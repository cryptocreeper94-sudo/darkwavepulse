import { createTool as createTool$1, Mastra } from '@mastra/core';
import { MastraError } from '@mastra/core/error';
import { PinoLogger } from '@mastra/loggers';
import { MastraLogger, LogLevel } from '@mastra/core/logger';
import pino from 'pino';
import { MCPServer } from '@mastra/mcp';
import { Inngest, NonRetriableError } from 'inngest';
import { z } from 'zod';
import { PostgresStore } from '@mastra/pg';
import { realtimeMiddleware } from '@inngest/realtime';
import { serve, init } from '@mastra/inngest';
import { RuntimeContext } from '@mastra/core/di';
import { createTool } from '@mastra/core/tools';
import pg from 'pg';
import axios from 'axios';
import { createWorkflow, createStep } from '@mastra/core/workflows';

const sharedPostgresStorage = new PostgresStore({
  connectionString: process.env.DATABASE_URL || "postgresql://localhost:5432/mastra"
});

const inngest = new Inngest(
  process.env.NODE_ENV === "production" ? {
    id: "replit-agent-workflow",
    name: "Replit Agent Workflow System"
  } : {
    id: "mastra",
    baseUrl: "http://localhost:3000",
    isDev: true,
    middleware: [realtimeMiddleware()]
  }
);

init(inngest);
const inngestFunctions = [];
function registerCronWorkflow(cronExpression, workflow) {
  const f = inngest.createFunction(
    { id: "cron-trigger" },
    [{ event: "replit/cron.trigger" }, { cron: cronExpression }],
    async ({ event, step }) => {
      const run = await workflow.createRunAsync();
      const result = await run.start({ inputData: {} });
      return result;
    }
  );
  inngestFunctions.push(f);
}
function inngestServe({
  mastra,
  inngest: inngest2
}) {
  let serveHost = void 0;
  if (process.env.NODE_ENV === "production") {
    if (process.env.REPLIT_DOMAINS) {
      serveHost = `https://${process.env.REPLIT_DOMAINS.split(",")[0]}`;
    }
  } else {
    serveHost = "http://localhost:5000";
  }
  return serve({
    mastra,
    inngest: inngest2,
    functions: inngestFunctions,
    registerOptions: { serveHost }
  });
}

if (!process.env.TELEGRAM_BOT_TOKEN) {
  console.warn(
    "\u26A0\uFE0F TELEGRAM_BOT_TOKEN not found. Telegram bot will not function."
  );
}
const TELEGRAM_API_URL = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;
let lastUpdateId = 0;
async function startTelegramPolling(mastra, handler) {
  const logger = mastra.getLogger();
  logger?.info("\u{1F916} [TelegramPolling] Starting polling mode...");
  const pollInterval = 2e3;
  async function poll() {
    try {
      const response = await fetch(
        `${TELEGRAM_API_URL}/getUpdates?offset=${lastUpdateId + 1}&timeout=30`,
        {
          method: "GET"
        }
      );
      const data = await response.json();
      if (!response.ok) {
        logger?.error(
          `\u274C [TelegramPolling] Failed to fetch updates: ${response.status} ${response.statusText}`,
          { telegramError: data.description || data }
        );
        return;
      }
      if (!data.ok) {
        logger?.error(
          `\u274C [TelegramPolling] Telegram API error:`,
          data.description
        );
        return;
      }
      const updates = data.result || [];
      if (updates.length > 0) {
        logger?.info(
          `\u{1F4EC} [TelegramPolling] Received ${updates.length} update(s)`
        );
      }
      for (const update of updates) {
        lastUpdateId = Math.max(lastUpdateId, update.update_id);
        if (!update.message || !update.message.text) {
          logger?.warn(
            "\u26A0\uFE0F [TelegramPolling] Ignoring non-text message or invalid update"
          );
          continue;
        }
        logger?.info("\u{1F4DD} [TelegramPolling] Processing message", {
          userName: update.message.from?.username || update.message.from?.first_name || "user",
          message: update.message.text
        });
        try {
          await handler(mastra, {
            type: "telegram/message",
            params: {
              userName: update.message.from?.username || update.message.from?.first_name || "user",
              message: update.message.text
            },
            payload: update
          });
        } catch (error) {
          logger?.error(
            "\u274C [TelegramPolling] Error processing message:",
            error
          );
        }
      }
    } catch (error) {
      logger?.error("\u274C [TelegramPolling] Polling error:", error);
    }
  }
  logger?.info(
    `\u2705 [TelegramPolling] Polling started (checking every ${pollInterval / 1e3}s)`
  );
  poll();
  setInterval(poll, pollInterval);
}

function calculateRSI$1(prices, period = 14) {
  if (prices.length < period + 1) {
    return null;
  }
  const changes = [];
  for (let i = 1; i < prices.length; i++) {
    changes.push(prices[i] - prices[i - 1]);
  }
  let avgGain = 0;
  let avgLoss = 0;
  for (let i = 0; i < period; i++) {
    if (changes[i] > 0) {
      avgGain += changes[i];
    } else {
      avgLoss += Math.abs(changes[i]);
    }
  }
  avgGain /= period;
  avgLoss /= period;
  for (let i = period; i < changes.length; i++) {
    const change = changes[i];
    const gain = change > 0 ? change : 0;
    const loss = change < 0 ? Math.abs(change) : 0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
  }
  if (avgLoss === 0) {
    return 100;
  }
  const rs = avgGain / avgLoss;
  const rsi = 100 - 100 / (1 + rs);
  return rsi;
}
function calculateSMA(prices, period) {
  if (prices.length < period) {
    return null;
  }
  const recentPrices = prices.slice(-period);
  const sum = recentPrices.reduce((a, b) => a + b, 0);
  return sum / period;
}
function calculateEMA(prices, period) {
  if (prices.length < period) {
    return null;
  }
  const multiplier = 2 / (period + 1);
  let ema = prices.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < prices.length; i++) {
    ema = (prices[i] - ema) * multiplier + ema;
  }
  return ema;
}
function calculateMACD(prices) {
  if (prices.length < 26) {
    return null;
  }
  const ema12 = calculateEMA(prices, 12);
  const ema26 = calculateEMA(prices, 26);
  if (!ema12 || !ema26) {
    return null;
  }
  const macdLine = ema12 - ema26;
  const macdHistory = [];
  for (let i = 26; i <= prices.length; i++) {
    const slice = prices.slice(0, i);
    const e12 = calculateEMA(slice, 12);
    const e26 = calculateEMA(slice, 26);
    if (e12 && e26) {
      macdHistory.push(e12 - e26);
    }
  }
  const signalLine = calculateEMA(macdHistory, 9) || 0;
  const histogram = macdLine - signalLine;
  return {
    macd: macdLine,
    signal: signalLine,
    histogram
  };
}
function calculateBollingerBands(prices, period = 20) {
  if (prices.length < period) {
    return null;
  }
  const recentPrices = prices.slice(-period);
  const sma = recentPrices.reduce((a, b) => a + b, 0) / period;
  const squaredDiffs = recentPrices.map((price) => Math.pow(price - sma, 2));
  const variance = squaredDiffs.reduce((a, b) => a + b, 0) / period;
  const stdDev = Math.sqrt(variance);
  const upper = sma + 2 * stdDev;
  const lower = sma - 2 * stdDev;
  const bandwidth = (upper - lower) / sma * 100;
  return {
    upper,
    middle: sma,
    lower,
    bandwidth
  };
}
function calculateSupportResistance(prices) {
  if (prices.length < 10) {
    return null;
  }
  const recentPrices = prices.slice(-20);
  const high = Math.max(...recentPrices);
  const low = Math.min(...recentPrices);
  const close = recentPrices[recentPrices.length - 1];
  const pivot = (high + low + close) / 3;
  const support = 2 * pivot - high;
  const resistance = 2 * pivot - low;
  const avg = recentPrices.reduce((a, b) => a + b) / recentPrices.length;
  const variance = recentPrices.reduce((sum, price) => sum + Math.pow(price - avg, 2), 0) / recentPrices.length;
  const volatility = Math.sqrt(variance);
  return { support, resistance, volatility };
}
function isNearSupport(currentPrice, support, volatility) {
  const threshold = volatility * 0.5;
  return currentPrice <= support + threshold && currentPrice >= support - threshold;
}
function isNearResistance(currentPrice, resistance, volatility) {
  const threshold = volatility * 0.5;
  return currentPrice >= resistance - threshold && currentPrice <= resistance + threshold;
}
function isBouncing(prices, support, currentPrice) {
  if (prices.length < 3) return false;
  const recent = prices.slice(-3);
  const wasNearSupport = recent[0] <= support * 1.02;
  const nowAboveSupport = currentPrice > support;
  return wasNearSupport && nowAboveSupport;
}
const scanAsset = createTool({
  id: "scan-asset",
  description: `Manual scanner to analyze ANY stock or crypto on demand. 
    Fetches 2 YEARS of historical data with comprehensive technical analysis.
    Calculates: RSI, MACD, Bollinger Bands, EMA (50/200), SMA (50/200), volume trends.
    Does NOT save to database - for quick ad-hoc analysis only.
    Supports stocks via Alpha Vantage and crypto via CoinGecko.`,
  inputSchema: z.object({
    symbol: z.string().describe("Asset symbol (e.g., AMD, NVDA, TSLA for stocks; SOL, BTC, ETH for crypto)"),
    assetType: z.enum(["STOCK", "CRYPTO"]).describe("Type of asset to scan")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    symbol: z.string().optional(),
    assetType: z.string().optional(),
    currentPrice: z.number().optional(),
    changePercent: z.number().optional(),
    rsi: z.number().optional(),
    recommendation: z.string().optional(),
    signal: z.string().optional(),
    volume24h: z.number().optional(),
    volumeChange: z.number().optional(),
    volumeIndicator: z.string().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { symbol, assetType } = context;
    try {
      logger?.info("\u{1F50D} [ScanAsset] Starting manual scan with 2-year analysis", { symbol, assetType });
      let currentPrice;
      let changePercent;
      let historicalPrices = [];
      let volume24h;
      let volumeChange;
      let volumeIndicator;
      if (assetType === "STOCK") {
        logger?.info("\u{1F517} [ScanAsset] Fetching stock data from Alpha Vantage", { symbol });
        const apiKey = process.env.ALPHA_VANTAGE_API_KEY;
        if (!apiKey) {
          throw new Error("ALPHA_VANTAGE_API_KEY not configured");
        }
        const quoteUrl = `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${apiKey}`;
        const quoteResponse = await fetch(quoteUrl);
        if (!quoteResponse.ok) {
          throw new Error(`Alpha Vantage API error: ${quoteResponse.status}`);
        }
        const quoteData = await quoteResponse.json();
        if (quoteData["Note"]) {
          return {
            success: false,
            error: "Alpha Vantage API rate limit exceeded. Try again in 1 minute."
          };
        }
        if (quoteData["Error Message"]) {
          throw new Error(`Invalid stock symbol: ${symbol}`);
        }
        const quote = quoteData["Global Quote"];
        if (!quote) {
          throw new Error("No stock quote data received");
        }
        currentPrice = parseFloat(quote["05. price"]);
        changePercent = parseFloat(quote["10. change percent"]?.replace("%", ""));
        logger?.info("\u{1F4CA} [ScanAsset] Fetching 2 years of historical stock data...");
        const dailyUrl = `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=${symbol}&outputsize=full&apikey=${apiKey}`;
        const dailyResponse = await fetch(dailyUrl);
        if (dailyResponse.ok) {
          const dailyData = await dailyResponse.json();
          const timeSeries = dailyData["Time Series (Daily)"];
          if (timeSeries) {
            historicalPrices = Object.keys(timeSeries).sort().slice(-730).map((date) => parseFloat(timeSeries[date]["4. close"]));
            logger?.info("\u2705 [ScanAsset] Loaded historical data", { days: historicalPrices.length });
          }
        }
        logger?.info("\u{1F4B0} [ScanAsset] Stock data fetched", { price: currentPrice, changePercent });
      } else {
        logger?.info("\u{1F517} [ScanAsset] Searching for crypto on CoinGecko", { symbol });
        let searchUrl = `https://api.coingecko.com/api/v3/search?query=${symbol}`;
        let searchResponse = await fetch(searchUrl);
        if (searchResponse.status === 429) {
          logger?.warn("\u23F3 [ScanAsset] Rate limited, waiting 3 seconds...");
          await new Promise((resolve) => setTimeout(resolve, 3e3));
          searchResponse = await fetch(searchUrl);
        }
        if (!searchResponse.ok) {
          throw new Error(`CoinGecko search failed: ${searchResponse.status}`);
        }
        const searchData = await searchResponse.json();
        const coin = searchData.coins?.find(
          (c) => c.symbol?.toUpperCase() === symbol.toUpperCase()
        );
        if (!coin) {
          throw new Error(`"${symbol}" not found on CoinGecko. Check the ticker symbol.`);
        }
        const coinId = coin.id;
        logger?.info("\u2705 [ScanAsset] Found coin", { symbol, coinId, name: coin.name });
        let priceUrl = `https://api.coingecko.com/api/v3/simple/price?ids=${coinId}&vs_currencies=usd&include_24hr_change=true`;
        let priceResponse = await fetch(priceUrl);
        if (priceResponse.status === 429) {
          logger?.warn("\u23F3 [ScanAsset] Rate limited on price, waiting 3 seconds...");
          await new Promise((resolve) => setTimeout(resolve, 3e3));
          priceResponse = await fetch(priceUrl);
        }
        if (!priceResponse.ok) {
          throw new Error(`CoinGecko price fetch failed: ${priceResponse.status}`);
        }
        const priceData = await priceResponse.json();
        if (!priceData[coinId]) {
          throw new Error("No price data available");
        }
        currentPrice = priceData[coinId].usd;
        changePercent = priceData[coinId].usd_24h_change;
        logger?.info("\u{1F4CA} [ScanAsset] Fetching 2 years of crypto historical data...");
        let historyUrl = `https://api.coingecko.com/api/v3/coins/${coinId}/market_chart?vs_currency=usd&days=730&interval=daily`;
        let historyResponse = null;
        let historyData = null;
        for (let attempt = 1; attempt <= 3; attempt++) {
          historyResponse = await fetch(historyUrl);
          if (historyResponse.status === 429) {
            const delay = attempt * 2e3;
            logger?.warn(`\u23F3 [ScanAsset] Rate limited on history (attempt ${attempt}/3), waiting ${delay / 1e3}s...`);
            await new Promise((resolve) => setTimeout(resolve, delay));
            continue;
          }
          if (historyResponse.ok) {
            historyData = await historyResponse.json();
            logger?.info(`\u2705 [ScanAsset] Historical data received (attempt ${attempt})`, {
              priceCount: historyData?.prices?.length || 0,
              volumeCount: historyData?.total_volumes?.length || 0
            });
            break;
          } else {
            logger?.warn(`\u26A0\uFE0F [ScanAsset] History fetch failed (attempt ${attempt}/3): ${historyResponse.status}`);
            if (attempt < 3) {
              await new Promise((resolve) => setTimeout(resolve, 2e3));
            }
          }
        }
        if (historyData && historyData.prices && historyData.prices.length >= 15) {
          historicalPrices = historyData.prices.map((p) => p[1]);
          logger?.info("\u{1F4CA} [ScanAsset] Historical prices loaded", { days: historicalPrices.length });
        } else {
          logger?.warn("\u26A0\uFE0F [ScanAsset] Insufficient historical price data", {
            received: historyData?.prices?.length || 0,
            required: 15
          });
        }
        if (historyData) {
          if (historyData.total_volumes && historyData.total_volumes.length >= 2) {
            const volumes = historyData.total_volumes;
            const currentVol = volumes[volumes.length - 1][1];
            const previousVol = volumes[volumes.length - 2][1];
            volume24h = currentVol;
            if (previousVol > 0 && currentVol >= 0) {
              volumeChange = (currentVol - previousVol) / previousVol * 100;
              if (Number.isFinite(volumeChange)) {
                volumeIndicator = volumeChange > 0 ? "\u{1F7E2}" : "\u{1F534}";
                logger?.info("\u{1F4CA} [ScanAsset] Volume data calculated", {
                  volume24h: volume24h?.toFixed(0) || "0",
                  volumeChange: volumeChange.toFixed(2) + "%",
                  volumeIndicator
                });
              }
            }
          }
        }
        logger?.info("\u{1F4B0} [ScanAsset] Crypto data fetched", { price: currentPrice, changePercent });
      }
      historicalPrices.push(currentPrice);
      const rsi = calculateRSI$1(historicalPrices, 14);
      const sma50 = calculateSMA(historicalPrices, 50);
      const sma200 = calculateSMA(historicalPrices, 200);
      const ema50 = calculateEMA(historicalPrices, 50);
      const ema200 = calculateEMA(historicalPrices, 200);
      const macd = calculateMACD(historicalPrices);
      const bollinger = calculateBollingerBands(historicalPrices, 20);
      const levels = calculateSupportResistance(historicalPrices);
      logger?.info("\u{1F4CA} [ScanAsset] All technical indicators calculated", {
        rsi: rsi?.toFixed(2),
        sma50: sma50?.toFixed(2),
        sma200: sma200?.toFixed(2),
        ema50: ema50?.toFixed(2),
        ema200: ema200?.toFixed(2),
        macd: macd?.macd.toFixed(2),
        bollingerBandwidth: bollinger?.bandwidth.toFixed(2)
      });
      let signal = "";
      let recommendation = "";
      const buySignals = [];
      const sellSignals = [];
      if (rsi !== null) {
        logger?.info("\u{1F4CA} [ScanAsset] RSI calculated", { rsi: rsi.toFixed(2) });
        if (rsi < 30) {
          buySignals.push(`RSI oversold (${rsi.toFixed(1)})`);
        } else if (rsi > 70) {
          sellSignals.push(`RSI overbought (${rsi.toFixed(1)})`);
        }
      }
      if (macd) {
        if (macd.histogram > 0 && macd.macd > macd.signal) {
          buySignals.push(`MACD bullish crossover`);
        } else if (macd.histogram < 0 && macd.macd < macd.signal) {
          sellSignals.push(`MACD bearish crossover`);
        }
      }
      if (sma50 && sma200) {
        if (currentPrice > sma50 && sma50 > sma200) {
          buySignals.push(`Golden cross: SMA50 > SMA200`);
        } else if (currentPrice < sma50 && sma50 < sma200) {
          sellSignals.push(`Death cross: SMA50 < SMA200`);
        }
      }
      if (bollinger) {
        if (currentPrice <= bollinger.lower) {
          buySignals.push(`Price at lower Bollinger Band`);
        } else if (currentPrice >= bollinger.upper) {
          sellSignals.push(`Price at upper Bollinger Band`);
        }
      }
      if (levels) {
        const { support, resistance, volatility } = levels;
        const volatilityPercent = volatility / currentPrice * 100;
        logger?.info("\u{1F4CA} [ScanAsset] Dynamic levels calculated", {
          support: support.toFixed(2),
          resistance: resistance.toFixed(2),
          volatility: volatility.toFixed(2),
          volatilityPercent: volatilityPercent.toFixed(2)
        });
        const nearSupport = isNearSupport(currentPrice, support, volatility);
        const nearResistance = isNearResistance(currentPrice, resistance, volatility);
        const bouncing = isBouncing(historicalPrices, support, currentPrice);
        if (bouncing && nearSupport) {
          buySignals.push(`Bouncing off support floor ($${support.toFixed(2)})`);
        } else if (nearSupport) {
          buySignals.push(`At support floor ($${support.toFixed(2)})`);
        }
        if (nearResistance) {
          sellSignals.push(`At resistance ceiling ($${resistance.toFixed(2)})`);
        }
        const distanceFromSupport = (currentPrice - support) / support * 100;
        const distanceFromResistance = (resistance - currentPrice) / currentPrice * 100;
        if (distanceFromSupport < 2) {
          buySignals.push(`Within 2% of support`);
        }
        if (distanceFromResistance < 2) {
          sellSignals.push(`Within 2% of resistance`);
        }
        const decimals = assetType === "CRYPTO" ? 8 : 2;
        if (buySignals.length > 0) {
          signal = `\u{1F7E2} BUY`;
          recommendation = `${symbol} - STRONG BUY SIGNAL

`;
          recommendation += `\u{1F4B0} Price: $${currentPrice.toFixed(decimals)} (${changePercent?.toFixed(2)}% 24h)

`;
          recommendation += `\u{1F4CA} TECHNICAL INDICATORS:
`;
          recommendation += `  \u2022 RSI (14): ${rsi?.toFixed(1) || "N/A"}
`;
          if (macd) {
            recommendation += `  \u2022 MACD: ${macd.macd > 0 ? "+" : ""}${macd.macd.toFixed(2)} | Signal: ${macd.signal.toFixed(2)} | Histogram: ${macd.histogram > 0 ? "+" : ""}${macd.histogram.toFixed(2)}
`;
          }
          if (sma50) recommendation += `  \u2022 SMA 50: $${sma50.toFixed(decimals)}
`;
          if (sma200) recommendation += `  \u2022 SMA 200: $${sma200.toFixed(decimals)}
`;
          if (ema50) recommendation += `  \u2022 EMA 50: $${ema50.toFixed(decimals)}
`;
          if (ema200) recommendation += `  \u2022 EMA 200: $${ema200.toFixed(decimals)}
`;
          if (bollinger) {
            recommendation += `  \u2022 Bollinger Bands:
`;
            recommendation += `    Upper: $${bollinger.upper.toFixed(decimals)}
`;
            recommendation += `    Middle: $${bollinger.middle.toFixed(decimals)}
`;
            recommendation += `    Lower: $${bollinger.lower.toFixed(decimals)}
`;
            recommendation += `    Bandwidth: ${bollinger.bandwidth.toFixed(2)}%
`;
          }
          recommendation += `  \u2022 Support: $${support.toFixed(decimals)}
`;
          recommendation += `  \u2022 Resistance: $${resistance.toFixed(decimals)}
`;
          recommendation += `  \u2022 Volatility: ${volatilityPercent.toFixed(1)}%
`;
          if (volume24h !== void 0 && volumeChange !== void 0 && volumeIndicator) {
            recommendation += `  \u2022 Volume: ${volumeIndicator} $${(volume24h / 1e6).toFixed(2)}M (${volumeChange > 0 ? "+" : ""}${volumeChange.toFixed(1)}%)
`;
          }
          recommendation += `
\u2705 BUY SIGNALS (${buySignals.length}):
${buySignals.map((s) => `  \u2022 ${s}`).join("\n")}

`;
          recommendation += `\u{1F4A1} RECOMMENDATION: Strong entry point based on ${historicalPrices.length} days of analysis! Price ${bouncing ? "is bouncing off" : "is near"} dynamic support floor. Consider entering position.`;
        } else if (sellSignals.length > 0) {
          signal = `\u{1F534} SELL`;
          recommendation = `${symbol} - SELL WARNING

`;
          recommendation += `\u{1F4B0} Price: $${currentPrice.toFixed(decimals)} (${changePercent?.toFixed(2)}% 24h)

`;
          recommendation += `\u{1F4CA} TECHNICAL INDICATORS:
`;
          recommendation += `  \u2022 RSI (14): ${rsi?.toFixed(1) || "N/A"}
`;
          if (macd) {
            recommendation += `  \u2022 MACD: ${macd.macd > 0 ? "+" : ""}${macd.macd.toFixed(2)} | Signal: ${macd.signal.toFixed(2)} | Histogram: ${macd.histogram > 0 ? "+" : ""}${macd.histogram.toFixed(2)}
`;
          }
          if (sma50) recommendation += `  \u2022 SMA 50: $${sma50.toFixed(decimals)}
`;
          if (sma200) recommendation += `  \u2022 SMA 200: $${sma200.toFixed(decimals)}
`;
          if (ema50) recommendation += `  \u2022 EMA 50: $${ema50.toFixed(decimals)}
`;
          if (ema200) recommendation += `  \u2022 EMA 200: $${ema200.toFixed(decimals)}
`;
          if (bollinger) {
            recommendation += `  \u2022 Bollinger Bands:
`;
            recommendation += `    Upper: $${bollinger.upper.toFixed(decimals)}
`;
            recommendation += `    Middle: $${bollinger.middle.toFixed(decimals)}
`;
            recommendation += `    Lower: $${bollinger.lower.toFixed(decimals)}
`;
            recommendation += `    Bandwidth: ${bollinger.bandwidth.toFixed(2)}%
`;
          }
          recommendation += `  \u2022 Support: $${support.toFixed(decimals)}
`;
          recommendation += `  \u2022 Resistance: $${resistance.toFixed(decimals)}
`;
          recommendation += `  \u2022 Volatility: ${volatilityPercent.toFixed(1)}%
`;
          if (volume24h !== void 0 && volumeChange !== void 0 && volumeIndicator) {
            recommendation += `  \u2022 Volume: ${volumeIndicator} $${(volume24h / 1e6).toFixed(2)}M (${volumeChange > 0 ? "+" : ""}${volumeChange.toFixed(1)}%)
`;
          }
          recommendation += `
\u26A0\uFE0F SELL SIGNALS (${sellSignals.length}):
${sellSignals.map((s) => `  \u2022 ${s}`).join("\n")}

`;
          recommendation += `\u{1F4A1} RECOMMENDATION: Based on ${historicalPrices.length} days of data - Price near resistance ceiling. Consider taking profits or waiting for pullback.`;
        } else {
          signal = `\u{1F7E1} HOLD`;
          recommendation = `${symbol} - NO CLEAR SIGNAL

`;
          recommendation += `\u{1F4B0} Price: $${currentPrice.toFixed(decimals)} (${changePercent?.toFixed(2)}% 24h)

`;
          recommendation += `\u{1F4CA} TECHNICAL INDICATORS:
`;
          recommendation += `  \u2022 RSI (14): ${rsi?.toFixed(1) || "N/A"}
`;
          if (macd) {
            recommendation += `  \u2022 MACD: ${macd.macd > 0 ? "+" : ""}${macd.macd.toFixed(2)} | Signal: ${macd.signal.toFixed(2)} | Histogram: ${macd.histogram > 0 ? "+" : ""}${macd.histogram.toFixed(2)}
`;
          }
          if (sma50) recommendation += `  \u2022 SMA 50: $${sma50.toFixed(decimals)}
`;
          if (sma200) recommendation += `  \u2022 SMA 200: $${sma200.toFixed(decimals)}
`;
          if (ema50) recommendation += `  \u2022 EMA 50: $${ema50.toFixed(decimals)}
`;
          if (ema200) recommendation += `  \u2022 EMA 200: $${ema200.toFixed(decimals)}
`;
          if (bollinger) {
            recommendation += `  \u2022 Bollinger Bands:
`;
            recommendation += `    Upper: $${bollinger.upper.toFixed(decimals)}
`;
            recommendation += `    Middle: $${bollinger.middle.toFixed(decimals)}
`;
            recommendation += `    Lower: $${bollinger.lower.toFixed(decimals)}
`;
            recommendation += `    Bandwidth: ${bollinger.bandwidth.toFixed(2)}%
`;
          }
          recommendation += `  \u2022 Support: $${support.toFixed(decimals)} (${distanceFromSupport.toFixed(1)}% away)
`;
          recommendation += `  \u2022 Resistance: $${resistance.toFixed(decimals)} (${distanceFromResistance.toFixed(1)}% away)
`;
          recommendation += `  \u2022 Volatility: ${volatilityPercent.toFixed(1)}%
`;
          if (volume24h !== void 0 && volumeChange !== void 0 && volumeIndicator) {
            recommendation += `  \u2022 Volume: ${volumeIndicator} $${(volume24h / 1e6).toFixed(2)}M (${volumeChange > 0 ? "+" : ""}${volumeChange.toFixed(1)}%)
`;
          }
          recommendation += `
\u{1F4A1} RECOMMENDATION: Based on ${historicalPrices.length} days of data - Price in neutral zone. Wait for price to reach support ($${support.toFixed(decimals)}) for buy signal or resistance ($${resistance.toFixed(decimals)}) for sell signal.`;
        }
      } else if (rsi !== null) {
        const decimals = assetType === "CRYPTO" ? 8 : 2;
        if (rsi < 30) {
          signal = `\u{1F7E2} BUY`;
          recommendation = `${symbol} - OVERSOLD

Price: $${currentPrice.toFixed(decimals)} (${changePercent?.toFixed(2)}% 24h)
RSI: ${rsi.toFixed(1)}

RECOMMENDATION: Strong buy signal! Asset is heavily oversold and likely to bounce.`;
        } else if (rsi > 70) {
          signal = `\u{1F534} SELL`;
          recommendation = `${symbol} - OVERBOUGHT

Price: $${currentPrice.toFixed(decimals)} (${changePercent?.toFixed(2)}% 24h)
RSI: ${rsi.toFixed(1)}

RECOMMENDATION: Price is overheated. Consider taking profits or wait for pullback.`;
        } else {
          signal = `\u{1F7E1} HOLD`;
          recommendation = `${symbol} - NEUTRAL

Price: $${currentPrice.toFixed(decimals)} (${changePercent?.toFixed(2)}% 24h)
RSI: ${rsi.toFixed(1)}

RECOMMENDATION: No clear signal. Wait for RSI < 30 for buy opportunity.`;
        }
      } else {
        const decimals = assetType === "CRYPTO" ? 8 : 2;
        logger?.warn("\u26A0\uFE0F [ScanAsset] Not enough historical data");
        recommendation = `${symbol} Price: $${currentPrice.toFixed(decimals)} (${changePercent?.toFixed(2)}% 24h)

NOTE: Not enough historical data to calculate comprehensive signals. Need more price history for full technical analysis.`;
      }
      logger?.info("\u2705 [ScanAsset] Scan complete with 2-year analysis", {
        symbol,
        currentPrice,
        historicalDays: historicalPrices.length,
        rsi: rsi !== null ? rsi.toFixed(2) : "N/A",
        signal
      });
      return {
        success: true,
        symbol,
        assetType,
        currentPrice,
        changePercent,
        rsi: rsi !== null ? rsi : void 0,
        signal,
        recommendation,
        volume24h,
        volumeChange,
        volumeIndicator
      };
    } catch (error) {
      logger?.error("\u274C [ScanAsset] Error during scan", {
        error: error.message,
        symbol
      });
      return {
        success: false,
        error: error.message
      };
    }
  }
});

const sendTelegramAlert = createTool({
  id: "send-telegram-alert",
  description: "Sends a message alert to a configured Telegram chat",
  inputSchema: z.object({
    message: z.string().describe("Message to send (supports Markdown formatting)")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    messageId: z.number().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { message } = context;
    logger?.info("\u{1F527} [SendTelegramAlert] Starting execution", { messageLength: message.length });
    try {
      const botToken = process.env.TELEGRAM_BOT_TOKEN;
      const chatId = process.env.TELEGRAM_CHAT_ID;
      if (!botToken) {
        logger?.error("\u274C [SendTelegramAlert] TELEGRAM_BOT_TOKEN not found in environment");
        throw new Error("TELEGRAM_BOT_TOKEN is not configured");
      }
      if (!chatId) {
        logger?.error("\u274C [SendTelegramAlert] TELEGRAM_CHAT_ID not found in environment");
        throw new Error("TELEGRAM_CHAT_ID is not configured");
      }
      const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
      const chatIdMasked = chatId.length > 8 ? `${chatId.substring(0, 4)}...${chatId.substring(chatId.length - 4)}` : "***";
      logger?.info("\u{1F4E1} [SendTelegramAlert] Sending message to Telegram", { chatId: chatIdMasked });
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          chat_id: chatId,
          text: message,
          parse_mode: "Markdown"
        })
      });
      if (!response.ok) {
        const errorData = await response.json();
        logger?.error("\u274C [SendTelegramAlert] Telegram API request failed", {
          status: response.status,
          error: errorData
        });
        throw new Error(`Telegram API request failed: ${response.status} - ${JSON.stringify(errorData)}`);
      }
      const result = await response.json();
      logger?.info("\u2705 [SendTelegramAlert] Successfully sent Telegram message", {
        messageId: result.result?.message_id
      });
      return {
        success: true,
        messageId: result.result?.message_id
      };
    } catch (error) {
      logger?.error("\u274C [SendTelegramAlert] Error sending Telegram alert", { error });
      throw error;
    }
  }
});

const getNewCoins = createTool({
  id: "get-new-coins",
  description: "Fetches newly listed and verified cryptocurrencies from CoinGecko with market data and sentiment indicators",
  inputSchema: z.object({
    limit: z.number().default(10).describe("Number of new coins to fetch (default 10)")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    coins: z.array(z.object({
      id: z.string(),
      symbol: z.string(),
      name: z.string(),
      currentPrice: z.number().optional(),
      marketCap: z.number().optional(),
      volume24h: z.number().optional(),
      priceChange24h: z.number().optional(),
      marketCapRank: z.number().optional()
    })).optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { limit } = context;
    try {
      logger?.info("\u{1F195} [GetNewCoins] Fetching newly listed coins", { limit });
      const url = `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=${limit}&page=1&sparkline=false&price_change_percentage=24h&locale=en`;
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`CoinGecko API error: ${response.status}`);
      }
      const data = await response.json();
      const coins = data.slice(0, limit).map((coin) => ({
        id: coin.id,
        symbol: coin.symbol?.toUpperCase(),
        name: coin.name,
        currentPrice: coin.current_price,
        marketCap: coin.market_cap,
        volume24h: coin.total_volume,
        priceChange24h: coin.price_change_percentage_24h,
        marketCapRank: coin.market_cap_rank
      }));
      logger?.info(`\u2705 [GetNewCoins] Fetched ${coins.length} coins`);
      return {
        success: true,
        coins
      };
    } catch (error) {
      logger?.error("\u274C [GetNewCoins] Error fetching new coins", {
        error: error.message
      });
      return {
        success: false,
        error: error.message
      };
    }
  }
});

const getTrendingCoins = createTool({
  id: "get-trending-coins",
  description: "Fetches trending cryptocurrencies with community engagement and sentiment data from CoinGecko",
  inputSchema: z.object({}),
  outputSchema: z.object({
    success: z.boolean(),
    trending: z.array(z.object({
      id: z.string(),
      symbol: z.string(),
      name: z.string(),
      marketCapRank: z.number().optional(),
      priceUsd: z.number().optional(),
      priceChange24h: z.number().optional(),
      volume24h: z.number().optional(),
      marketCap: z.number().optional(),
      description: z.string().optional()
    })).optional(),
    error: z.string().optional()
  }),
  execute: async ({ mastra }) => {
    const logger = mastra?.getLogger();
    try {
      logger?.info("\u{1F4C8} [GetTrendingCoins] Fetching trending coins from CoinGecko");
      const trendingUrl = "https://api.coingecko.com/api/v3/search/trending";
      const trendingResponse = await fetch(trendingUrl);
      if (!trendingResponse.ok) {
        throw new Error(`CoinGecko trending API error: ${trendingResponse.status}`);
      }
      const trendingData = await trendingResponse.json();
      const trendingCoins = trendingData.coins || [];
      logger?.info(`\u{1F4CA} [GetTrendingCoins] Found ${trendingCoins.length} trending coins`);
      const coinIds = trendingCoins.slice(0, 10).map((item) => item.item?.id).filter(Boolean);
      if (coinIds.length === 0) {
        return {
          success: true,
          trending: []
        };
      }
      const marketUrl = `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${coinIds.join(",")}&order=market_cap_desc&sparkline=false&price_change_percentage=24h`;
      const marketResponse = await fetch(marketUrl);
      if (!marketResponse.ok) {
        logger?.warn("\u26A0\uFE0F [GetTrendingCoins] Could not fetch market data, returning basic info");
        return {
          success: true,
          trending: trendingCoins.slice(0, 10).map((item) => ({
            id: item.item?.id || "unknown",
            symbol: item.item?.symbol?.toUpperCase() || "N/A",
            name: item.item?.name || "Unknown",
            marketCapRank: item.item?.market_cap_rank,
            description: `Trending #${item.item?.market_cap_rank || "N/A"} on CoinGecko`
          }))
        };
      }
      const marketData = await marketResponse.json();
      const enrichedTrending = marketData.map((coin) => ({
        id: coin.id,
        symbol: coin.symbol?.toUpperCase(),
        name: coin.name,
        marketCapRank: coin.market_cap_rank,
        priceUsd: coin.current_price,
        priceChange24h: coin.price_change_percentage_24h,
        volume24h: coin.total_volume,
        marketCap: coin.market_cap,
        description: `Rank #${coin.market_cap_rank || "N/A"} | Volume: $${(coin.total_volume / 1e6).toFixed(2)}M`
      }));
      logger?.info(`\u2705 [GetTrendingCoins] Enriched ${enrichedTrending.length} trending coins with market data`);
      return {
        success: true,
        trending: enrichedTrending
      };
    } catch (error) {
      logger?.error("\u274C [GetTrendingCoins] Error fetching trending coins", {
        error: error.message
      });
      return {
        success: false,
        error: error.message
      };
    }
  }
});

const TOP_200_STOCKS$1 = [
  // Top 100 by market cap
  "AAPL",
  "MSFT",
  "GOOGL",
  "AMZN",
  "NVDA",
  "META",
  "TSLA",
  "BRK.B",
  "UNH",
  "XOM",
  "JNJ",
  "JPM",
  "V",
  "PG",
  "MA",
  "HD",
  "CVX",
  "MRK",
  "ABBV",
  "PEP",
  "COST",
  "AVGO",
  "KO",
  "ADBE",
  "MCD",
  "CSCO",
  "ACN",
  "LLY",
  "TMO",
  "NFLX",
  "ABT",
  "NKE",
  "CRM",
  "DHR",
  "VZ",
  "TXN",
  "WMT",
  "NEE",
  "ORCL",
  "INTC",
  "PM",
  "BMY",
  "UPS",
  "RTX",
  "QCOM",
  "AMD",
  "INTU",
  "HON",
  "CMCSA",
  "AMGN",
  "UNP",
  "IBM",
  "BA",
  "LOW",
  "SBUX",
  "CAT",
  "GE",
  "SPGI",
  "DE",
  "AMAT",
  "PLD",
  "LMT",
  "GS",
  "BLK",
  "AXP",
  "MDT",
  "GILD",
  "ADI",
  "ISRG",
  "CI",
  "TJX",
  "MMC",
  "C",
  "BKNG",
  "AMT",
  "SYK",
  "CB",
  "ZTS",
  "VRTX",
  "MO",
  "REGN",
  "DUK",
  "PGR",
  "SO",
  "EOG",
  "CME",
  "MMM",
  "ITW",
  "SCHW",
  "NOC",
  "APD",
  "WM",
  "CL",
  "BSX",
  "ICE",
  "MU",
  "SLB",
  "PYPL",
  "AON",
  "FDX",
  // Top 101-200
  "TMUS",
  "MS",
  "EQIX",
  "MCO",
  "BDX",
  "ADP",
  "USB",
  "TGT",
  "LRCX",
  "PNC",
  "SHW",
  "ATVI",
  "FISV",
  "EL",
  "NSC",
  "MDLZ",
  "GM",
  "HUM",
  "GPN",
  "MAR",
  "AIG",
  "MCK",
  "EMR",
  "D",
  "KLAC",
  "SNPS",
  "ORLY",
  "ADSK",
  "HCA",
  "ECL",
  "CSX",
  "ROP",
  "IQV",
  "AFL",
  "EW",
  "PSA",
  "AEP",
  "ILMN",
  "SPG",
  "NXPI",
  "CCI",
  "FCX",
  "KMB",
  "CARR",
  "CMG",
  "MCHP",
  "WELL",
  "DD",
  "MNST",
  "AZO",
  "DLR",
  "MSI",
  "PAYX",
  "STZ",
  "ROST",
  "ALL",
  "APH",
  "PPG",
  "NEM",
  "APTV",
  "HLT",
  "SRE",
  "F",
  "CDNS",
  "CTVA",
  "FTNT",
  "TEL",
  "IDXX",
  "KHC",
  "SYY",
  "DOW",
  "EA",
  "GIS",
  "YUM",
  "PRU",
  "BK",
  "O",
  "WBA",
  "ANSS",
  "CTSH",
  "GLW",
  "BIIB",
  "DXCM",
  "CTAS",
  "ED",
  "WEC",
  "XEL",
  "IT",
  "EBAY",
  "AMP",
  "HPQ",
  "DHI",
  "KEYS",
  "MTD",
  "ETN",
  "PCAR",
  "FAST",
  "VRSK",
  "AVB",
  "KMI"
];
async function getTop250Cryptos$1(logger) {
  try {
    logger?.info("\u{1F50D} [GetBuySignals] Fetching top 250 cryptocurrencies from CoinGecko");
    const url = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=250&page=1&sparkline=false";
    const response = await fetch(url);
    if (!response.ok) {
      logger?.warn("\u26A0\uFE0F [GetBuySignals] Failed to fetch top 250 cryptos, using fallback list");
      return ["BTC", "ETH", "USDT", "BNB", "SOL", "USDC", "XRP", "DOGE", "ADA", "AVAX", "TRX", "DOT", "MATIC", "LINK", "SHIB", "UNI", "ATOM", "LTC", "XMR", "BCH"];
    }
    const data = await response.json();
    const cryptoSymbols = data.map((coin) => coin.symbol.toUpperCase());
    logger?.info(`\u2705 [GetBuySignals] Fetched ${cryptoSymbols.length} crypto symbols`);
    return cryptoSymbols;
  } catch (error) {
    logger?.warn("\u26A0\uFE0F [GetBuySignals] Error fetching top 250 cryptos:", error.message);
    return ["BTC", "ETH", "USDT", "BNB", "SOL", "USDC", "XRP", "DOGE", "ADA", "AVAX", "TRX", "DOT", "MATIC", "LINK", "SHIB", "UNI", "ATOM", "LTC", "XMR", "BCH"];
  }
}
const getBuySignals = createTool({
  id: "get-buy-signals",
  description: "Scans stocks and/or crypto for buy signals with configurable filters",
  inputSchema: z.object({
    assetType: z.enum(["STOCK", "CRYPTO", "BOTH"]).optional().default("BOTH").describe("Filter by asset type"),
    limit: z.number().optional().default(200).describe("Max assets to scan per type (default 200)")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    buyOpportunities: z.array(z.object({
      ticker: z.string(),
      type: z.string(),
      price: z.number(),
      signal: z.string(),
      reason: z.string(),
      rsi: z.number().optional(),
      priceChange24h: z.number().optional(),
      volume24h: z.number().optional(),
      volumeChange: z.number().optional(),
      volumeIndicator: z.string().optional()
    })).optional(),
    scannedCount: z.number(),
    totalAssets: z.number(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { assetType = "BOTH", limit = 100 } = context;
    logger?.info("\u{1F50D} [GetBuySignals] Starting scan", { assetType, limit });
    const buyOpportunities = [];
    let scannedCount = 0;
    try {
      let allAssets = [];
      if (assetType === "STOCK" || assetType === "BOTH") {
        const stocksToScan = TOP_200_STOCKS$1.slice(0, limit);
        allAssets.push(...stocksToScan.map((ticker) => ({ ticker, type: "STOCK" })));
      }
      if (assetType === "CRYPTO" || assetType === "BOTH") {
        const cryptoSymbols = await getTop250Cryptos$1(logger);
        const cryptosToScan = cryptoSymbols.slice(0, limit);
        allAssets.push(...cryptosToScan.map((ticker) => ({ ticker, type: "CRYPTO" })));
      }
      logger?.info(`\u{1F4CA} [GetBuySignals] Total assets to scan: ${allAssets.length}`);
      for (const asset of allAssets) {
        try {
          logger?.info(`\u{1F4CA} [GetBuySignals] Scanning ${asset.ticker} (${asset.type})`);
          const result = await scanAsset.execute({
            context: {
              symbol: asset.ticker,
              assetType: asset.type
            },
            runtimeContext: new RuntimeContext(),
            mastra
          });
          scannedCount++;
          await new Promise((resolve) => setTimeout(resolve, 1e3));
          if (!result.success) {
            logger?.warn(`\u26A0\uFE0F [GetBuySignals] Failed to scan ${asset.ticker}`);
            continue;
          }
          let isBuySignal = false;
          let reason = "";
          if (result.signal?.includes("BUY")) {
            isBuySignal = true;
            const rec = result.recommendation || "";
            if (rec.includes("Bouncing off support")) {
              reason = "Bouncing off dynamic support floor";
            } else if (rec.includes("At support floor")) {
              reason = "At dynamic support level";
            } else if (rec.includes("Within 2% of support")) {
              reason = "Near support floor";
            } else if (rec.includes("oversold")) {
              reason = "RSI oversold - strong buy signal";
            } else {
              reason = "Multiple buy signals detected";
            }
            if (result.rsi && result.rsi < 30) {
              reason += ` | RSI: ${result.rsi.toFixed(1)}`;
            }
          }
          if (isBuySignal && result.currentPrice) {
            buyOpportunities.push({
              ticker: asset.ticker,
              type: asset.type,
              price: result.currentPrice,
              signal: "BUY",
              reason,
              rsi: result.rsi,
              priceChange24h: result.changePercent,
              volume24h: result.volume24h,
              volumeChange: result.volumeChange,
              volumeIndicator: result.volumeIndicator
            });
            logger?.info(`\u2705 [GetBuySignals] BUY signal: ${asset.ticker}`, { reason });
          }
        } catch (error) {
          logger?.warn(`\u26A0\uFE0F [GetBuySignals] Error scanning ${asset.ticker}:`, error.message);
        }
      }
      logger?.info(`\u{1F3AF} [GetBuySignals] Scan complete: ${buyOpportunities.length} buy signals found out of ${scannedCount} scanned`);
      return {
        success: true,
        buyOpportunities,
        scannedCount,
        totalAssets: allAssets.length
      };
    } catch (error) {
      logger?.error("\u274C [GetBuySignals] Fatal error", { error: error.message });
      return {
        success: false,
        scannedCount,
        totalAssets: 0,
        error: error.message
      };
    }
  }
});

const TOP_200_STOCKS = [
  // Top 100 by market cap
  "AAPL",
  "MSFT",
  "GOOGL",
  "AMZN",
  "NVDA",
  "META",
  "TSLA",
  "BRK.B",
  "UNH",
  "XOM",
  "JNJ",
  "JPM",
  "V",
  "PG",
  "MA",
  "HD",
  "CVX",
  "MRK",
  "ABBV",
  "PEP",
  "COST",
  "AVGO",
  "KO",
  "ADBE",
  "MCD",
  "CSCO",
  "ACN",
  "LLY",
  "TMO",
  "NFLX",
  "ABT",
  "NKE",
  "CRM",
  "DHR",
  "VZ",
  "TXN",
  "WMT",
  "NEE",
  "ORCL",
  "INTC",
  "PM",
  "BMY",
  "UPS",
  "RTX",
  "QCOM",
  "AMD",
  "INTU",
  "HON",
  "CMCSA",
  "AMGN",
  "UNP",
  "IBM",
  "BA",
  "LOW",
  "SBUX",
  "CAT",
  "GE",
  "SPGI",
  "DE",
  "AMAT",
  "PLD",
  "LMT",
  "GS",
  "BLK",
  "AXP",
  "MDT",
  "GILD",
  "ADI",
  "ISRG",
  "CI",
  "TJX",
  "MMC",
  "C",
  "BKNG",
  "AMT",
  "SYK",
  "CB",
  "ZTS",
  "VRTX",
  "MO",
  "REGN",
  "DUK",
  "PGR",
  "SO",
  "EOG",
  "CME",
  "MMM",
  "ITW",
  "SCHW",
  "NOC",
  "APD",
  "WM",
  "CL",
  "BSX",
  "ICE",
  "MU",
  "SLB",
  "PYPL",
  "AON",
  "FDX",
  // Top 101-200
  "TMUS",
  "MS",
  "EQIX",
  "MCO",
  "BDX",
  "ADP",
  "USB",
  "TGT",
  "LRCX",
  "PNC",
  "SHW",
  "ATVI",
  "FISV",
  "EL",
  "NSC",
  "MDLZ",
  "GM",
  "HUM",
  "GPN",
  "MAR",
  "AIG",
  "MCK",
  "EMR",
  "D",
  "KLAC",
  "SNPS",
  "ORLY",
  "ADSK",
  "HCA",
  "ECL",
  "CSX",
  "ROP",
  "IQV",
  "AFL",
  "EW",
  "PSA",
  "AEP",
  "ILMN",
  "SPG",
  "NXPI",
  "CCI",
  "FCX",
  "KMB",
  "CARR",
  "CMG",
  "MCHP",
  "WELL",
  "DD",
  "MNST",
  "AZO",
  "DLR",
  "MSI",
  "PAYX",
  "STZ",
  "ROST",
  "ALL",
  "APH",
  "PPG",
  "NEM",
  "APTV",
  "HLT",
  "SRE",
  "F",
  "CDNS",
  "CTVA",
  "FTNT",
  "TEL",
  "IDXX",
  "KHC",
  "SYY",
  "DOW",
  "EA",
  "GIS",
  "YUM",
  "PRU",
  "BK",
  "O",
  "WBA",
  "ANSS",
  "CTSH",
  "GLW",
  "BIIB",
  "DXCM",
  "CTAS",
  "ED",
  "WEC",
  "XEL",
  "IT",
  "EBAY",
  "AMP",
  "HPQ",
  "DHI",
  "KEYS",
  "MTD",
  "ETN",
  "PCAR",
  "FAST",
  "VRSK",
  "AVB",
  "KMI"
];
async function getTop250Cryptos(logger) {
  try {
    logger?.info("\u{1F50D} [GetSellSignals] Fetching top 250 cryptocurrencies from CoinGecko");
    const url = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=250&page=1&sparkline=false";
    const response = await fetch(url);
    if (!response.ok) {
      logger?.warn("\u26A0\uFE0F [GetSellSignals] Failed to fetch top 250 cryptos, using fallback list");
      return ["BTC", "ETH", "USDT", "BNB", "SOL", "USDC", "XRP", "DOGE", "ADA", "AVAX", "TRX", "DOT", "MATIC", "LINK", "SHIB", "UNI", "ATOM", "LTC", "XMR", "BCH"];
    }
    const data = await response.json();
    const cryptoSymbols = data.map((coin) => coin.symbol.toUpperCase());
    logger?.info(`\u2705 [GetSellSignals] Fetched ${cryptoSymbols.length} crypto symbols`);
    return cryptoSymbols;
  } catch (error) {
    logger?.warn("\u26A0\uFE0F [GetSellSignals] Error fetching top 250 cryptos:", error.message);
    return ["BTC", "ETH", "USDT", "BNB", "SOL", "USDC", "XRP", "DOGE", "ADA", "AVAX", "TRX", "DOT", "MATIC", "LINK", "SHIB", "UNI", "ATOM", "LTC", "XMR", "BCH"];
  }
}
const getSellSignals = createTool({
  id: "get-sell-signals",
  description: "Scans stocks and/or crypto for sell warnings with configurable filters",
  inputSchema: z.object({
    assetType: z.enum(["STOCK", "CRYPTO", "BOTH"]).optional().default("BOTH").describe("Filter by asset type"),
    limit: z.number().optional().default(200).describe("Max assets to scan per type (default 200)")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    sellWarnings: z.array(z.object({
      ticker: z.string(),
      type: z.string(),
      price: z.number(),
      signal: z.string(),
      reason: z.string(),
      rsi: z.number().optional(),
      priceChange24h: z.number().optional()
    })).optional(),
    scannedCount: z.number(),
    totalAssets: z.number(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { assetType = "BOTH", limit = 50 } = context;
    logger?.info("\u{1F50D} [GetSellSignals] Starting scan", { assetType, limit });
    const sellWarnings = [];
    let scannedCount = 0;
    try {
      let allAssets = [];
      if (assetType === "STOCK" || assetType === "BOTH") {
        const stocksToScan = TOP_200_STOCKS.slice(0, limit);
        allAssets.push(...stocksToScan.map((ticker) => ({ ticker, type: "STOCK" })));
      }
      if (assetType === "CRYPTO" || assetType === "BOTH") {
        const cryptoSymbols = await getTop250Cryptos(logger);
        const cryptosToScan = cryptoSymbols.slice(0, limit);
        allAssets.push(...cryptosToScan.map((ticker) => ({ ticker, type: "CRYPTO" })));
      }
      logger?.info(`\u{1F4CA} [GetSellSignals] Total assets to scan: ${allAssets.length}`);
      for (const asset of allAssets) {
        try {
          logger?.info(`\u{1F4CA} [GetSellSignals] Scanning ${asset.ticker} (${asset.type})`);
          const result = await scanAsset.execute({
            context: {
              symbol: asset.ticker,
              assetType: asset.type
            },
            runtimeContext: new RuntimeContext(),
            mastra
          });
          scannedCount++;
          await new Promise((resolve) => setTimeout(resolve, 1e3));
          if (!result.success) {
            logger?.warn(`\u26A0\uFE0F [GetSellSignals] Failed to scan ${asset.ticker}`);
            continue;
          }
          let isSellSignal = false;
          let reason = "";
          if (result.signal?.includes("SELL")) {
            isSellSignal = true;
            const rec = result.recommendation || "";
            if (rec.includes("At resistance ceiling")) {
              reason = "At dynamic resistance ceiling";
            } else if (rec.includes("Within 2% of resistance")) {
              reason = "Near resistance ceiling";
            } else if (rec.includes("overbought")) {
              reason = "RSI overbought - sell warning";
            } else {
              reason = "Multiple sell signals detected";
            }
            if (result.rsi && result.rsi > 70) {
              reason += ` | RSI: ${result.rsi.toFixed(1)}`;
            }
          }
          if (isSellSignal && result.currentPrice) {
            sellWarnings.push({
              ticker: asset.ticker,
              type: asset.type,
              price: result.currentPrice,
              signal: "SELL",
              reason,
              rsi: result.rsi,
              priceChange24h: result.changePercent
            });
            logger?.info(`\u26A0\uFE0F [GetSellSignals] SELL warning: ${asset.ticker}`, { reason });
          }
        } catch (error) {
          logger?.warn(`\u26A0\uFE0F [GetSellSignals] Error scanning ${asset.ticker}:`, error.message);
        }
      }
      logger?.info(`\u{1F3AF} [GetSellSignals] Scan complete: ${sellWarnings.length} sell warnings found out of ${scannedCount} scanned`);
      return {
        success: true,
        sellWarnings,
        scannedCount,
        totalAssets: allAssets.length
      };
    } catch (error) {
      logger?.error("\u274C [GetSellSignals] Fatal error", { error: error.message });
      return {
        success: false,
        scannedCount,
        totalAssets: 0,
        error: error.message
      };
    }
  }
});

const { Pool: Pool$3 } = pg;
const pool$3 = new Pool$3({
  connectionString: process.env.DATABASE_URL
});
const addHolding = createTool({
  id: "add-holding",
  description: "Add a stock or crypto to your holdings watchlist for sell monitoring",
  inputSchema: z.object({
    symbol: z.string().describe("Ticker symbol (e.g., AMD, SOL, BTC)"),
    assetType: z.enum(["STOCK", "CRYPTO"]).describe("Asset type"),
    notes: z.string().optional().describe("Optional notes about this holding")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    message: z.string(),
    symbol: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { symbol, assetType, notes } = context;
    try {
      logger?.info("\u2795 [AddHolding] Adding to holdings", { symbol, assetType });
      const existing = await pool$3.query(
        "SELECT symbol FROM holdings WHERE UPPER(symbol) = UPPER($1)",
        [symbol]
      );
      if (existing.rows.length > 0) {
        logger?.warn("\u26A0\uFE0F [AddHolding] Already in holdings", { symbol });
        return {
          success: false,
          message: `${symbol} is already in your holdings watchlist.`
        };
      }
      await pool$3.query(
        "INSERT INTO holdings (symbol, asset_type, notes) VALUES (UPPER($1), $2, $3)",
        [symbol, assetType, notes || null]
      );
      logger?.info("\u2705 [AddHolding] Added successfully", { symbol });
      return {
        success: true,
        message: `\u2705 Added ${symbol} (${assetType}) to your holdings. I'll monitor it hourly for SELL signals.`,
        symbol: symbol.toUpperCase()
      };
    } catch (error) {
      logger?.error("\u274C [AddHolding] Error", { error: error.message });
      return {
        success: false,
        message: `Error adding ${symbol}: ${error.message}`
      };
    }
  }
});
const removeHolding = createTool({
  id: "remove-holding",
  description: "Remove a stock or crypto from your holdings watchlist",
  inputSchema: z.object({
    symbol: z.string().describe("Ticker symbol to remove")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    message: z.string()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { symbol } = context;
    try {
      logger?.info("\u2796 [RemoveHolding] Removing from holdings", { symbol });
      const result = await pool$3.query(
        "DELETE FROM holdings WHERE UPPER(symbol) = UPPER($1)",
        [symbol]
      );
      if (result.rowCount === 0) {
        logger?.warn("\u26A0\uFE0F [RemoveHolding] Not found in holdings", { symbol });
        return {
          success: false,
          message: `${symbol} was not found in your holdings.`
        };
      }
      logger?.info("\u2705 [RemoveHolding] Removed successfully", { symbol });
      return {
        success: true,
        message: `\u2705 Removed ${symbol} from your holdings watchlist.`
      };
    } catch (error) {
      logger?.error("\u274C [RemoveHolding] Error", { error: error.message });
      return {
        success: false,
        message: `Error removing ${symbol}: ${error.message}`
      };
    }
  }
});
const listHoldings = createTool({
  id: "list-holdings",
  description: "List all assets in your holdings watchlist",
  inputSchema: z.object({}),
  outputSchema: z.object({
    success: z.boolean(),
    holdings: z.array(z.object({
      symbol: z.string(),
      assetType: z.string(),
      addedAt: z.string(),
      notes: z.string().optional()
    })).optional(),
    message: z.string()
  }),
  execute: async ({ mastra }) => {
    const logger = mastra?.getLogger();
    try {
      logger?.info("\u{1F4CB} [ListHoldings] Fetching holdings");
      const result = await pool$3.query(
        "SELECT symbol, asset_type, added_at, notes FROM holdings ORDER BY added_at DESC"
      );
      const holdings = result.rows.map((row) => ({
        symbol: row.symbol,
        assetType: row.asset_type,
        addedAt: row.added_at,
        notes: row.notes
      }));
      logger?.info("\u2705 [ListHoldings] Retrieved holdings", { count: holdings.length });
      if (holdings.length === 0) {
        return {
          success: true,
          holdings: [],
          message: 'Your holdings watchlist is empty. Use "addhold <ticker>" to add assets.'
        };
      }
      return {
        success: true,
        holdings,
        message: `You have ${holdings.length} asset(s) in your watchlist.`
      };
    } catch (error) {
      logger?.error("\u274C [ListHoldings] Error", { error: error.message });
      return {
        success: false,
        message: `Error fetching holdings: ${error.message}`
      };
    }
  }
});

const KNOWN_STOCK_TICKERS = [
  "AMD",
  "NVDA",
  "TSLA",
  "AAPL",
  "MSFT",
  "GOOGL",
  "AMZN",
  "META",
  "NFLX",
  "PYPL",
  "INTC",
  "QCOM",
  "MU",
  "AVGO",
  "TXN",
  "ADBE",
  "CRM",
  "ORCL"
];
async function handleTickerRequest(mastra, triggerInfo) {
  const logger = mastra.getLogger();
  const { userName, message } = triggerInfo.params;
  logger?.info("\u{1F916} [TickerBot] Received message", { userName, message });
  const input = message.trim().replace(/^\/+/, "");
  const inputUpper = input.toUpperCase();
  logger?.info("\u{1F50D} [TickerBot] Processing command", { input, inputUpper, length: input.length });
  if (inputUpper === "NEW") {
    return await handleNewCoinsCommand(mastra);
  }
  if (inputUpper === "UPCOMING" || inputUpper === "TRENDING") {
    return await handleTrendingCoinsCommand(mastra);
  }
  if (inputUpper === "BUYCOIN") {
    return await handleBuyCoinCommand(mastra);
  }
  if (inputUpper === "BUYSTOCK") {
    return await handleBuyStockCommand(mastra);
  }
  if (inputUpper === "BUY") {
    await sendTelegramAlert.execute({
      context: {
        message: `\u{1F4A1} *Use these commands instead:*

\u2022 "buycoin" - Scan crypto for buy signals
\u2022 "buystock" - Scan stocks for buy signals

(Scanning 200 assets at once was too expensive!)`
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
    return;
  }
  if (inputUpper === "SELL") {
    return await handleSellSignalsCommand(mastra);
  }
  if (inputUpper.startsWith("ADDHOLD ") || inputUpper.startsWith("ADD HOLD ")) {
    const ticker2 = inputUpper.replace(/^(ADDHOLD|ADD HOLD)\s+/, "").trim();
    return await handleAddHoldingCommand(mastra, ticker2);
  }
  if (inputUpper.startsWith("REMOVEHOLD ") || inputUpper.startsWith("REMOVE HOLD ")) {
    const ticker2 = inputUpper.replace(/^(REMOVEHOLD|REMOVE HOLD)\s+/, "").trim();
    return await handleRemoveHoldingCommand(mastra, ticker2);
  }
  if (inputUpper === "HOLDINGS" || inputUpper === "MYHOLDINGS") {
    return await handleListHoldingsCommand(mastra);
  }
  const ticker = inputUpper;
  if (!ticker || ticker.length === 0) {
    await sendTelegramAlert.execute({
      context: {
        message: '\u274C Please send:\n\u2022 A ticker (AMD, BTC, XRP, etc.)\n\u2022 "holdings" - view your watchlist\n\u2022 "buycoin" - crypto ready to buy\n\u2022 "buystock" - stocks ready to buy\n\u2022 "sell" - sell warnings\n\u2022 "new" - newly listed coins\n\u2022 "trending" - trending coins'
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
    return;
  }
  if (ticker.length > 10) {
    await sendTelegramAlert.execute({
      context: {
        message: "\u274C Ticker symbol too long. Please send a valid stock or crypto ticker."
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
    return;
  }
  logger?.info("\u{1F50D} [TickerBot] Analyzing ticker", { ticker });
  await sendTelegramAlert.execute({
    context: {
      message: `\u{1F50D} Analyzing ${ticker}... Please wait.`
    },
    runtimeContext: new RuntimeContext(),
    mastra
  });
  let assetType = KNOWN_STOCK_TICKERS.includes(ticker) ? "STOCK" : "CRYPTO";
  logger?.info("\u{1F4CA} [TickerBot] Detected asset type", { ticker, assetType });
  try {
    let result = await scanAsset.execute({
      context: {
        symbol: ticker,
        assetType
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
    if (!result.success) {
      const fallbackType = assetType === "STOCK" ? "CRYPTO" : "STOCK";
      logger?.warn(`\u26A0\uFE0F [TickerBot] ${assetType} scan failed, trying ${fallbackType}`, { ticker });
      result = await scanAsset.execute({
        context: {
          symbol: ticker,
          assetType: fallbackType
        },
        runtimeContext: new RuntimeContext(),
        mastra
      });
      if (result.success) {
        assetType = fallbackType;
        logger?.info(`\u2705 [TickerBot] Found ${ticker} as ${fallbackType}`);
      }
    }
    if (!result.success) {
      logger?.error("\u274C [TickerBot] Both scans failed", { ticker, error: result.error });
      await sendTelegramAlert.execute({
        context: {
          message: `\u274C *${ticker} Not Found*

Couldn't find data for "${ticker}" as either stock or crypto.

\u{1F4A1} Please verify the ticker symbol is correct.`
        },
        runtimeContext: new RuntimeContext(),
        mastra
      });
      return;
    }
    const { currentPrice, signal, recommendation, rsi, changePercent } = result;
    let responseMessage = `\u{1F4CA} *${ticker} ${assetType === "CRYPTO" ? "Crypto" : "Stock"} Analysis*

`;
    responseMessage += `\u{1F4B0} *Current Price:* $${currentPrice?.toFixed(2)}
`;
    if (changePercent !== void 0 && changePercent !== null) {
      const arrow = changePercent >= 0 ? "\u{1F4C8}" : "\u{1F4C9}";
      responseMessage += `${arrow} *24h Change:* ${changePercent >= 0 ? "+" : ""}${changePercent.toFixed(2)}%
`;
    }
    if (rsi !== null && rsi !== void 0) {
      const rsiEmoji = rsi < 30 ? "\u{1F525}" : rsi > 70 ? "\u26A0\uFE0F" : "\u{1F4CA}";
      responseMessage += `${rsiEmoji} *RSI:* ${rsi.toFixed(1)}`;
      if (rsi < 30) responseMessage += " (Oversold)";
      else if (rsi > 70) responseMessage += " (Overbought)";
      responseMessage += "\n";
    }
    if (signal) {
      responseMessage += `
${signal}
`;
    }
    if (recommendation) {
      responseMessage += `
\u{1F4A1} ${recommendation}`;
    }
    logger?.info("\u2705 [TickerBot] Sending analysis results", { ticker, signal });
    await sendTelegramAlert.execute({
      context: {
        message: responseMessage
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
  } catch (error) {
    logger?.error("\u274C [TickerBot] Unexpected error", { ticker, error });
    await sendTelegramAlert.execute({
      context: {
        message: `\u274C *Error analyzing ${ticker}*

An unexpected error occurred. Please try again later.`
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
  }
}
async function handleNewCoinsCommand(mastra) {
  const logger = mastra.getLogger();
  logger?.info("\u{1F195} [TickerBot] Processing NEW command");
  await sendTelegramAlert.execute({
    context: {
      message: "\u{1F50D} Fetching newly listed coins... Please wait."
    },
    runtimeContext: new RuntimeContext(),
    mastra
  });
  try {
    const result = await getNewCoins.execute({
      context: { limit: 10 },
      runtimeContext: new RuntimeContext(),
      mastra
    });
    if (!result.success || !result.coins || result.coins.length === 0) {
      await sendTelegramAlert.execute({
        context: {
          message: `\u274C Could not fetch new coins.

${result.error || "No data available"}`
        },
        runtimeContext: new RuntimeContext(),
        mastra
      });
      return;
    }
    let responseMessage = `\u{1F195} *Recently Listed Coins*

`;
    result.coins.forEach((coin, index) => {
      const priceChange = coin.priceChange24h;
      const changeEmoji = priceChange && priceChange > 0 ? "\u{1F4C8}" : priceChange && priceChange < 0 ? "\u{1F4C9}" : "\u27A1\uFE0F";
      responseMessage += `${index + 1}. *${coin.symbol}* (${coin.name})
`;
      responseMessage += `   \u{1F4B0} $${coin.currentPrice?.toFixed(6) || "N/A"}
`;
      if (priceChange !== null && priceChange !== void 0) {
        responseMessage += `   ${changeEmoji} ${priceChange >= 0 ? "+" : ""}${priceChange.toFixed(2)}% (24h)
`;
      }
      if (coin.marketCap) {
        responseMessage += `   \u{1F4CA} MCap: $${(coin.marketCap / 1e6).toFixed(2)}M
`;
      }
      responseMessage += `
`;
    });
    responseMessage += `\u{1F4A1} *Tip:* Send any ticker symbol to get detailed analysis!`;
    await sendTelegramAlert.execute({
      context: {
        message: responseMessage
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
    logger?.info("\u2705 [TickerBot] NEW command completed");
  } catch (error) {
    logger?.error("\u274C [TickerBot] NEW command failed", { error: error.message });
    await sendTelegramAlert.execute({
      context: {
        message: `\u274C Error fetching new coins: ${error.message}`
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
  }
}
async function handleTrendingCoinsCommand(mastra) {
  const logger = mastra.getLogger();
  logger?.info("\u{1F4C8} [TickerBot] Processing TRENDING/UPCOMING command");
  await sendTelegramAlert.execute({
    context: {
      message: "\u{1F50D} Fetching trending coins... Please wait."
    },
    runtimeContext: new RuntimeContext(),
    mastra
  });
  try {
    const result = await getTrendingCoins.execute({
      context: {},
      runtimeContext: new RuntimeContext(),
      mastra
    });
    if (!result.success || !result.trending || result.trending.length === 0) {
      await sendTelegramAlert.execute({
        context: {
          message: `\u274C Could not fetch trending coins.

${result.error || "No data available"}`
        },
        runtimeContext: new RuntimeContext(),
        mastra
      });
      return;
    }
    let responseMessage = `\u{1F4C8} *Trending Coins on CoinGecko*

`;
    responseMessage += `_These coins are currently trending with high community engagement._

`;
    result.trending.forEach((coin, index) => {
      const priceChange = coin.priceChange24h;
      const changeEmoji = priceChange && priceChange > 0 ? "\u{1F4C8}" : priceChange && priceChange < 0 ? "\u{1F4C9}" : "\u27A1\uFE0F";
      responseMessage += `${index + 1}. *${coin.symbol}* (${coin.name})
`;
      if (coin.priceUsd) {
        responseMessage += `   \u{1F4B0} $${coin.priceUsd.toFixed(6)}
`;
      }
      if (priceChange !== null && priceChange !== void 0) {
        responseMessage += `   ${changeEmoji} ${priceChange >= 0 ? "+" : ""}${priceChange.toFixed(2)}% (24h)
`;
      }
      if (coin.description) {
        responseMessage += `   \u{1F4CA} ${coin.description}
`;
      }
      responseMessage += `
`;
    });
    responseMessage += `\u{1F4A1} *Tip:* Send any ticker to analyze it in detail!`;
    await sendTelegramAlert.execute({
      context: {
        message: responseMessage
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
    logger?.info("\u2705 [TickerBot] TRENDING command completed");
  } catch (error) {
    logger?.error("\u274C [TickerBot] TRENDING command failed", { error: error.message });
    await sendTelegramAlert.execute({
      context: {
        message: `\u274C Error fetching trending coins: ${error.message}`
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
  }
}
async function handleBuyCoinCommand(mastra) {
  const logger = mastra.getLogger();
  logger?.info("\u{1FA99} [TickerBot] Processing BUYCOIN command");
  await sendTelegramAlert.execute({
    context: {
      message: "\u{1F50D} Scanning TOP 30 crypto for buy opportunities...\n\n\u23F3 This may take 1-2 minutes."
    },
    runtimeContext: new RuntimeContext(),
    mastra
  });
  try {
    const result = await getBuySignals.execute({
      context: { assetType: "CRYPTO", limit: 30 },
      runtimeContext: new RuntimeContext(),
      mastra
    });
    if (!result.success) {
      await sendTelegramAlert.execute({
        context: {
          message: `\u274C Error scanning crypto.

${result.error || "Unknown error"}`
        },
        runtimeContext: new RuntimeContext(),
        mastra
      });
      return;
    }
    const opportunities = result.buyOpportunities || [];
    if (opportunities.length === 0) {
      await sendTelegramAlert.execute({
        context: {
          message: `\u{1F4CA} *Crypto Scan Complete*

\u2705 Scanned ${result.scannedCount}/${result.totalAssets} crypto

\u274C *No buy signals* right now.

\u{1F4A1} Try "new" for newly listed coins or send a ticker for detailed analysis!`
        },
        runtimeContext: new RuntimeContext(),
        mastra
      });
      return;
    }
    let responseMessage = `\u{1FA99} *CRYPTO BUY SIGNALS*

`;
    responseMessage += `\u2705 Scanned ${result.scannedCount}/${result.totalAssets} crypto
`;
    responseMessage += `\u{1F3AF} Found ${opportunities.length} buy opportunities:

`;
    opportunities.forEach((opp, index) => {
      responseMessage += `${index + 1}. *${opp.ticker}*
`;
      responseMessage += `   \u{1F4B0} $${opp.price.toFixed(8)}
`;
      if (opp.rsi) {
        responseMessage += `   \u{1F4C9} RSI: ${opp.rsi.toFixed(1)}
`;
      }
      if (opp.priceChange24h !== null && opp.priceChange24h !== void 0) {
        const changeEmoji = opp.priceChange24h >= 0 ? "\u{1F4C8}" : "\u{1F4C9}";
        responseMessage += `   ${changeEmoji} 24h: ${opp.priceChange24h >= 0 ? "+" : ""}${opp.priceChange24h.toFixed(2)}%
`;
      }
      responseMessage += `   \u2705 ${opp.reason}

`;
    });
    responseMessage += `\u26A0\uFE0F *High-risk capital only!*`;
    await sendTelegramAlert.execute({
      context: {
        message: responseMessage
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
    logger?.info(`\u2705 [TickerBot] BUYCOIN completed with ${opportunities.length} signals`);
  } catch (error) {
    logger?.error("\u274C [TickerBot] BUYCOIN failed", { error: error.message });
    await sendTelegramAlert.execute({
      context: {
        message: `\u274C Error: ${error.message}`
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
  }
}
async function handleBuyStockCommand(mastra) {
  const logger = mastra.getLogger();
  logger?.info("\u{1F4CA} [TickerBot] Processing BUYSTOCK command");
  await sendTelegramAlert.execute({
    context: {
      message: "\u{1F50D} Scanning TOP 30 stocks for buy opportunities...\n\n\u23F3 This may take 1-2 minutes."
    },
    runtimeContext: new RuntimeContext(),
    mastra
  });
  try {
    const result = await getBuySignals.execute({
      context: { assetType: "STOCK", limit: 30 },
      runtimeContext: new RuntimeContext(),
      mastra
    });
    if (!result.success) {
      await sendTelegramAlert.execute({
        context: {
          message: `\u274C Error scanning stocks.

${result.error || "Unknown error"}`
        },
        runtimeContext: new RuntimeContext(),
        mastra
      });
      return;
    }
    const opportunities = result.buyOpportunities || [];
    if (opportunities.length === 0) {
      await sendTelegramAlert.execute({
        context: {
          message: `\u{1F4CA} *Stock Scan Complete*

\u2705 Scanned ${result.scannedCount}/${result.totalAssets} stocks

\u274C *No buy signals* right now.

\u{1F4A1} Send a ticker (e.g., AMD, NVDA) for detailed analysis!`
        },
        runtimeContext: new RuntimeContext(),
        mastra
      });
      return;
    }
    let responseMessage = `\u{1F4CA} *STOCK BUY SIGNALS*

`;
    responseMessage += `\u2705 Scanned ${result.scannedCount}/${result.totalAssets} stocks
`;
    responseMessage += `\u{1F3AF} Found ${opportunities.length} buy opportunities:

`;
    opportunities.forEach((opp, index) => {
      responseMessage += `${index + 1}. *${opp.ticker}*
`;
      responseMessage += `   \u{1F4B0} $${opp.price.toFixed(2)}
`;
      if (opp.rsi) {
        responseMessage += `   \u{1F4C9} RSI: ${opp.rsi.toFixed(1)}
`;
      }
      if (opp.priceChange24h !== null && opp.priceChange24h !== void 0) {
        const changeEmoji = opp.priceChange24h >= 0 ? "\u{1F4C8}" : "\u{1F4C9}";
        responseMessage += `   ${changeEmoji} 24h: ${opp.priceChange24h >= 0 ? "+" : ""}${opp.priceChange24h.toFixed(2)}%
`;
      }
      responseMessage += `   \u2705 ${opp.reason}

`;
    });
    responseMessage += `\u26A0\uFE0F *Do your own research!*`;
    await sendTelegramAlert.execute({
      context: {
        message: responseMessage
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
    logger?.info(`\u2705 [TickerBot] BUYSTOCK completed with ${opportunities.length} signals`);
  } catch (error) {
    logger?.error("\u274C [TickerBot] BUYSTOCK failed", { error: error.message });
    await sendTelegramAlert.execute({
      context: {
        message: `\u274C Error: ${error.message}`
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
  }
}
async function handleAddHoldingCommand(mastra, ticker) {
  const logger = mastra.getLogger();
  logger?.info("\u2795 [TickerBot] Processing ADDHOLD command", { ticker });
  if (!ticker || ticker.length === 0) {
    await sendTelegramAlert.execute({
      context: {
        message: "\u274C Usage: addhold <ticker>\n\nExample: addhold AMD"
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
    return;
  }
  const assetType = KNOWN_STOCK_TICKERS.includes(ticker) ? "STOCK" : "CRYPTO";
  const result = await addHolding.execute({
    context: {
      symbol: ticker,
      assetType
    },
    runtimeContext: new RuntimeContext(),
    mastra
  });
  await sendTelegramAlert.execute({
    context: {
      message: result.message
    },
    runtimeContext: new RuntimeContext(),
    mastra
  });
  logger?.info(`\u2705 [TickerBot] ADDHOLD completed`, { ticker, success: result.success });
}
async function handleRemoveHoldingCommand(mastra, ticker) {
  const logger = mastra.getLogger();
  logger?.info("\u2796 [TickerBot] Processing REMOVEHOLD command", { ticker });
  if (!ticker || ticker.length === 0) {
    await sendTelegramAlert.execute({
      context: {
        message: "\u274C Usage: removehold <ticker>\n\nExample: removehold AMD"
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
    return;
  }
  const result = await removeHolding.execute({
    context: {
      symbol: ticker
    },
    runtimeContext: new RuntimeContext(),
    mastra
  });
  await sendTelegramAlert.execute({
    context: {
      message: result.message
    },
    runtimeContext: new RuntimeContext(),
    mastra
  });
  logger?.info(`\u2705 [TickerBot] REMOVEHOLD completed`, { ticker, success: result.success });
}
async function handleListHoldingsCommand(mastra) {
  const logger = mastra.getLogger();
  logger?.info("\u{1F4CB} [TickerBot] Processing HOLDINGS command");
  const result = await listHoldings.execute({
    context: {},
    runtimeContext: new RuntimeContext(),
    mastra
  });
  if (!result.success || !result.holdings || result.holdings.length === 0) {
    await sendTelegramAlert.execute({
      context: {
        message: result.message
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
    return;
  }
  await sendTelegramAlert.execute({
    context: {
      message: `\u{1F50D} Fetching live metrics for ${result.holdings.length} asset(s)... Please wait.`
    },
    runtimeContext: new RuntimeContext(),
    mastra
  });
  let responseMessage = `\u{1F4CA} *Your Holdings Watchlist*

`;
  for (let i = 0; i < result.holdings.length; i++) {
    const holding = result.holdings[i];
    const typeEmoji = holding.assetType === "STOCK" ? "\u{1F4CA}" : "\u{1FA99}";
    if (i > 0) {
      logger?.info("\u23F3 [TickerBot] Waiting 3 seconds between holdings to avoid rate limits...");
      await new Promise((resolve) => setTimeout(resolve, 3e3));
    }
    logger?.info("\u{1F50D} [TickerBot] Fetching metrics for holding", { symbol: holding.symbol });
    try {
      const scanResult = await scanAsset.execute({
        context: {
          symbol: holding.symbol,
          assetType: holding.assetType
        },
        runtimeContext: new RuntimeContext(),
        mastra
      });
      if (scanResult.success && scanResult.currentPrice) {
        responseMessage += `${i + 1}. ${typeEmoji} *${holding.symbol}* (${holding.assetType})
`;
        responseMessage += `   \u{1F4B0} $${scanResult.currentPrice.toFixed(holding.assetType === "CRYPTO" ? 6 : 2)}
`;
        if (scanResult.changePercent !== void 0 && scanResult.changePercent !== null) {
          const arrow = scanResult.changePercent >= 0 ? "\u{1F4C8}" : "\u{1F4C9}";
          responseMessage += `   ${arrow} 24h: ${scanResult.changePercent >= 0 ? "+" : ""}${scanResult.changePercent.toFixed(2)}%
`;
        }
        if (scanResult.rsi !== null && scanResult.rsi !== void 0) {
          const rsiEmoji = scanResult.rsi < 30 ? "\u{1F525}" : scanResult.rsi > 70 ? "\u26A0\uFE0F" : "\u{1F4CA}";
          responseMessage += `   ${rsiEmoji} RSI: ${scanResult.rsi.toFixed(1)}`;
          if (scanResult.rsi < 30) responseMessage += " (Oversold)";
          else if (scanResult.rsi > 70) responseMessage += " (Overbought)";
          responseMessage += "\n";
        }
        if (scanResult.signal) {
          responseMessage += `   ${scanResult.signal}
`;
        }
        if (holding.notes) {
          responseMessage += `   \u{1F4DD} ${holding.notes}
`;
        }
        const addedDate = new Date(holding.addedAt);
        responseMessage += `   \u{1F4C5} Added: ${addedDate.toLocaleDateString()}
`;
      } else {
        responseMessage += `${i + 1}. ${typeEmoji} *${holding.symbol}* (${holding.assetType})
`;
        responseMessage += `   \u26A0\uFE0F Unable to fetch live data
`;
        if (holding.notes) {
          responseMessage += `   \u{1F4DD} ${holding.notes}
`;
        }
        const addedDate = new Date(holding.addedAt);
        responseMessage += `   \u{1F4C5} Added: ${addedDate.toLocaleDateString()}
`;
      }
      responseMessage += `
`;
    } catch (error) {
      logger?.error("\u274C [TickerBot] Error fetching metrics for holding", {
        symbol: holding.symbol,
        error: error.message
      });
      responseMessage += `${i + 1}. ${typeEmoji} *${holding.symbol}* (${holding.assetType})
`;
      responseMessage += `   \u26A0\uFE0F Error fetching data

`;
    }
  }
  responseMessage += `\u{1F4A1} *Tip:* Use "removehold <ticker>" to remove assets.`;
  await sendTelegramAlert.execute({
    context: {
      message: responseMessage
    },
    runtimeContext: new RuntimeContext(),
    mastra
  });
  logger?.info(`\u2705 [TickerBot] HOLDINGS completed with live metrics`, { count: result.holdings.length });
}
async function handleSellSignalsCommand(mastra) {
  const logger = mastra.getLogger();
  logger?.info("\u{1F4C9} [TickerBot] Processing SELL command");
  await sendTelegramAlert.execute({
    context: {
      message: "\u{1F50D} Scanning TOP 50 stocks + TOP 50 crypto for sell warnings...\n\n\u23F3 This will take 1-2 minutes."
    },
    runtimeContext: new RuntimeContext(),
    mastra
  });
  try {
    const result = await getSellSignals.execute({
      context: { assetType: "BOTH", limit: 50 },
      runtimeContext: new RuntimeContext(),
      mastra
    });
    if (!result.success) {
      await sendTelegramAlert.execute({
        context: {
          message: `\u274C Error scanning for sell signals.

${result.error || "Unknown error"}`
        },
        runtimeContext: new RuntimeContext(),
        mastra
      });
      return;
    }
    const warnings = result.sellWarnings || [];
    if (warnings.length === 0) {
      await sendTelegramAlert.execute({
        context: {
          message: `\u{1F4CA} *Market Scan Complete*

\u2705 Scanned ${result.scannedCount}/${result.totalAssets} assets (top 50 stocks + top 50 crypto)

\u2705 *No sell warnings* right now.

I'm looking for:
\u2022 RSI > 70 (overbought)
\u2022 Strong downtrends (< -5%)
\u2022 Sell recommendations

\u{1F4A1} All clear! Try again later or check specific tickers.`
        },
        runtimeContext: new RuntimeContext(),
        mastra
      });
      return;
    }
    let responseMessage = `\u26A0\uFE0F *SELL WARNINGS DETECTED!*

`;
    responseMessage += `\u2705 Scanned ${result.scannedCount}/${result.totalAssets} assets
`;
    responseMessage += `\u26A0\uFE0F Found ${warnings.length} sell warnings:

`;
    warnings.forEach((warning, index) => {
      const typeEmoji = warning.type === "STOCK" ? "\u{1F4CA}" : "\u{1FA99}";
      responseMessage += `${index + 1}. ${typeEmoji} *${warning.ticker}* (${warning.type})
`;
      responseMessage += `   \u{1F4B0} Price: $${warning.price.toFixed(warning.type === "CRYPTO" ? 6 : 2)}
`;
      if (warning.rsi) {
        responseMessage += `   \u{1F4C8} RSI: ${warning.rsi.toFixed(1)}
`;
      }
      if (warning.priceChange24h !== null && warning.priceChange24h !== void 0) {
        const changeEmoji = warning.priceChange24h >= 0 ? "\u{1F4C8}" : "\u{1F4C9}";
        responseMessage += `   ${changeEmoji} 24h: ${warning.priceChange24h >= 0 ? "+" : ""}${warning.priceChange24h.toFixed(2)}%
`;
      }
      responseMessage += `   \u26A0\uFE0F ${warning.reason}

`;
    });
    responseMessage += `\u{1F4A1} *Consider taking profits or reducing exposure.*`;
    await sendTelegramAlert.execute({
      context: {
        message: responseMessage
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
    logger?.info(`\u2705 [TickerBot] SELL command completed with ${warnings.length} warnings`);
  } catch (error) {
    logger?.error("\u274C [TickerBot] SELL command failed", { error: error.message });
    await sendTelegramAlert.execute({
      context: {
        message: `\u274C Error scanning for sell signals: ${error.message}`
      },
      runtimeContext: new RuntimeContext(),
      mastra
    });
  }
}
const registerTickerBot = (mastra) => {
  const logger = mastra.getLogger();
  const pollingEnabled = process.env.ENABLE_TELEGRAM_POLLING === "true";
  if (!pollingEnabled) {
    logger?.info("\u2139\uFE0F [TickerBot] Telegram polling disabled (set ENABLE_TELEGRAM_POLLING=true secret to enable)");
    return [];
  }
  logger?.info("\u2705 [TickerBot] Starting Telegram polling bot");
  startTelegramPolling(mastra, handleTickerRequest);
  return [];
};

const getWalletActivity = createTool({
  id: "get-wallet-activity",
  description: "Fetches recent transaction history for a Solana wallet address using Helius RPC API. Returns up to 100 recent transactions including token transfers.",
  inputSchema: z.object({
    walletAddress: z.string().describe("The Solana wallet address to fetch activity for")
  }),
  outputSchema: z.object({
    transactions: z.array(z.any()).describe("Array of wallet transactions"),
    error: z.string().optional().describe("Error message if request fails")
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F50D} [GetWalletActivity] Starting wallet activity fetch", {
      wallet: context.walletAddress
    });
    const HELIUS_API_KEY = process.env.HELIUS_API_KEY;
    if (!HELIUS_API_KEY) {
      logger?.error("\u274C [GetWalletActivity] Missing HELIUS_API_KEY");
      return { transactions: [], error: "Missing HELIUS_API_KEY" };
    }
    const url = `https://api.helius.xyz/v0/addresses/${context.walletAddress}/transactions?api-key=${HELIUS_API_KEY}`;
    try {
      logger?.info("\u{1F4E1} [GetWalletActivity] Calling Helius Enhanced Transactions API...");
      const response = await axios.get(url);
      const transactions = response.data || [];
      logger?.info("\u2705 [GetWalletActivity] Successfully fetched transactions", {
        count: transactions.length
      });
      return { transactions };
    } catch (error) {
      logger?.error("\u274C [GetWalletActivity] Error fetching wallet activity", {
        error: error.message,
        wallet: context.walletAddress
      });
      return {
        transactions: [],
        error: error.message || "Failed to fetch wallet activity"
      };
    }
  }
});

const getTokenMetrics = createTool({
  id: "get-token-metrics",
  description: "Fetches token metrics from Birdeye API including liquidity and RSI (Relative Strength Index) for technical analysis.",
  inputSchema: z.object({
    tokenAddress: z.string().describe("The Solana token mint address to fetch metrics for")
  }),
  outputSchema: z.object({
    liquidity: z.number().describe("Token liquidity in USD"),
    rsi: z.number().nullable().describe("RSI value (0-100) or null if unavailable"),
    fdv: z.number().nullable().describe("Fully Diluted Valuation in USD or null if unavailable"),
    priceChange24h: z.number().nullable().describe("24h price change percentage"),
    error: z.string().optional().describe("Error message if request fails")
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F4CA} [GetTokenMetrics] Starting token metrics fetch", {
      token: context.tokenAddress
    });
    const BIRDEYE_API_KEY = process.env.BIRDEYE_API_KEY;
    if (!BIRDEYE_API_KEY) {
      logger?.error("\u274C [GetTokenMetrics] Missing BIRDEYE_API_KEY");
      return { liquidity: 0, fdv: null, priceChange24h: null, rsi: null, error: "Missing BIRDEYE_API_KEY" };
    }
    const headers = { "X-API-KEY": BIRDEYE_API_KEY };
    try {
      logger?.info("\u{1F4E1} [GetTokenMetrics] Calling Birdeye API...");
      const [overviewRes, taRes] = await Promise.all([
        axios.get(
          `https://public-api.birdeye.so/defi/token-overview?address=${context.tokenAddress}`,
          { headers }
        ),
        axios.get(
          `https://public-api.birdeye.so/defi/token-technical-analysis?address=${context.tokenAddress}`,
          { headers }
        )
      ]);
      const liquidity = overviewRes.data?.data?.liquidity || 0;
      const fdv = overviewRes.data?.data?.fdv || null;
      const priceChange24h = overviewRes.data?.data?.priceChange24h || overviewRes.data?.data?.v24hChangePercent || null;
      const rsi = taRes.data?.data?.rsi || null;
      logger?.info("\u2705 [GetTokenMetrics] Successfully fetched metrics", {
        token: context.tokenAddress,
        liquidity,
        fdv,
        priceChange24h,
        rsi
      });
      return { liquidity, fdv, priceChange24h, rsi };
    } catch (error) {
      logger?.error("\u274C [GetTokenMetrics] Error fetching token metrics", {
        error: error.message,
        token: context.tokenAddress
      });
      return {
        liquidity: 0,
        fdv: null,
        priceChange24h: null,
        rsi: null,
        error: error.message || "Failed to fetch token metrics"
      };
    }
  }
});

const FILTERS = {
  maxTradesPerDay: 10,
  minHoldTimeSec: 1800,
  // 30 minutes
  minTokenDiversity: 5,
  maxRepeatTokenTrades: 3,
  minLiquidity: 5e3
};
const analyzeWalletOrganic = createTool({
  id: "analyze-wallet-organic",
  description: "Analyzes a wallet's trading behavior to determine if it exhibits organic conviction trading patterns (vs bot/wash trading). Checks trade frequency, hold times, token diversity, and liquidity.",
  inputSchema: z.object({
    walletAddress: z.string().describe("The wallet address being analyzed"),
    transactions: z.array(z.any()).describe("Transaction history from Helius"),
    tokenMetrics: z.record(
      z.object({
        liquidity: z.number(),
        rsi: z.number().nullable(),
        fdv: z.number().nullable(),
        priceChange24h: z.number().nullable()
      })
    ).describe("Token metrics for all tokens traded")
  }),
  outputSchema: z.object({
    isOrganic: z.boolean().describe("Whether the wallet passes organic trading filters"),
    organicScore: z.number().describe("Organic behavior score 0-50 (higher = more organic)"),
    tradeCount: z.number().describe("Number of trades in the period"),
    avgHoldTime: z.number().describe("Average hold time in seconds across all trades"),
    tokenDiversity: z.number().describe("Number of unique tokens traded"),
    repeatTokenTrades: z.number().describe("Number of trades on the same token (indicates wash trading)"),
    failureReasons: z.array(z.string()).describe("List of reasons why wallet failed organic check"),
    tokenList: z.array(z.string()).describe("List of all tokens traded by this wallet")
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F50D} [AnalyzeWalletOrganic] Starting wallet analysis", {
      wallet: context.walletAddress,
      txCount: context.transactions.length
    });
    const tokenMap = {};
    const tokenTimestamps = {};
    let tradeCount = 0;
    let repeatTokenTrades = 0;
    for (const tx of context.transactions) {
      if (tx.tokenTransfers && tx.tokenTransfers.length > 0) {
        tradeCount++;
        for (const transfer of tx.tokenTransfers) {
          const token = transfer.mint;
          tokenMap[token] = (tokenMap[token] || 0) + 1;
          if (tokenMap[token] > 1) {
            repeatTokenTrades++;
          }
          if (tx.timestamp) {
            if (!tokenTimestamps[token]) {
              tokenTimestamps[token] = [];
            }
            const unixTimestamp = typeof tx.timestamp === "string" ? Math.floor(new Date(tx.timestamp).getTime() / 1e3) : tx.timestamp;
            tokenTimestamps[token].push(unixTimestamp);
          }
        }
      }
    }
    const holdDurations = [];
    for (const [token, timestamps] of Object.entries(tokenTimestamps)) {
      if (timestamps.length >= 2) {
        timestamps.sort((a, b) => a - b);
        for (let i = 1; i < timestamps.length; i++) {
          const holdTime = timestamps[i] - timestamps[i - 1];
          holdDurations.push(holdTime);
        }
      }
    }
    const avgHoldTime = holdDurations.length > 0 ? Math.round(
      holdDurations.reduce((a, b) => a + b, 0) / holdDurations.length
    ) : 0;
    const tokenDiversity = Object.keys(tokenMap).length;
    const tokenList = Object.keys(tokenMap);
    const failureReasons = [];
    if (tradeCount > FILTERS.maxTradesPerDay) {
      failureReasons.push(
        `Too many trades: ${tradeCount} > ${FILTERS.maxTradesPerDay}`
      );
    }
    if (avgHoldTime < FILTERS.minHoldTimeSec) {
      failureReasons.push(
        `Hold time too short: ${avgHoldTime}s < ${FILTERS.minHoldTimeSec}s`
      );
    }
    if (tokenDiversity < FILTERS.minTokenDiversity) {
      failureReasons.push(
        `Low token diversity: ${tokenDiversity} < ${FILTERS.minTokenDiversity}`
      );
    }
    if (repeatTokenTrades > FILTERS.maxRepeatTokenTrades) {
      failureReasons.push(
        `Too many repeat trades: ${repeatTokenTrades} > ${FILTERS.maxRepeatTokenTrades}`
      );
    }
    for (const [token, metrics] of Object.entries(context.tokenMetrics)) {
      if (metrics.liquidity < FILTERS.minLiquidity) {
        failureReasons.push(
          `Token ${token} has low liquidity: $${metrics.liquidity} < $${FILTERS.minLiquidity}`
        );
      }
    }
    const isOrganic = failureReasons.length === 0;
    let organicScore = 0;
    if (tradeCount <= FILTERS.maxTradesPerDay / 2) organicScore += 10;
    else if (tradeCount <= FILTERS.maxTradesPerDay) organicScore += 5;
    if (avgHoldTime >= FILTERS.minHoldTimeSec * 4) organicScore += 15;
    else if (avgHoldTime >= FILTERS.minHoldTimeSec * 2) organicScore += 10;
    else if (avgHoldTime >= FILTERS.minHoldTimeSec) organicScore += 5;
    if (tokenDiversity >= FILTERS.minTokenDiversity * 2) organicScore += 10;
    else if (tokenDiversity >= FILTERS.minTokenDiversity) organicScore += 5;
    if (repeatTokenTrades === 0) organicScore += 10;
    else if (repeatTokenTrades <= FILTERS.maxRepeatTokenTrades / 2) organicScore += 5;
    const lowLiquidityTokens = Object.entries(context.tokenMetrics).filter(
      ([, metrics]) => metrics.liquidity < FILTERS.minLiquidity
    ).length;
    if (lowLiquidityTokens === 0) organicScore += 5;
    logger?.info(
      `${isOrganic ? "\u2705" : "\u274C"} [AnalyzeWalletOrganic] Analysis complete`,
      {
        wallet: context.walletAddress,
        isOrganic,
        organicScore,
        tradeCount,
        avgHoldTime,
        tokenDiversity,
        repeatTokenTrades,
        failureReasons
      }
    );
    return {
      isOrganic,
      organicScore,
      tradeCount,
      avgHoldTime,
      tokenDiversity,
      repeatTokenTrades,
      failureReasons,
      tokenList
    };
  }
});

const getWalletPerformance = createTool({
  id: "get-wallet-performance",
  description: "Fetches wallet performance metrics including P&L, ROI, and trade count using Birdeye PNL API.",
  inputSchema: z.object({
    walletAddress: z.string().describe("The Solana wallet address to analyze")
  }),
  outputSchema: z.object({
    totalPnl: z.number().nullable().describe("Total portfolio P&L in USD"),
    totalRoi: z.number().nullable().describe("Total ROI percentage"),
    realizedProfit: z.number().nullable().describe("Realized profit in USD"),
    unrealizedProfit: z.number().nullable().describe("Unrealized profit in USD"),
    totalInvested: z.number().nullable().describe("Total amount invested in USD"),
    currentValue: z.number().nullable().describe("Current portfolio value in USD"),
    tradeCount: z.number().describe("Total number of trades"),
    profitableTokens: z.number().describe("Number of tokens with positive P&L"),
    totalTokens: z.number().describe("Total number of unique tokens traded"),
    error: z.string().optional().describe("Error message if request fails")
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F4C8} [GetWalletPerformance] Starting performance analysis", {
      wallet: context.walletAddress
    });
    const BIRDEYE_API_KEY = process.env.BIRDEYE_API_KEY;
    if (!BIRDEYE_API_KEY) {
      logger?.error("\u274C [GetWalletPerformance] Missing BIRDEYE_API_KEY");
      return {
        totalPnl: null,
        totalRoi: null,
        realizedProfit: null,
        unrealizedProfit: null,
        totalInvested: null,
        currentValue: null,
        tradeCount: 0,
        profitableTokens: 0,
        totalTokens: 0,
        error: "Missing BIRDEYE_API_KEY"
      };
    }
    const headers = {
      "X-API-KEY": BIRDEYE_API_KEY,
      "x-chain": "solana"
    };
    try {
      logger?.info("\u{1F4E1} [GetWalletPerformance] Calling Birdeye PNL API...");
      const response = await axios.get(
        `https://public-api.birdeye.so/wallet/v2/pnl?wallet=${context.walletAddress}`,
        { headers }
      );
      const data = response.data?.data;
      if (!data) {
        logger?.warn("\u26A0\uFE0F [GetWalletPerformance] No PNL data available");
        return {
          totalPnl: null,
          totalRoi: null,
          realizedProfit: null,
          unrealizedProfit: null,
          totalInvested: null,
          currentValue: null,
          tradeCount: 0,
          profitableTokens: 0,
          totalTokens: 0
        };
      }
      const totalPnl = typeof data.total_pnl === "string" ? parseFloat(data.total_pnl) : data.total_pnl || 0;
      const totalRoi = typeof data.total_roi === "string" ? parseFloat(data.total_roi) : data.total_roi || 0;
      const realizedProfit = typeof data.realized_profit === "string" ? parseFloat(data.realized_profit) : data.realized_profit || 0;
      const unrealizedProfit = typeof data.unrealized_profit === "string" ? parseFloat(data.unrealized_profit) : data.unrealized_profit || 0;
      const totalInvested = typeof data.total_invested === "string" ? parseFloat(data.total_invested) : data.total_invested || 0;
      const currentValue = typeof data.current_value === "string" ? parseFloat(data.current_value) : data.current_value || 0;
      const tokens = data.tokens || [];
      const profitableTokens = tokens.filter((t) => (t.pnl || 0) > 0).length;
      const totalTokens = tokens.length;
      const tradeCount = totalTokens;
      logger?.info("\u2705 [GetWalletPerformance] Performance analysis complete", {
        wallet: context.walletAddress,
        totalPnl,
        totalRoi,
        profitableTokens,
        totalTokens
      });
      return {
        totalPnl,
        totalRoi,
        realizedProfit,
        unrealizedProfit,
        totalInvested,
        currentValue,
        tradeCount,
        profitableTokens,
        totalTokens
      };
    } catch (error) {
      logger?.error("\u274C [GetWalletPerformance] Error fetching wallet performance", {
        error: error.message,
        wallet: context.walletAddress
      });
      return {
        totalPnl: null,
        totalRoi: null,
        realizedProfit: null,
        unrealizedProfit: null,
        totalInvested: null,
        currentValue: null,
        tradeCount: 0,
        profitableTokens: 0,
        totalTokens: 0,
        error: error.message || "Failed to fetch wallet performance"
      };
    }
  }
});

const calculateWalletScore = createTool({
  id: "calculate-wallet-score",
  description: "Calculates a 0-100 score for a wallet based on organic trading behavior and performance metrics. Higher scores indicate better copy-trading candidates.",
  inputSchema: z.object({
    organicScore: z.number().describe("Organic behavior score from analyzeWalletOrganic"),
    performance: z.object({
      totalPnl: z.number().nullable(),
      totalRoi: z.number().nullable(),
      realizedProfit: z.number().nullable(),
      unrealizedProfit: z.number().nullable(),
      totalInvested: z.number().nullable(),
      currentValue: z.number().nullable(),
      tradeCount: z.number(),
      profitableTokens: z.number(),
      totalTokens: z.number()
    }).describe("Performance metrics from getWalletPerformance")
  }),
  outputSchema: z.object({
    totalScore: z.number().describe("Final score 0-100 (higher = better trader)"),
    organicScore: z.number().describe("Organic behavior component (0-50)"),
    performanceScore: z.number().describe("Performance component (0-50)"),
    isProfitable: z.boolean().describe("Whether wallet has positive P&L"),
    isConsistent: z.boolean().describe("Whether wallet shows good win rate"),
    meetsThreshold: z.boolean().describe("Whether score meets minimum threshold (75+)"),
    breakdown: z.object({
      organicWeight: z.number(),
      roiWeight: z.number(),
      winRateWeight: z.number(),
      profitabilityWeight: z.number()
    }).describe("Score breakdown by component")
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F3AF} [CalculateWalletScore] Starting score calculation", {
      organicScore: context.organicScore,
      performance: context.performance
    });
    const { organicScore, performance } = context;
    const organicComponent = Math.min(50, organicScore);
    let performanceScore = 0;
    let roiPoints = 0;
    if (performance.totalRoi !== null && performance.totalRoi !== void 0) {
      if (performance.totalRoi >= 100) roiPoints = 20;
      else if (performance.totalRoi >= 50) roiPoints = 15;
      else if (performance.totalRoi >= 20) roiPoints = 10;
      else if (performance.totalRoi >= 0) roiPoints = 5;
      else roiPoints = 0;
    }
    let winRatePoints = 0;
    if (performance.totalTokens > 0) {
      const winRate2 = performance.profitableTokens / performance.totalTokens * 100;
      if (winRate2 >= 70) winRatePoints = 20;
      else if (winRate2 >= 60) winRatePoints = 15;
      else if (winRate2 >= 50) winRatePoints = 10;
      else if (winRate2 >= 40) winRatePoints = 5;
      else winRatePoints = 0;
    }
    let profitabilityPoints = 0;
    if (performance.totalPnl !== null && performance.totalPnl !== void 0) {
      if (performance.totalPnl >= 1e4) profitabilityPoints = 10;
      else if (performance.totalPnl >= 5e3) profitabilityPoints = 8;
      else if (performance.totalPnl >= 1e3) profitabilityPoints = 6;
      else if (performance.totalPnl >= 500) profitabilityPoints = 4;
      else if (performance.totalPnl >= 0) profitabilityPoints = 2;
      else profitabilityPoints = 0;
    }
    performanceScore = roiPoints + winRatePoints + profitabilityPoints;
    const totalScore = Math.min(100, organicComponent + performanceScore);
    const isProfitable = performance.totalPnl !== null && performance.totalPnl > 0;
    const winRate = performance.totalTokens > 0 ? performance.profitableTokens / performance.totalTokens * 100 : 0;
    const isConsistent = winRate >= 60;
    const meetsThreshold = totalScore >= 75;
    logger?.info("\u2705 [CalculateWalletScore] Score calculation complete", {
      totalScore,
      organicComponent,
      performanceScore,
      isProfitable,
      isConsistent,
      meetsThreshold
    });
    return {
      totalScore,
      organicScore: organicComponent,
      performanceScore,
      isProfitable,
      isConsistent,
      meetsThreshold,
      breakdown: {
        organicWeight: organicComponent,
        roiWeight: roiPoints,
        winRateWeight: winRatePoints,
        profitabilityWeight: profitabilityPoints
      }
    };
  }
});

const autoDiscoverWallets = createTool({
  id: "auto-discover-wallets",
  description: "Automatically discovers top profitable Solana wallets using Solana Tracker API. Fetches wallets with high win rates, proven profitability, and active trading history.",
  inputSchema: z.object({
    limit: z.number().default(100).describe("Maximum number of wallets to return (default: 100)"),
    verified: z.boolean().default(false).describe("Only include verified traders (default: false)")
  }),
  outputSchema: z.object({
    wallets: z.array(z.string()).describe("List of wallet addresses"),
    count: z.number().describe("Number of wallets discovered"),
    error: z.string().optional().describe("Error message if request fails")
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F50D} [AutoDiscoverWallets] Starting auto-discovery via Solana Tracker", {
      limit: context.limit,
      verified: context.verified
    });
    const SOLANA_TRACKER_API_KEY = process.env.SOLANA_TRACKER_API_KEY;
    if (!SOLANA_TRACKER_API_KEY) {
      logger?.error("\u274C [AutoDiscoverWallets] Missing SOLANA_TRACKER_API_KEY");
      return {
        wallets: [],
        count: 0,
        error: "Missing SOLANA_TRACKER_API_KEY - get one at solanatracker.io"
      };
    }
    try {
      logger?.info("\u{1F4E1} [AutoDiscoverWallets] Fetching top traders from Solana Tracker...");
      const response = await fetch("https://data.solanatracker.io/traders/top", {
        method: "GET",
        headers: {
          "x-api-key": SOLANA_TRACKER_API_KEY,
          "Content-Type": "application/json"
        }
      });
      if (!response.ok) {
        const errorText = await response.text();
        logger?.error("\u274C [AutoDiscoverWallets] API request failed", {
          status: response.status,
          error: errorText
        });
        return {
          wallets: [],
          count: 0,
          error: `Solana Tracker API error: ${response.status} - ${errorText}`
        };
      }
      const data = await response.json();
      logger?.info("\u{1F4CA} [AutoDiscoverWallets] Received data from Solana Tracker", {
        dataType: typeof data,
        isArray: Array.isArray(data),
        sampleData: Array.isArray(data) ? data.slice(0, 2) : data
      });
      let wallets = [];
      if (Array.isArray(data)) {
        wallets = data.slice(0, context.limit || 100).map((trader) => {
          return trader.wallet || trader.address || trader.walletAddress || trader.trader || trader.pubkey;
        }).filter((addr) => addr && addr.length > 0);
      } else if (data && typeof data === "object") {
        const tradersArray = data.traders || data.data || data.results || [];
        wallets = tradersArray.slice(0, context.limit || 100).map((trader) => {
          return trader.wallet || trader.address || trader.walletAddress || trader.trader || trader.pubkey;
        }).filter((addr) => addr && addr.length > 0);
      }
      logger?.info("\u2705 [AutoDiscoverWallets] Discovery complete", {
        totalWallets: wallets.length,
        sampleWallets: wallets.slice(0, 3)
      });
      return {
        wallets,
        count: wallets.length
      };
    } catch (error) {
      logger?.error("\u274C [AutoDiscoverWallets] Error during auto-discovery", {
        error: error.message,
        stack: error.stack
      });
      return {
        wallets: [],
        count: 0,
        error: error.message || "Failed to discover wallets from Solana Tracker"
      };
    }
  }
});

const verifyWallets = createTool({
  id: "verify-wallets",
  description: "Manually verify Solana wallets by checking organic behavior and performance metrics. Input wallet addresses found on gmgn or other sources, get back elite scores (\u226585 = safe to copy).",
  inputSchema: z.object({
    walletAddresses: z.array(z.string()).describe("List of Solana wallet addresses to verify")
  }),
  outputSchema: z.object({
    results: z.array(
      z.object({
        walletAddress: z.string(),
        score: z.number(),
        passed: z.boolean().describe("True if score \u226585 (elite trader)"),
        organicScore: z.number(),
        performanceScore: z.number(),
        roi: z.number().nullable(),
        winRate: z.number().nullable(),
        totalPnl: z.number().nullable(),
        failureReasons: z.array(z.string())
      })
    ),
    summary: z.object({
      totalChecked: z.number(),
      eliteCount: z.number().describe("Wallets with score \u226585"),
      passRate: z.number().describe("Percentage of wallets that passed")
    })
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const runtimeContext = new RuntimeContext();
    logger?.info("\u{1F50D} [VerifyWallets] Starting manual wallet verification", {
      totalWallets: context.walletAddresses.length
    });
    const results = [];
    let eliteCount = 0;
    for (const walletAddress of context.walletAddresses) {
      try {
        logger?.info("\u{1F4CA} [VerifyWallets] Checking wallet", { wallet: walletAddress });
        const activityResult = await getWalletActivity.execute({
          context: { walletAddress },
          runtimeContext
        });
        const txCount = activityResult.transactions?.length || 0;
        if (activityResult.error || txCount < 20) {
          logger?.info("\u23ED\uFE0F [VerifyWallets] Insufficient activity", {
            wallet: walletAddress,
            txCount
          });
          results.push({
            walletAddress,
            score: 0,
            passed: false,
            organicScore: 0,
            performanceScore: 0,
            roi: null,
            winRate: null,
            totalPnl: null,
            failureReasons: ["Insufficient trading history (< 20 transactions)"]
          });
          continue;
        }
        const tokenSet = /* @__PURE__ */ new Set();
        for (const tx of activityResult.transactions) {
          if (tx.tokenTransfers) {
            for (const transfer of tx.tokenTransfers) {
              if (transfer.mint) {
                tokenSet.add(transfer.mint);
              }
            }
          }
        }
        const tokenAddresses = Array.from(tokenSet);
        const tokenMetrics = {};
        for (const tokenAddress of tokenAddresses) {
          const result = await getTokenMetrics.execute({
            context: { tokenAddress },
            runtimeContext
          });
          tokenMetrics[tokenAddress] = {
            liquidity: result.liquidity,
            rsi: result.rsi,
            fdv: result.fdv,
            priceChange24h: result.priceChange24h
          };
        }
        const analysisResult = await analyzeWalletOrganic.execute({
          context: {
            walletAddress,
            transactions: activityResult.transactions,
            tokenMetrics
          },
          runtimeContext
        });
        const performanceResult = await getWalletPerformance.execute({
          context: { walletAddress },
          runtimeContext
        });
        const failureReasons = [];
        if (!analysisResult.isOrganic) {
          failureReasons.push(...analysisResult.failureReasons);
        }
        if (performanceResult.totalRoi !== null && performanceResult.totalRoi < 50) {
          failureReasons.push(`ROI too low: ${performanceResult.totalRoi.toFixed(1)}% (need \u226550%)`);
        }
        if (performanceResult.totalPnl !== null && performanceResult.totalPnl < 1e3) {
          failureReasons.push(`Total profit too low: $${performanceResult.totalPnl.toFixed(2)} (need \u2265$1,000)`);
        }
        const winRate = performanceResult.totalTokens > 0 ? performanceResult.profitableTokens / performanceResult.totalTokens * 100 : 0;
        if (winRate < 65) {
          failureReasons.push(`Win rate too low: ${winRate.toFixed(1)}% (need \u226565%)`);
        }
        const scoreResult = await calculateWalletScore.execute({
          context: {
            organicScore: analysisResult.organicScore,
            performance: performanceResult
          },
          runtimeContext
        });
        const passed = scoreResult.totalScore >= 85 && failureReasons.length === 0;
        if (passed) {
          logger?.info("\u{1F31F} [VerifyWallets] ELITE WALLET FOUND!", {
            wallet: walletAddress,
            score: scoreResult.totalScore
          });
          eliteCount++;
        } else {
          logger?.info("\u23ED\uFE0F [VerifyWallets] Wallet failed filters", {
            wallet: walletAddress,
            score: scoreResult.totalScore,
            reasons: failureReasons
          });
        }
        results.push({
          walletAddress,
          score: scoreResult.totalScore,
          passed,
          organicScore: scoreResult.organicScore,
          performanceScore: scoreResult.performanceScore,
          roi: performanceResult.totalRoi,
          winRate: winRate || null,
          totalPnl: performanceResult.totalPnl,
          failureReasons
        });
      } catch (error) {
        logger?.error("\u274C [VerifyWallets] Error verifying wallet", {
          wallet: walletAddress,
          error: error.message
        });
        results.push({
          walletAddress,
          score: 0,
          passed: false,
          organicScore: 0,
          performanceScore: 0,
          roi: null,
          winRate: null,
          totalPnl: null,
          failureReasons: [`Error: ${error.message}`]
        });
      }
    }
    const passRate = results.length > 0 ? eliteCount / results.length * 100 : 0;
    logger?.info("\u2705 [VerifyWallets] Verification complete", {
      totalChecked: results.length,
      eliteCount,
      passRate: passRate.toFixed(1)
    });
    return {
      results,
      summary: {
        totalChecked: results.length,
        eliteCount,
        passRate
      }
    };
  }
});

const TOKEN_ADDRESSES$1 = {
  SOL: "So11111111111111111111111111111111111111112",
  JUP: "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN",
  RAY: "4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R",
  BONK: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
  WIF: "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm",
  ORCA: "orcaEKTdK7LKz57vaAYr9QeNsVEPfiu6QeMU1kektZE",
  PYTH: "HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3",
  JTO: "jtojtomepa8beP8AuQc6eXt5FriJwfFMwQx2v2f9mCL",
  MOBILE: "mb1eu7TzEc71KxDpsmsKoucSSuuoGLv1drys1oP2jh6",
  POPCAT: "7GCihgDB8fe6KNjn2MYtkzZcRjQy3t9GHdC8uHYmW2hr"
};
const getHistoricalOHLCV = createTool$1({
  id: "get-historical-ohlcv",
  description: "Fetches historical OHLCV (Open, High, Low, Close, Volume) data for a token from Birdeye API. Use this to analyze price patterns over 30-180 days to determine optimal entry/exit points for trading.",
  inputSchema: z.object({
    tokenSymbol: z.enum(["SOL", "JUP", "RAY", "BONK", "WIF", "ORCA", "PYTH", "JTO", "MOBILE", "POPCAT"]).describe("Token symbol to fetch data for"),
    intervalType: z.enum(["1H", "4H", "1D"]).default("1H").describe("Candlestick interval: 1H (hourly), 4H (4-hour), 1D (daily)"),
    daysBack: z.number().min(30).max(180).default(90).describe("Number of days of historical data to fetch (30-180)")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    tokenSymbol: z.string(),
    tokenAddress: z.string(),
    interval: z.string(),
    dataPoints: z.number(),
    timeRange: z.object({
      from: z.number(),
      to: z.number(),
      fromDate: z.string(),
      toDate: z.string()
    }),
    data: z.array(
      z.object({
        timestamp: z.number(),
        date: z.string(),
        open: z.number(),
        high: z.number(),
        low: z.number(),
        close: z.number(),
        volume: z.number(),
        priceChange: z.number().optional(),
        priceChangePercent: z.number().optional()
      })
    ),
    summary: z.object({
      avgVolume: z.number(),
      maxPrice: z.number(),
      minPrice: z.number(),
      priceVolatility: z.number(),
      totalDataPoints: z.number()
    }),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { tokenSymbol, intervalType, daysBack } = context;
    logger?.info("\u{1F4CA} [GetHistoricalOHLCV] Fetching historical data", {
      tokenSymbol,
      intervalType,
      daysBack
    });
    const tokenAddress = TOKEN_ADDRESSES$1[tokenSymbol];
    if (!tokenAddress) {
      logger?.error("\u274C [GetHistoricalOHLCV] Invalid token symbol", { tokenSymbol });
      return {
        success: false,
        tokenSymbol,
        tokenAddress: "",
        interval: intervalType,
        dataPoints: 0,
        timeRange: {
          from: 0,
          to: 0,
          fromDate: "",
          toDate: ""
        },
        data: [],
        summary: {
          avgVolume: 0,
          maxPrice: 0,
          minPrice: 0,
          priceVolatility: 0,
          totalDataPoints: 0
        },
        error: `Invalid token symbol: ${tokenSymbol}`
      };
    }
    try {
      const apiKey = process.env.BIRDEYE_API_KEY;
      if (!apiKey) {
        throw new Error("BIRDEYE_API_KEY not found in environment variables");
      }
      const now = Math.floor(Date.now() / 1e3);
      const timeFrom = now - daysBack * 24 * 60 * 60;
      logger?.info("\u{1F4C5} [GetHistoricalOHLCV] Time range", {
        from: new Date(timeFrom * 1e3).toISOString(),
        to: new Date(now * 1e3).toISOString()
      });
      const url = `https://public-api.birdeye.so/defi/ohlcv?address=${tokenAddress}&type=${intervalType}&time_from=${timeFrom}&time_to=${now}`;
      logger?.info("\u{1F517} [GetHistoricalOHLCV] Fetching from Birdeye API", { url: url.replace(apiKey, "REDACTED") });
      const response = await fetch(url, {
        headers: {
          "X-API-KEY": apiKey,
          Accept: "application/json"
        }
      });
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Birdeye API error (${response.status}): ${errorText}`);
      }
      const result = await response.json();
      if (!result.success || !result.data || !result.data.items) {
        throw new Error("Invalid response from Birdeye API");
      }
      const items = result.data.items;
      logger?.info("\u2705 [GetHistoricalOHLCV] Received data", { dataPoints: items.length });
      const processedData = items.map((item, index) => {
        const priceChange = index > 0 ? item.c - items[index - 1].c : 0;
        const priceChangePercent = index > 0 ? (item.c - items[index - 1].c) / items[index - 1].c * 100 : 0;
        return {
          timestamp: item.unixTime,
          date: new Date(item.unixTime * 1e3).toISOString(),
          open: item.o,
          high: item.h,
          low: item.l,
          close: item.c,
          volume: item.v,
          priceChange,
          priceChangePercent
        };
      });
      const volumes = processedData.map((d) => d.volume);
      const prices = processedData.map((d) => d.close);
      const priceChanges = processedData.map((d) => Math.abs(d.priceChangePercent || 0));
      const avgVolume = volumes.reduce((a, b) => a + b, 0) / volumes.length;
      const maxPrice = Math.max(...prices);
      const minPrice = Math.min(...prices);
      const priceVolatility = priceChanges.reduce((a, b) => a + b, 0) / priceChanges.length;
      logger?.info("\u{1F4C8} [GetHistoricalOHLCV] Summary statistics", {
        avgVolume,
        maxPrice,
        minPrice,
        priceVolatility: `${priceVolatility.toFixed(2)}%`
      });
      return {
        success: true,
        tokenSymbol,
        tokenAddress,
        interval: intervalType,
        dataPoints: processedData.length,
        timeRange: {
          from: timeFrom,
          to: now,
          fromDate: new Date(timeFrom * 1e3).toISOString(),
          toDate: new Date(now * 1e3).toISOString()
        },
        data: processedData,
        summary: {
          avgVolume,
          maxPrice,
          minPrice,
          priceVolatility,
          totalDataPoints: processedData.length
        }
      };
    } catch (error) {
      logger?.error("\u274C [GetHistoricalOHLCV] Error fetching data", { error: error.message });
      return {
        success: false,
        tokenSymbol,
        tokenAddress,
        interval: intervalType,
        dataPoints: 0,
        timeRange: {
          from: 0,
          to: 0,
          fromDate: "",
          toDate: ""
        },
        data: [],
        summary: {
          avgVolume: 0,
          maxPrice: 0,
          minPrice: 0,
          priceVolatility: 0,
          totalDataPoints: 0
        },
        error: error.message
      };
    }
  }
});

const analyzePatterns = createTool$1({
  id: "analyze-patterns",
  description: "Analyzes historical OHLCV data to identify profitable trading patterns. Calculates optimal entry points (% gain thresholds that predict bigger moves), exit points (average peaks before reversals), win rates at different thresholds, and risk/reward ratios. Essential for determining buy/sell parameters.",
  inputSchema: z.object({
    data: z.array(
      z.object({
        timestamp: z.number(),
        date: z.string(),
        open: z.number(),
        high: z.number(),
        low: z.number(),
        close: z.number(),
        volume: z.number(),
        priceChange: z.number().optional(),
        priceChangePercent: z.number().optional()
      })
    ),
    tokenSymbol: z.string(),
    entryThresholds: z.array(z.number()).default([3, 5, 7, 10, 15]).describe("% gain thresholds to test for entry signals"),
    exitThresholds: z.array(z.number()).default([10, 15, 20, 25, 30, 40, 50]).describe("% gain thresholds to test for exit signals"),
    stopLossThresholds: z.array(z.number()).default([5, 7, 10]).describe("% loss thresholds to test for stop-loss")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    tokenSymbol: z.string(),
    analysisDate: z.string(),
    dataPointsAnalyzed: z.number(),
    entryAnalysis: z.array(
      z.object({
        entryThreshold: z.number(),
        totalSignals: z.number(),
        avgPeakAfterEntry: z.number(),
        avgTimeToPeak: z.number(),
        winRate: z.number(),
        avgWin: z.number(),
        avgLoss: z.number(),
        profitFactor: z.number(),
        bestExitPoint: z.number()
      })
    ),
    exitAnalysis: z.array(
      z.object({
        exitThreshold: z.number(),
        timesReached: z.number(),
        avgTimeToReach: z.number(),
        avgReversalAfter: z.number(),
        probabilityOfReversal: z.number()
      })
    ),
    stopLossAnalysis: z.array(
      z.object({
        stopLossThreshold: z.number(),
        timesHit: z.number(),
        avgRecoveryTime: z.number(),
        probabilityOfRecovery: z.number()
      })
    ),
    recommendations: z.object({
      bestEntryThreshold: z.number(),
      bestExitThreshold: z.number(),
      recommendedStopLoss: z.number(),
      expectedWinRate: z.number(),
      expectedProfitFactor: z.number(),
      reasoning: z.string()
    }),
    volumePatterns: z.object({
      avgVolumeOnPumps: z.number(),
      avgVolumeOnDumps: z.number(),
      volumeIncreaseBeforePump: z.number()
    }),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { data, tokenSymbol, entryThresholds, exitThresholds, stopLossThresholds } = context;
    logger?.info("\u{1F52C} [AnalyzePatterns] Starting pattern analysis", {
      tokenSymbol,
      dataPoints: data.length,
      entryThresholds,
      exitThresholds
    });
    try {
      if (data.length < 100) {
        throw new Error("Insufficient data for pattern analysis (need at least 100 data points)");
      }
      const entryAnalysis = entryThresholds.map((threshold) => {
        logger?.info(`\u{1F4CA} [AnalyzePatterns] Analyzing entry threshold: ${threshold}%`);
        let totalSignals = 0;
        let wins = 0;
        let totalWinAmount = 0;
        let totalLossAmount = 0;
        let totalTimeToPeak = 0;
        let totalPeakGain = 0;
        for (let i = 1; i < data.length - 50; i++) {
          const priceChange = (data[i].close - data[i - 1].close) / data[i - 1].close * 100;
          if (priceChange >= threshold) {
            totalSignals++;
            const entryPrice = data[i].close;
            let peak = entryPrice;
            let peakIndex = i;
            let exitPrice = entryPrice;
            let exitIndex = i + 1;
            for (let j = i + 1; j < Math.min(i + 51, data.length); j++) {
              if (data[j].high > peak) {
                peak = data[j].high;
                peakIndex = j;
              }
              const currentGain = (data[j].close - entryPrice) / entryPrice * 100;
              if (currentGain <= -7) {
                exitPrice = data[j].close;
                exitIndex = j;
                break;
              }
              if (currentGain >= 25) {
                exitPrice = data[j].close;
                exitIndex = j;
                break;
              }
            }
            if (exitIndex === i + 1) {
              exitIndex = Math.min(i + 50, data.length - 1);
              exitPrice = data[exitIndex].close;
            }
            const peakGain = (peak - entryPrice) / entryPrice * 100;
            const finalGain = (exitPrice - entryPrice) / entryPrice * 100;
            totalPeakGain += peakGain;
            totalTimeToPeak += peakIndex - i;
            if (finalGain > 0) {
              wins++;
              totalWinAmount += finalGain;
            } else {
              totalLossAmount += Math.abs(finalGain);
            }
          }
        }
        const winRate = totalSignals > 0 ? wins / totalSignals * 100 : 0;
        const avgWin = wins > 0 ? totalWinAmount / wins : 0;
        const avgLoss = totalSignals - wins > 0 ? totalLossAmount / (totalSignals - wins) : 0;
        const profitFactor = avgLoss > 0 ? avgWin / avgLoss : 0;
        const avgPeakAfterEntry = totalSignals > 0 ? totalPeakGain / totalSignals : 0;
        const avgTimeToPeak = totalSignals > 0 ? totalTimeToPeak / totalSignals : 0;
        logger?.info(`\u2705 [AnalyzePatterns] Entry ${threshold}%: ${totalSignals} signals, ${winRate.toFixed(1)}% win rate`);
        return {
          entryThreshold: threshold,
          totalSignals,
          avgPeakAfterEntry,
          avgTimeToPeak,
          winRate,
          avgWin,
          avgLoss,
          profitFactor,
          bestExitPoint: avgPeakAfterEntry * 0.8
          // Conservative: 80% of avg peak
        };
      });
      const exitAnalysis = exitThresholds.map((threshold) => {
        let timesReached = 0;
        let totalTimeToReach = 0;
        let reversals = 0;
        let totalReversal = 0;
        for (let i = 0; i < data.length - 20; i++) {
          const startPrice = data[i].close;
          for (let j = i + 1; j < Math.min(i + 21, data.length); j++) {
            const gain = (data[j].close - startPrice) / startPrice * 100;
            if (gain >= threshold) {
              timesReached++;
              totalTimeToReach += j - i;
              for (let k = j + 1; k < Math.min(j + 6, data.length); k++) {
                if (data[k].close < data[j].close * 0.95) {
                  reversals++;
                  totalReversal += (data[j].close - data[k].close) / data[j].close * 100;
                  break;
                }
              }
              break;
            }
          }
        }
        return {
          exitThreshold: threshold,
          timesReached,
          avgTimeToReach: timesReached > 0 ? totalTimeToReach / timesReached : 0,
          avgReversalAfter: reversals > 0 ? totalReversal / reversals : 0,
          probabilityOfReversal: timesReached > 0 ? reversals / timesReached * 100 : 0
        };
      });
      const stopLossAnalysis = stopLossThresholds.map((threshold) => {
        let timesHit = 0;
        let recoveries = 0;
        let totalRecoveryTime = 0;
        for (let i = 0; i < data.length - 20; i++) {
          const startPrice = data[i].close;
          for (let j = i + 1; j < Math.min(i + 21, data.length); j++) {
            const loss = (data[j].close - startPrice) / startPrice * 100;
            if (loss <= -threshold) {
              timesHit++;
              for (let k = j + 1; k < Math.min(j + 11, data.length); k++) {
                if (data[k].close >= startPrice) {
                  recoveries++;
                  totalRecoveryTime += k - j;
                  break;
                }
              }
              break;
            }
          }
        }
        return {
          stopLossThreshold: threshold,
          timesHit,
          avgRecoveryTime: recoveries > 0 ? totalRecoveryTime / recoveries : 0,
          probabilityOfRecovery: timesHit > 0 ? recoveries / timesHit * 100 : 0
        };
      });
      const bestEntry = entryAnalysis.reduce(
        (best, current) => current.profitFactor > best.profitFactor ? current : best
      );
      const bestExit = exitAnalysis.reduce(
        (best, current) => current.probabilityOfReversal < best.probabilityOfReversal && current.timesReached > 5 ? current : best
      );
      stopLossAnalysis.find((sl) => sl.stopLossThreshold === 7) || stopLossAnalysis[1];
      const pumps = data.filter((d, i) => i > 0 && (d.priceChangePercent || 0) > 5);
      const dumps = data.filter((d, i) => i > 0 && (d.priceChangePercent || 0) < -5);
      const avgVolumeOnPumps = pumps.length > 0 ? pumps.reduce((a, b) => a + b.volume, 0) / pumps.length : 0;
      const avgVolumeOnDumps = dumps.length > 0 ? dumps.reduce((a, b) => a + b.volume, 0) / dumps.length : 0;
      const avgVolume = data.reduce((a, b) => a + b.volume, 0) / data.length;
      const volumeIncreaseBeforePump = avgVolume > 0 ? (avgVolumeOnPumps / avgVolume - 1) * 100 : 0;
      logger?.info("\u{1F3AF} [AnalyzePatterns] Best parameters found", {
        bestEntry: `${bestEntry.entryThreshold}%`,
        bestExit: `${bestExit.exitThreshold}%`,
        winRate: `${bestEntry.winRate.toFixed(1)}%`,
        profitFactor: bestEntry.profitFactor.toFixed(2)
      });
      return {
        success: true,
        tokenSymbol,
        analysisDate: (/* @__PURE__ */ new Date()).toISOString(),
        dataPointsAnalyzed: data.length,
        entryAnalysis,
        exitAnalysis,
        stopLossAnalysis,
        recommendations: {
          bestEntryThreshold: bestEntry.entryThreshold,
          bestExitThreshold: bestEntry.bestExitPoint,
          recommendedStopLoss: 7,
          expectedWinRate: bestEntry.winRate,
          expectedProfitFactor: bestEntry.profitFactor,
          reasoning: `Entry at ${bestEntry.entryThreshold}% showed ${bestEntry.totalSignals} signals with ${bestEntry.winRate.toFixed(1)}% win rate. Average peak after entry: ${bestEntry.avgPeakAfterEntry.toFixed(1)}%. Conservative exit at ${bestEntry.bestExitPoint.toFixed(1)}% (80% of avg peak) maximizes profit while avoiding reversals.`
        },
        volumePatterns: {
          avgVolumeOnPumps,
          avgVolumeOnDumps,
          volumeIncreaseBeforePump
        }
      };
    } catch (error) {
      logger?.error("\u274C [AnalyzePatterns] Error analyzing patterns", { error: error.message });
      return {
        success: false,
        tokenSymbol,
        analysisDate: (/* @__PURE__ */ new Date()).toISOString(),
        dataPointsAnalyzed: 0,
        entryAnalysis: [],
        exitAnalysis: [],
        stopLossAnalysis: [],
        recommendations: {
          bestEntryThreshold: 0,
          bestExitThreshold: 0,
          recommendedStopLoss: 0,
          expectedWinRate: 0,
          expectedProfitFactor: 0,
          reasoning: ""
        },
        volumePatterns: {
          avgVolumeOnPumps: 0,
          avgVolumeOnDumps: 0,
          volumeIncreaseBeforePump: 0
        },
        error: error.message
      };
    }
  }
});

const TOKEN_ADDRESSES = {
  SOL: "So11111111111111111111111111111111111111112",
  JUP: "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN",
  RAY: "4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R",
  BONK: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
  WIF: "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm",
  ORCA: "orcaEKTdK7LKz57vaAYr9QeNsVEPfiu6QeMU1kektZE",
  PYTH: "HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3",
  JTO: "jtojtomepa8beP8AuQc6eXt5FriJwfFMwQx2v2f9mCL"
};
const monitorTokenPrices = createTool$1({
  id: "monitor-token-prices",
  description: "Monitors real-time token prices from DexScreener API. Fetches current price, 24h volume, liquidity, and price changes (1h, 6h, 24h). Use this to detect trading opportunities and track token performance.",
  inputSchema: z.object({
    tokens: z.array(z.enum(["SOL", "JUP", "RAY", "BONK", "WIF", "ORCA", "PYTH", "JTO"])).default(["JUP", "BONK", "WIF", "RAY"]).describe("Array of token symbols to monitor")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    timestamp: z.string(),
    tokens: z.array(
      z.object({
        symbol: z.string(),
        address: z.string(),
        priceUsd: z.number(),
        priceChange1h: z.number().nullable(),
        priceChange6h: z.number().nullable(),
        priceChange24h: z.number().nullable(),
        volume24h: z.number(),
        liquidity: z.number(),
        marketCap: z.number().nullable(),
        fdv: z.number().nullable(),
        pairAddress: z.string(),
        dexId: z.string(),
        buys5m: z.number().optional(),
        sells5m: z.number().optional(),
        volumeChange24h: z.number().optional()
      })
    ),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { tokens } = context;
    logger?.info("\u{1F4CA} [MonitorTokenPrices] Starting price monitoring", {
      tokens,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
    try {
      const results = await Promise.all(
        tokens.map(async (symbol) => {
          const address = TOKEN_ADDRESSES[symbol];
          if (!address) {
            logger?.warn(`\u26A0\uFE0F [MonitorTokenPrices] Unknown token: ${symbol}`);
            return null;
          }
          try {
            const url = `https://api.dexscreener.com/latest/dex/tokens/${address}`;
            logger?.debug(`\u{1F517} [MonitorTokenPrices] Fetching ${symbol}`, { url });
            const response = await fetch(url);
            if (!response.ok) {
              throw new Error(`DexScreener API error: ${response.status}`);
            }
            const data = await response.json();
            if (!data.pairs || data.pairs.length === 0) {
              logger?.warn(`\u26A0\uFE0F [MonitorTokenPrices] No pairs found for ${symbol}`);
              return null;
            }
            const pair = data.pairs.reduce((best, current) => {
              const bestLiq = best?.liquidity?.usd || 0;
              const currentLiq = current?.liquidity?.usd || 0;
              return currentLiq > bestLiq ? current : best;
            });
            const tokenData = {
              symbol,
              address,
              priceUsd: parseFloat(pair.priceUsd || "0"),
              priceChange1h: pair.priceChange?.h1 ? parseFloat(pair.priceChange.h1) : null,
              priceChange6h: pair.priceChange?.h6 ? parseFloat(pair.priceChange.h6) : null,
              priceChange24h: pair.priceChange?.h24 ? parseFloat(pair.priceChange.h24) : null,
              volume24h: parseFloat(pair.volume?.h24 || "0"),
              liquidity: parseFloat(pair.liquidity?.usd || "0"),
              marketCap: pair.marketCap ? parseFloat(pair.marketCap) : null,
              fdv: pair.fdv ? parseFloat(pair.fdv) : null,
              pairAddress: pair.pairAddress,
              dexId: pair.dexId,
              buys5m: pair.txns?.m5?.buys || 0,
              sells5m: pair.txns?.m5?.sells || 0,
              volumeChange24h: pair.volume?.h24 && pair.volume?.h6 ? (parseFloat(pair.volume.h24) / 4 - parseFloat(pair.volume.h6)) / parseFloat(pair.volume.h6) * 100 : 0
            };
            logger?.info(`\u2705 [MonitorTokenPrices] ${symbol}`, {
              price: `$${tokenData.priceUsd.toFixed(6)}`,
              change1h: `${tokenData.priceChange1h?.toFixed(2)}%`,
              volume24h: `$${(tokenData.volume24h / 1e6).toFixed(2)}M`,
              liquidity: `$${(tokenData.liquidity / 1e6).toFixed(2)}M`
            });
            return tokenData;
          } catch (error) {
            logger?.error(`\u274C [MonitorTokenPrices] Error fetching ${symbol}`, {
              error: error.message
            });
            return null;
          }
        })
      );
      const validResults = results.filter((r) => r !== null);
      return {
        success: true,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        tokens: validResults
      };
    } catch (error) {
      logger?.error("\u274C [MonitorTokenPrices] Error monitoring tokens", {
        error: error.message
      });
      return {
        success: false,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        tokens: [],
        error: error.message
      };
    }
  }
});

const COINGECKO_IDS$1 = {
  JUP: "jupiter-exchange-solana",
  BONK: "bonk",
  WIF: "dogwifcoin",
  RAY: "raydium",
  SOL: "solana"
};
const backtestStrategy = createTool$1({
  id: "backtest-strategy",
  description: "Backtests trading strategy on historical price data from CoinGecko. Simulates buy/sell signals over 30-365 days to calculate actual win rate, profit factor, and total returns. Essential for validating strategy before risking real capital.",
  inputSchema: z.object({
    tokenSymbol: z.enum(["JUP", "BONK", "WIF", "RAY", "SOL"]).describe("Token to backtest"),
    daysBack: z.number().min(30).max(365).default(180).describe("Days of historical data to test"),
    initialCapital: z.number().default(1e3).describe("Starting capital in USD"),
    positionSize: z.number().default(1e3).describe("USD per trade"),
    parameters: z.object({
      minEntryGain: z.number().default(5),
      maxEntryGain: z.number().default(10),
      minLiquidity: z.number().default(2e6),
      minVolume24h: z.number().default(5e5),
      profitTarget1: z.number().default(15),
      profitTarget2: z.number().default(25),
      stopLoss: z.number().default(7)
    }).default({})
  }),
  outputSchema: z.object({
    success: z.boolean(),
    tokenSymbol: z.string(),
    testPeriod: z.object({
      from: z.string(),
      to: z.string(),
      totalDays: z.number()
    }),
    results: z.object({
      totalTrades: z.number(),
      wins: z.number(),
      losses: z.number(),
      winRate: z.number(),
      avgWin: z.number(),
      avgLoss: z.number(),
      profitFactor: z.number(),
      totalReturn: z.number(),
      finalCapital: z.number(),
      maxDrawdown: z.number(),
      sharpeRatio: z.number().nullable()
    }),
    trades: z.array(
      z.object({
        entryDate: z.string(),
        entryPrice: z.number(),
        exitDate: z.string(),
        exitPrice: z.number(),
        profitPercent: z.number(),
        profitUSD: z.number(),
        reason: z.string()
      })
    ),
    recommendation: z.string(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { tokenSymbol, daysBack, initialCapital, positionSize, parameters } = context;
    logger?.info("\u{1F4CA} [BacktestStrategy] Starting backtest", {
      tokenSymbol,
      daysBack,
      initialCapital,
      positionSize
    });
    try {
      const coinId = COINGECKO_IDS$1[tokenSymbol];
      if (!coinId) {
        throw new Error(`Unknown token: ${tokenSymbol}`);
      }
      const url = `https://api.coingecko.com/api/v3/coins/${coinId}/ohlc?vs_currency=usd&days=${daysBack}`;
      logger?.info("\u{1F517} [BacktestStrategy] Fetching historical data", { url });
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`CoinGecko API error: ${response.status}`);
      }
      const ohlcData = await response.json();
      if (!Array.isArray(ohlcData) || ohlcData.length === 0) {
        throw new Error("No historical data received");
      }
      logger?.info(`\u2705 [BacktestStrategy] Received ${ohlcData.length} candles`);
      const candles = ohlcData.map((candle) => ({
        timestamp: candle[0],
        date: new Date(candle[0]).toISOString(),
        open: candle[1],
        high: candle[2],
        low: candle[3],
        close: candle[4]
      }));
      let capital = initialCapital;
      let position = null;
      const trades = [];
      let maxCapital = capital;
      let maxDrawdown = 0;
      for (let i = 1; i < candles.length; i++) {
        const current = candles[i];
        const previous = candles[i - 1];
        const priceChange = (current.close - previous.close) / previous.close * 100;
        if (position) {
          const profitPercent = (current.close - position.entryPrice) / position.entryPrice * 100;
          if (profitPercent <= -parameters.stopLoss) {
            const exitPrice = current.close;
            const profitUSD = (exitPrice - position.entryPrice) * (positionSize / position.entryPrice);
            capital += profitUSD;
            trades.push({
              entryDate: position.entryDate,
              entryPrice: position.entryPrice,
              exitDate: current.date,
              exitPrice,
              profitPercent,
              profitUSD,
              reason: "Stop Loss"
            });
            position = null;
            continue;
          }
          if (profitPercent >= parameters.profitTarget2) {
            const exitPrice = current.close;
            const profitUSD = (exitPrice - position.entryPrice) * (positionSize / position.entryPrice);
            capital += profitUSD;
            trades.push({
              entryDate: position.entryDate,
              entryPrice: position.entryPrice,
              exitDate: current.date,
              exitPrice,
              profitPercent,
              profitUSD,
              reason: "Profit Target 2"
            });
            position = null;
            continue;
          }
          if (profitPercent >= parameters.profitTarget1) {
            const exitPrice = current.close;
            const profitUSD = (exitPrice - position.entryPrice) * (positionSize / position.entryPrice);
            capital += profitUSD;
            trades.push({
              entryDate: position.entryDate,
              entryPrice: position.entryPrice,
              exitDate: current.date,
              exitPrice,
              profitPercent,
              profitUSD,
              reason: "Profit Target 1"
            });
            position = null;
            continue;
          }
        } else {
          if (priceChange >= parameters.minEntryGain && priceChange <= parameters.maxEntryGain && capital >= positionSize) {
            position = {
              entryDate: current.date,
              entryPrice: current.close
            };
            logger?.debug(`\u{1F680} [BacktestStrategy] BUY signal at ${current.date}`, {
              price: current.close,
              change: priceChange.toFixed(2)
            });
          }
        }
        if (capital > maxCapital) {
          maxCapital = capital;
        }
        const drawdown = (maxCapital - capital) / maxCapital * 100;
        if (drawdown > maxDrawdown) {
          maxDrawdown = drawdown;
        }
      }
      if (position) {
        const final = candles[candles.length - 1];
        const profitPercent = (final.close - position.entryPrice) / position.entryPrice * 100;
        const profitUSD = (final.close - position.entryPrice) * (positionSize / position.entryPrice);
        capital += profitUSD;
        trades.push({
          entryDate: position.entryDate,
          entryPrice: position.entryPrice,
          exitDate: final.date,
          exitPrice: final.close,
          profitPercent,
          profitUSD,
          reason: "End of Test"
        });
      }
      const wins = trades.filter((t) => t.profitUSD > 0);
      const losses = trades.filter((t) => t.profitUSD <= 0);
      const totalWinAmount = wins.reduce((sum, t) => sum + t.profitUSD, 0);
      const totalLossAmount = Math.abs(losses.reduce((sum, t) => sum + t.profitUSD, 0));
      const avgWin = wins.length > 0 ? wins.reduce((sum, t) => sum + t.profitPercent, 0) / wins.length : 0;
      const avgLoss = losses.length > 0 ? Math.abs(losses.reduce((sum, t) => sum + t.profitPercent, 0) / losses.length) : 0;
      const winRate = trades.length > 0 ? wins.length / trades.length * 100 : 0;
      const profitFactor = totalLossAmount > 0 ? totalWinAmount / totalLossAmount : totalWinAmount > 0 ? 999 : 0;
      const totalReturn = (capital - initialCapital) / initialCapital * 100;
      let recommendation = "";
      if (totalReturn > 0 && winRate >= 60 && profitFactor >= 1.5) {
        recommendation = `\u2705 PROFITABLE STRATEGY: ${totalReturn.toFixed(2)}% return over ${daysBack} days. Win rate: ${winRate.toFixed(1)}%. Profit factor: ${profitFactor.toFixed(2)}x. This strategy shows promise - consider paper trading before live execution.`;
      } else if (totalReturn > 0 && winRate >= 50) {
        recommendation = `\u26A0\uFE0F MARGINALLY PROFITABLE: ${totalReturn.toFixed(2)}% return but win rate only ${winRate.toFixed(1)}%. Consider adjusting parameters or extending test period.`;
      } else {
        recommendation = `\u274C UNPROFITABLE: ${totalReturn.toFixed(2)}% return with ${winRate.toFixed(1)}% win rate. DO NOT trade with real money. Strategy needs major adjustments.`;
      }
      logger?.info("\u{1F4CA} [BacktestStrategy] Backtest complete", {
        totalTrades: trades.length,
        winRate: `${winRate.toFixed(1)}%`,
        totalReturn: `${totalReturn.toFixed(2)}%`,
        finalCapital: capital.toFixed(2)
      });
      return {
        success: true,
        tokenSymbol,
        testPeriod: {
          from: candles[0].date,
          to: candles[candles.length - 1].date,
          totalDays: daysBack
        },
        results: {
          totalTrades: trades.length,
          wins: wins.length,
          losses: losses.length,
          winRate,
          avgWin,
          avgLoss,
          profitFactor,
          totalReturn,
          finalCapital: capital,
          maxDrawdown,
          sharpeRatio: null
          // Would need daily returns for this
        },
        trades,
        recommendation
      };
    } catch (error) {
      logger?.error("\u274C [BacktestStrategy] Error running backtest", { error: error.message });
      return {
        success: false,
        tokenSymbol,
        testPeriod: {
          from: "",
          to: "",
          totalDays: 0
        },
        results: {
          totalTrades: 0,
          wins: 0,
          losses: 0,
          winRate: 0,
          avgWin: 0,
          avgLoss: 0,
          profitFactor: 0,
          totalReturn: 0,
          finalCapital: 0,
          maxDrawdown: 0,
          sharpeRatio: null
        },
        trades: [],
        recommendation: "",
        error: error.message
      };
    }
  }
});

const COINGECKO_IDS = {
  XRP: "ripple",
  SOL: "solana",
  BTC: "bitcoin",
  ETH: "ethereum",
  MATIC: "matic-network",
  AVAX: "avalanche-2",
  LINK: "chainlink",
  ADA: "cardano",
  DOT: "polkadot",
  UNI: "uniswap",
  ATOM: "cosmos",
  LTC: "litecoin",
  NEAR: "near",
  APT: "aptos",
  OP: "optimism",
  ARB: "arbitrum",
  SUI: "sui",
  FIL: "filecoin",
  ALGO: "algorand",
  VET: "vechain"
};
const backtestSwingStrategy = createTool$1({
  id: "backtest-swing-strategy",
  description: "Backtests SWING TRADING strategy on blue chip tokens (XRP, SOL, BTC, ETH). Buys on dips from recent highs, sells on rallies. Mean reversion approach for catching 10-30% price swings.",
  inputSchema: z.object({
    tokenSymbol: z.enum(["XRP", "SOL", "BTC", "ETH", "MATIC", "AVAX", "LINK", "ADA", "DOT", "UNI", "ATOM", "LTC", "NEAR", "APT", "OP", "ARB", "SUI", "FIL", "ALGO", "VET"]).describe("Top 100 token to backtest"),
    daysBack: z.number().min(30).max(365).default(180).describe("Days of historical data to test"),
    initialCapital: z.number().default(1e3).describe("Starting capital in USD"),
    positionSize: z.number().default(500).describe("USD per trade"),
    parameters: z.object({
      dipThreshold: z.number().default(8).describe("% drop from recent high to trigger BUY"),
      profitTarget: z.number().default(15).describe("% gain to trigger SELL"),
      stopLoss: z.number().default(10).describe("% loss to trigger stop loss"),
      lookbackDays: z.number().default(7).describe("Days to look back for recent high")
    }).default({})
  }),
  outputSchema: z.object({
    success: z.boolean(),
    tokenSymbol: z.string(),
    testPeriod: z.object({
      from: z.string(),
      to: z.string(),
      totalDays: z.number()
    }),
    results: z.object({
      totalTrades: z.number(),
      wins: z.number(),
      losses: z.number(),
      winRate: z.number(),
      avgWin: z.number(),
      avgLoss: z.number(),
      profitFactor: z.number(),
      totalReturn: z.number(),
      finalCapital: z.number(),
      maxDrawdown: z.number(),
      avgHoldingDays: z.number()
    }),
    trades: z.array(
      z.object({
        entryDate: z.string(),
        entryPrice: z.number(),
        exitDate: z.string(),
        exitPrice: z.number(),
        profitPercent: z.number(),
        profitUSD: z.number(),
        holdingDays: z.number(),
        reason: z.string()
      })
    ),
    recommendation: z.string(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { tokenSymbol, daysBack, initialCapital, positionSize, parameters } = context;
    logger?.info("\u{1F3AF} [SwingStrategy] Starting swing trading backtest", {
      tokenSymbol,
      daysBack,
      strategy: "Mean Reversion / Swing Trading"
    });
    try {
      const coinId = COINGECKO_IDS[tokenSymbol];
      if (!coinId) {
        throw new Error(`Unknown token: ${tokenSymbol}`);
      }
      const url = `https://api.coingecko.com/api/v3/coins/${coinId}/ohlc?vs_currency=usd&days=${daysBack}`;
      logger?.info("\u{1F517} [SwingStrategy] Fetching historical data", { url });
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`CoinGecko API error: ${response.status}`);
      }
      const ohlcData = await response.json();
      if (!Array.isArray(ohlcData) || ohlcData.length === 0) {
        throw new Error("No historical data received");
      }
      logger?.info(`\u2705 [SwingStrategy] Received ${ohlcData.length} candles`);
      const candles = ohlcData.map((candle) => ({
        timestamp: candle[0],
        date: new Date(candle[0]).toISOString(),
        open: candle[1],
        high: candle[2],
        low: candle[3],
        close: candle[4]
      }));
      let capital = initialCapital;
      let position = null;
      const trades = [];
      let maxCapital = capital;
      let maxDrawdown = 0;
      for (let i = parameters.lookbackDays; i < candles.length; i++) {
        const current = candles[i];
        const lookbackCandles = candles.slice(i - parameters.lookbackDays, i);
        const recentHigh = Math.max(...lookbackCandles.map((c) => c.high));
        Math.min(...lookbackCandles.map((c) => c.low));
        if (position) {
          const profitPercent = (current.close - position.entryPrice) / position.entryPrice * 100;
          const holdingDays = Math.floor((current.timestamp - position.entryTimestamp) / (1e3 * 60 * 60 * 24));
          if (profitPercent >= parameters.profitTarget) {
            const exitPrice = current.close;
            const profitUSD = (exitPrice - position.entryPrice) * (positionSize / position.entryPrice);
            capital += profitUSD;
            trades.push({
              entryDate: position.entryDate,
              entryPrice: position.entryPrice,
              exitDate: current.date,
              exitPrice,
              profitPercent,
              profitUSD,
              holdingDays,
              reason: `Profit Target (${parameters.profitTarget}%)`
            });
            logger?.debug(`\u2705 [SwingStrategy] SELL - Profit Target Hit`, {
              entry: position.entryPrice,
              exit: exitPrice,
              profit: `+${profitPercent.toFixed(2)}%`,
              holdingDays
            });
            position = null;
            continue;
          }
          if (profitPercent <= -parameters.stopLoss) {
            const exitPrice = current.close;
            const profitUSD = (exitPrice - position.entryPrice) * (positionSize / position.entryPrice);
            capital += profitUSD;
            trades.push({
              entryDate: position.entryDate,
              entryPrice: position.entryPrice,
              exitDate: current.date,
              exitPrice,
              profitPercent,
              profitUSD,
              holdingDays,
              reason: `Stop Loss (-${parameters.stopLoss}%)`
            });
            logger?.debug(`\u274C [SwingStrategy] SELL - Stop Loss Hit`, {
              entry: position.entryPrice,
              exit: exitPrice,
              loss: `${profitPercent.toFixed(2)}%`,
              holdingDays
            });
            position = null;
            continue;
          }
        } else {
          const dipFromHigh = (recentHigh - current.close) / recentHigh * 100;
          if (dipFromHigh >= parameters.dipThreshold && capital >= positionSize) {
            position = {
              entryDate: current.date,
              entryPrice: current.close,
              entryTimestamp: current.timestamp
            };
            logger?.debug(`\u{1F680} [SwingStrategy] BUY on dip`, {
              price: current.close,
              recentHigh,
              dipPercent: dipFromHigh.toFixed(2)
            });
          }
        }
        if (capital > maxCapital) {
          maxCapital = capital;
        }
        const drawdown = (maxCapital - capital) / maxCapital * 100;
        if (drawdown > maxDrawdown) {
          maxDrawdown = drawdown;
        }
      }
      if (position) {
        const final = candles[candles.length - 1];
        const profitPercent = (final.close - position.entryPrice) / position.entryPrice * 100;
        const profitUSD = (final.close - position.entryPrice) * (positionSize / position.entryPrice);
        const holdingDays = Math.floor((final.timestamp - position.entryTimestamp) / (1e3 * 60 * 60 * 24));
        capital += profitUSD;
        trades.push({
          entryDate: position.entryDate,
          entryPrice: position.entryPrice,
          exitDate: final.date,
          exitPrice: final.close,
          profitPercent,
          profitUSD,
          holdingDays,
          reason: "End of Test Period"
        });
      }
      const wins = trades.filter((t) => t.profitUSD > 0);
      const losses = trades.filter((t) => t.profitUSD <= 0);
      const totalWinAmount = wins.reduce((sum, t) => sum + t.profitUSD, 0);
      const totalLossAmount = Math.abs(losses.reduce((sum, t) => sum + t.profitUSD, 0));
      const avgWin = wins.length > 0 ? wins.reduce((sum, t) => sum + t.profitPercent, 0) / wins.length : 0;
      const avgLoss = losses.length > 0 ? Math.abs(losses.reduce((sum, t) => sum + t.profitPercent, 0) / losses.length) : 0;
      const winRate = trades.length > 0 ? wins.length / trades.length * 100 : 0;
      const profitFactor = totalLossAmount > 0 ? totalWinAmount / totalLossAmount : totalWinAmount > 0 ? 999 : 0;
      const totalReturn = (capital - initialCapital) / initialCapital * 100;
      const avgHoldingDays = trades.length > 0 ? trades.reduce((sum, t) => sum + t.holdingDays, 0) / trades.length : 0;
      let recommendation = "";
      if (totalReturn > 15 && winRate >= 60 && profitFactor >= 2) {
        recommendation = `\u{1F680} EXCELLENT STRATEGY: ${totalReturn.toFixed(2)}% return over ${daysBack} days. Win rate: ${winRate.toFixed(1)}%. Profit factor: ${profitFactor.toFixed(2)}x. This is a HIGH-QUALITY swing trading strategy. Start paper trading immediately.`;
      } else if (totalReturn > 10 && winRate >= 55) {
        recommendation = `\u2705 GOOD STRATEGY: ${totalReturn.toFixed(2)}% return with ${winRate.toFixed(1)}% win rate. Solid swing trading results. Paper trade for 30 days before live execution.`;
      } else if (totalReturn > 0) {
        recommendation = `\u26A0\uFE0F MARGINALLY PROFITABLE: ${totalReturn.toFixed(2)}% return but needs validation. Paper trade for 60 days before risking real money.`;
      } else {
        recommendation = `\u274C UNPROFITABLE: ${totalReturn.toFixed(2)}% return. Try adjusting parameters (dip threshold, profit target) before trading.`;
      }
      logger?.info("\u{1F4CA} [SwingStrategy] Backtest complete", {
        totalTrades: trades.length,
        winRate: `${winRate.toFixed(1)}%`,
        totalReturn: `${totalReturn.toFixed(2)}%`,
        finalCapital: capital.toFixed(2),
        avgHoldingDays: avgHoldingDays.toFixed(1)
      });
      return {
        success: true,
        tokenSymbol,
        testPeriod: {
          from: candles[0].date,
          to: candles[candles.length - 1].date,
          totalDays: daysBack
        },
        results: {
          totalTrades: trades.length,
          wins: wins.length,
          losses: losses.length,
          winRate,
          avgWin,
          avgLoss,
          profitFactor,
          totalReturn,
          finalCapital: capital,
          maxDrawdown,
          avgHoldingDays
        },
        trades,
        recommendation
      };
    } catch (error) {
      logger?.error("\u274C [SwingStrategy] Error running backtest", { error: error.message });
      return {
        success: false,
        tokenSymbol,
        testPeriod: {
          from: "",
          to: "",
          totalDays: 0
        },
        results: {
          totalTrades: 0,
          wins: 0,
          losses: 0,
          winRate: 0,
          avgWin: 0,
          avgLoss: 0,
          profitFactor: 0,
          totalReturn: 0,
          finalCapital: 0,
          maxDrawdown: 0,
          avgHoldingDays: 0
        },
        trades: [],
        recommendation: "",
        error: error.message
      };
    }
  }
});

const backtestStockSwingStrategy = createTool$1({
  id: "backtest-stock-swing-strategy",
  description: "Backtests SWING TRADING strategy on volatile stocks (TSLA, NVDA, AMD, MSTR, COIN). Buys on dips from recent highs, sells on rallies. Tests for high-volatility Cinderella comeback trades.",
  inputSchema: z.object({
    stockSymbol: z.enum(["TSLA", "NVDA", "AMD", "MSTR", "COIN", "RIOT", "PLTR", "SMCI", "GME", "AMC"]).describe("Volatile stock to backtest"),
    daysBack: z.number().min(30).max(365).default(180).describe("Days of historical data to test"),
    initialCapital: z.number().default(1e3).describe("Starting capital in USD"),
    positionSize: z.number().default(700).describe("USD per trade"),
    parameters: z.object({
      dipThreshold: z.number().default(8).describe("% drop from recent high to trigger BUY"),
      profitTarget: z.number().default(15).describe("% gain to trigger SELL"),
      stopLoss: z.number().default(10).describe("% loss to trigger stop loss"),
      lookbackDays: z.number().default(7).describe("Days to look back for recent high")
    }).default({})
  }),
  outputSchema: z.object({
    success: z.boolean(),
    stockSymbol: z.string(),
    testPeriod: z.object({
      from: z.string(),
      to: z.string(),
      totalDays: z.number()
    }),
    results: z.object({
      totalTrades: z.number(),
      wins: z.number(),
      losses: z.number(),
      winRate: z.number(),
      avgWin: z.number(),
      avgLoss: z.number(),
      profitFactor: z.number(),
      totalReturn: z.number(),
      finalCapital: z.number(),
      maxDrawdown: z.number(),
      avgHoldingDays: z.number()
    }),
    trades: z.array(
      z.object({
        entryDate: z.string(),
        entryPrice: z.number(),
        exitDate: z.string(),
        exitPrice: z.number(),
        profitPercent: z.number(),
        profitUSD: z.number(),
        holdingDays: z.number(),
        reason: z.string()
      })
    ),
    recommendation: z.string(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { stockSymbol, daysBack, initialCapital, positionSize, parameters } = context;
    logger?.info("\u{1F4C8} [StockSwingStrategy] Starting stock swing trading backtest", {
      stockSymbol,
      daysBack,
      strategy: "High Volatility Swing Trading"
    });
    try {
      const apiKey = process.env.ALPHA_VANTAGE_API_KEY;
      if (!apiKey) {
        throw new Error("ALPHA_VANTAGE_API_KEY not found in environment");
      }
      const url = `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=${stockSymbol}&apikey=${apiKey}&outputsize=full`;
      logger?.info("\u{1F517} [StockSwingStrategy] Fetching historical data from Alpha Vantage", { symbol: stockSymbol });
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Alpha Vantage API error: ${response.status}`);
      }
      const data = await response.json();
      if (data["Error Message"]) {
        throw new Error(`Invalid stock symbol: ${stockSymbol}`);
      }
      if (data["Note"]) {
        throw new Error("API rate limit exceeded. Alpha Vantage free tier allows 25 requests/day.");
      }
      const timeSeries = data["Time Series (Daily)"];
      if (!timeSeries) {
        throw new Error("No time series data received");
      }
      const cutoffDate = /* @__PURE__ */ new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysBack);
      const candles = Object.entries(timeSeries).map(([date, values]) => ({
        date,
        timestamp: new Date(date).getTime(),
        open: parseFloat(values["1. open"]),
        high: parseFloat(values["2. high"]),
        low: parseFloat(values["3. low"]),
        close: parseFloat(values["4. close"])
      })).filter((c) => c.timestamp >= cutoffDate.getTime()).sort((a, b) => a.timestamp - b.timestamp);
      logger?.info(`\u2705 [StockSwingStrategy] Received ${candles.length} daily candles`);
      if (candles.length < parameters.lookbackDays + 10) {
        throw new Error("Not enough data for analysis");
      }
      let capital = initialCapital;
      let position = null;
      const trades = [];
      let maxCapital = capital;
      let maxDrawdown = 0;
      for (let i = parameters.lookbackDays; i < candles.length; i++) {
        const current = candles[i];
        const lookbackCandles = candles.slice(i - parameters.lookbackDays, i);
        const recentHigh = Math.max(...lookbackCandles.map((c) => c.high));
        if (position) {
          const profitPercent = (current.close - position.entryPrice) / position.entryPrice * 100;
          const holdingDays = Math.floor((current.timestamp - position.entryTimestamp) / (1e3 * 60 * 60 * 24));
          if (profitPercent >= parameters.profitTarget) {
            const exitPrice = current.close;
            const profitUSD = (exitPrice - position.entryPrice) * (positionSize / position.entryPrice);
            capital += profitUSD;
            trades.push({
              entryDate: position.entryDate,
              entryPrice: position.entryPrice,
              exitDate: current.date,
              exitPrice,
              profitPercent,
              profitUSD,
              holdingDays,
              reason: `Profit Target (${parameters.profitTarget}%)`
            });
            logger?.debug(`\u2705 [StockSwingStrategy] SELL - Profit Target Hit`, {
              entry: position.entryPrice,
              exit: exitPrice,
              profit: `+${profitPercent.toFixed(2)}%`
            });
            position = null;
            continue;
          }
          if (profitPercent <= -parameters.stopLoss) {
            const exitPrice = current.close;
            const profitUSD = (exitPrice - position.entryPrice) * (positionSize / position.entryPrice);
            capital += profitUSD;
            trades.push({
              entryDate: position.entryDate,
              entryPrice: position.entryPrice,
              exitDate: current.date,
              exitPrice,
              profitPercent,
              profitUSD,
              holdingDays,
              reason: `Stop Loss (-${parameters.stopLoss}%)`
            });
            logger?.debug(`\u274C [StockSwingStrategy] SELL - Stop Loss Hit`, {
              entry: position.entryPrice,
              exit: exitPrice,
              loss: `${profitPercent.toFixed(2)}%`
            });
            position = null;
            continue;
          }
        } else {
          const dipFromHigh = (recentHigh - current.close) / recentHigh * 100;
          if (dipFromHigh >= parameters.dipThreshold && capital >= positionSize) {
            position = {
              entryDate: current.date,
              entryPrice: current.close,
              entryTimestamp: current.timestamp
            };
            logger?.debug(`\u{1F680} [StockSwingStrategy] BUY on dip`, {
              price: current.close,
              recentHigh,
              dipPercent: dipFromHigh.toFixed(2)
            });
          }
        }
        if (capital > maxCapital) {
          maxCapital = capital;
        }
        const drawdown = (maxCapital - capital) / maxCapital * 100;
        if (drawdown > maxDrawdown) {
          maxDrawdown = drawdown;
        }
      }
      if (position) {
        const final = candles[candles.length - 1];
        const profitPercent = (final.close - position.entryPrice) / position.entryPrice * 100;
        const profitUSD = (final.close - position.entryPrice) * (positionSize / position.entryPrice);
        const holdingDays = Math.floor((final.timestamp - position.entryTimestamp) / (1e3 * 60 * 60 * 24));
        capital += profitUSD;
        trades.push({
          entryDate: position.entryDate,
          entryPrice: position.entryPrice,
          exitDate: final.date,
          exitPrice: final.close,
          profitPercent,
          profitUSD,
          holdingDays,
          reason: "End of Test Period"
        });
      }
      const wins = trades.filter((t) => t.profitUSD > 0);
      const losses = trades.filter((t) => t.profitUSD <= 0);
      const totalWinAmount = wins.reduce((sum, t) => sum + t.profitUSD, 0);
      const totalLossAmount = Math.abs(losses.reduce((sum, t) => sum + t.profitUSD, 0));
      const avgWin = wins.length > 0 ? wins.reduce((sum, t) => sum + t.profitPercent, 0) / wins.length : 0;
      const avgLoss = losses.length > 0 ? Math.abs(losses.reduce((sum, t) => sum + t.profitPercent, 0) / losses.length) : 0;
      const winRate = trades.length > 0 ? wins.length / trades.length * 100 : 0;
      const profitFactor = totalLossAmount > 0 ? totalWinAmount / totalLossAmount : totalWinAmount > 0 ? 999 : 0;
      const totalReturn = (capital - initialCapital) / initialCapital * 100;
      const avgHoldingDays = trades.length > 0 ? trades.reduce((sum, t) => sum + t.holdingDays, 0) / trades.length : 0;
      let recommendation = "";
      if (totalReturn > 50 && winRate >= 60 && profitFactor >= 2.5) {
        recommendation = `\u{1F680} CINDERELLA STORY! ${totalReturn.toFixed(2)}% return over ${daysBack} days. Win rate: ${winRate.toFixed(1)}%. This is THE high-volatility comeback you're looking for. Paper trade immediately!`;
      } else if (totalReturn > 30 && winRate >= 50) {
        recommendation = `\u2705 STRONG PERFORMER: ${totalReturn.toFixed(2)}% return with ${winRate.toFixed(1)}% win rate. Solid high-risk strategy. Paper trade for 2 weeks before going live.`;
      } else if (totalReturn > 15) {
        recommendation = `\u26A0\uFE0F MODERATE: ${totalReturn.toFixed(2)}% return. Better than average but not a Cinderella story. Consider testing other volatile stocks.`;
      } else if (totalReturn > 0) {
        recommendation = `\u26A0\uFE0F LOW RETURN: ${totalReturn.toFixed(2)}% - Profitable but underwhelming for high-risk capital. Try more volatile stocks or different parameters.`;
      } else {
        recommendation = `\u274C UNPROFITABLE: ${totalReturn.toFixed(2)}% return. This stock/strategy combination didn't work. Try different parameters or stocks.`;
      }
      logger?.info("\u{1F4CA} [StockSwingStrategy] Backtest complete", {
        totalTrades: trades.length,
        winRate: `${winRate.toFixed(1)}%`,
        totalReturn: `${totalReturn.toFixed(2)}%`,
        finalCapital: capital.toFixed(2)
      });
      return {
        success: true,
        stockSymbol,
        testPeriod: {
          from: candles[0].date,
          to: candles[candles.length - 1].date,
          totalDays: candles.length
        },
        results: {
          totalTrades: trades.length,
          wins: wins.length,
          losses: losses.length,
          winRate,
          avgWin,
          avgLoss,
          profitFactor,
          totalReturn,
          finalCapital: capital,
          maxDrawdown,
          avgHoldingDays
        },
        trades,
        recommendation
      };
    } catch (error) {
      logger?.error("\u274C [StockSwingStrategy] Error running backtest", { error: error.message });
      return {
        success: false,
        stockSymbol,
        testPeriod: {
          from: "",
          to: "",
          totalDays: 0
        },
        results: {
          totalTrades: 0,
          wins: 0,
          losses: 0,
          winRate: 0,
          avgWin: 0,
          avgLoss: 0,
          profitFactor: 0,
          totalReturn: 0,
          finalCapital: 0,
          maxDrawdown: 0,
          avgHoldingDays: 0
        },
        trades: [],
        recommendation: "",
        error: error.message
      };
    }
  }
});

const { Pool: Pool$2 } = pg;
const pool$2 = new Pool$2({
  connectionString: process.env.DATABASE_URL
});
async function savePriceSnapshot(data) {
  const result = await pool$2.query(
    `INSERT INTO price_snapshots (symbol, price, high_7d, low_7d, change_percent, rsi, volume)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     RETURNING *`,
    [data.symbol, data.price, data.high7d, data.low7d, data.changePercent, data.rsi, data.volume]
  );
  return result.rows[0];
}
async function getPriceHistory(symbol, days) {
  const result = await pool$2.query(
    `SELECT * FROM price_snapshots
     WHERE symbol = $1
     AND timestamp >= NOW() - INTERVAL '${days} days'
     ORDER BY timestamp DESC`,
    [symbol]
  );
  return result.rows;
}
async function saveSignal(data) {
  const result = await pool$2.query(
    `INSERT INTO trading_signals (symbol, signal_type, trigger_price, current_price, reason)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING *`,
    [data.symbol, data.signalType, data.triggerPrice, data.currentPrice, data.reason]
  );
  return result.rows[0];
}
async function getRecentSignals(symbol, hours = 24) {
  const result = await pool$2.query(
    `SELECT * FROM trading_signals
     WHERE symbol = $1
     AND timestamp >= NOW() - INTERVAL '${hours} hours'
     ORDER BY timestamp DESC`,
    [symbol]
  );
  return result.rows;
}
async function createTrade(data) {
  const shares = data.positionSize / data.entryPrice;
  const result = await pool$2.query(
    `INSERT INTO trades (symbol, trade_type, entry_price, entry_date, position_size, shares, entry_signal_id, notes)
     VALUES ($1, $2, $3, NOW(), $4, $5, $6, $7)
     RETURNING *`,
    [data.symbol, data.tradeType, data.entryPrice, data.positionSize, shares, data.entrySignalId, data.notes]
  );
  return result.rows[0];
}
async function closeTrade(data) {
  const tradeResult = await pool$2.query(
    `SELECT * FROM trades WHERE id = $1`,
    [data.tradeId]
  );
  if (tradeResult.rows.length === 0) {
    throw new Error(`Trade ${data.tradeId} not found`);
  }
  const trade = tradeResult.rows[0];
  const profitLoss = parseFloat(trade.shares) * data.exitPrice - parseFloat(trade.position_size);
  const profitLossPercent = profitLoss / parseFloat(trade.position_size) * 100;
  const holdingDays = Math.floor((Date.now() - new Date(trade.entry_date).getTime()) / (1e3 * 60 * 60 * 24));
  const result = await pool$2.query(
    `UPDATE trades
     SET exit_price = $2, exit_date = NOW(), exit_reason = $3, exit_signal_id = $4,
         profit_loss = $5, profit_loss_percent = $6, holding_days = $7, status = 'CLOSED',
         updated_at = NOW()
     WHERE id = $1
     RETURNING *`,
    [data.tradeId, data.exitPrice, data.exitReason, data.exitSignalId, profitLoss, profitLossPercent, holdingDays]
  );
  return result.rows[0];
}
async function getOpenTrades(symbol, tradeType) {
  const query = tradeType ? `SELECT * FROM trades WHERE symbol = $1 AND status = 'OPEN' AND trade_type = $2 ORDER BY entry_date DESC` : `SELECT * FROM trades WHERE symbol = $1 AND status = 'OPEN' ORDER BY entry_date DESC`;
  const params = tradeType ? [symbol, tradeType] : [symbol];
  const result = await pool$2.query(query, params);
  return result.rows;
}
async function getAllTrades(symbol, tradeType) {
  const query = tradeType ? `SELECT * FROM trades WHERE symbol = $1 AND trade_type = $2 ORDER BY entry_date DESC` : `SELECT * FROM trades WHERE symbol = $1 ORDER BY entry_date DESC`;
  const params = tradeType ? [symbol, tradeType] : [symbol];
  const result = await pool$2.query(query, params);
  return result.rows;
}
async function calculateAndSaveMetrics(symbol, tradeType) {
  const trades = await getAllTrades(symbol, tradeType);
  const closedTrades = trades.filter((t) => t.status === "CLOSED");
  if (closedTrades.length === 0) {
    return null;
  }
  const winningTrades = closedTrades.filter((t) => parseFloat(t.profit_loss) > 0);
  const losingTrades = closedTrades.filter((t) => parseFloat(t.profit_loss) < 0);
  const totalProfit = winningTrades.reduce((sum, t) => sum + parseFloat(t.profit_loss), 0);
  const totalLoss = Math.abs(losingTrades.reduce((sum, t) => sum + parseFloat(t.profit_loss), 0));
  const netProfitLoss = totalProfit - totalLoss;
  const winRate = winningTrades.length / closedTrades.length * 100;
  const avgWin = winningTrades.length > 0 ? winningTrades.reduce((sum, t) => sum + parseFloat(t.profit_loss_percent), 0) / winningTrades.length : 0;
  const avgLoss = losingTrades.length > 0 ? losingTrades.reduce((sum, t) => sum + parseFloat(t.profit_loss_percent), 0) / losingTrades.length : 0;
  const avgHolding = closedTrades.reduce((sum, t) => sum + (t.holding_days || 0), 0) / closedTrades.length;
  const profitFactor = totalLoss > 0 ? totalProfit / totalLoss : totalProfit > 0 ? 999 : 0;
  let peak = 0;
  let maxDrawdown = 0;
  let runningTotal = 0;
  closedTrades.forEach((t) => {
    runningTotal += parseFloat(t.profit_loss);
    if (runningTotal > peak) {
      peak = runningTotal;
    }
    const drawdown = (peak - runningTotal) / peak * 100;
    if (drawdown > maxDrawdown) {
      maxDrawdown = drawdown;
    }
  });
  const periodStart = new Date(closedTrades[closedTrades.length - 1].entry_date);
  const periodEnd = new Date(closedTrades[0].exit_date);
  const result = await pool$2.query(
    `INSERT INTO performance_metrics 
     (symbol, trade_type, total_trades, winning_trades, losing_trades, win_rate,
      total_profit, total_loss, net_profit_loss, avg_win_percent, avg_loss_percent,
      avg_holding_days, profit_factor, max_drawdown, period_start, period_end)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
     ON CONFLICT DO NOTHING
     RETURNING *`,
    [
      symbol,
      tradeType,
      closedTrades.length,
      winningTrades.length,
      losingTrades.length,
      winRate,
      totalProfit,
      totalLoss,
      netProfitLoss,
      avgWin,
      avgLoss,
      avgHolding,
      profitFactor,
      maxDrawdown,
      periodStart,
      periodEnd
    ]
  );
  return result.rows[0];
}

const monitorAMDPrice = createTool({
  id: "monitor-amd-price",
  description: `
    Monitors AMD stock price in real-time using Alpha Vantage API.
    Detects swing trading signals based on 8% dip (BUY) and 15% profit target (SELL).
    Saves price snapshots and trading signals to Darkwave database.
    Returns current status, signals, and recommendations.
  `,
  inputSchema: z.object({
    symbol: z.string().default("AMD").describe("Stock symbol to monitor"),
    dipThreshold: z.number().default(8).describe("Percentage dip to trigger BUY signal"),
    profitTarget: z.number().default(15).describe("Percentage profit to trigger SELL signal"),
    lookbackDays: z.number().default(7).describe("Days to look back for high/low")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    currentPrice: z.number().optional(),
    high7d: z.number().optional(),
    low7d: z.number().optional(),
    changePercent: z.number().optional(),
    signals: z.array(z.object({
      type: z.string(),
      reason: z.string(),
      timestamp: z.string()
    })).optional(),
    openTrades: z.number().optional(),
    recommendation: z.string().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { symbol, dipThreshold, profitTarget, lookbackDays } = context;
    logger?.info("\u{1F4CA} [MonitorAMD] Starting AMD price monitoring", { symbol, dipThreshold, profitTarget });
    try {
      const apiKey = process.env.ALPHA_VANTAGE_API_KEY;
      if (!apiKey) {
        throw new Error("ALPHA_VANTAGE_API_KEY not found in environment");
      }
      const url = `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${apiKey}`;
      logger?.info("\u{1F517} [MonitorAMD] Fetching current price", { symbol });
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Alpha Vantage API error: ${response.status}`);
      }
      const data = await response.json();
      if (data["Error Message"]) {
        throw new Error(`Invalid stock symbol: ${symbol}`);
      }
      if (data["Note"]) {
        logger?.warn("\u26A0\uFE0F [MonitorAMD] API rate limit hit - will retry next hour");
        return {
          success: false,
          error: "Alpha Vantage API rate limit exceeded (25/day free tier). Upgrade to paid tier for unlimited requests or reduce polling frequency. Next attempt in 1 hour."
        };
      }
      const quote = data["Global Quote"];
      if (!quote) {
        throw new Error("No quote data received");
      }
      const currentPrice = parseFloat(quote["05. price"]);
      const changePercent = parseFloat(quote["10. change percent"].replace("%", ""));
      logger?.info("\u{1F4B0} [MonitorAMD] Current price fetched", { price: currentPrice, changePercent });
      const history = await getPriceHistory(symbol, lookbackDays);
      let high7d = currentPrice;
      let low7d = currentPrice;
      if (history && history.length > 0) {
        high7d = Math.max(...history.map((h) => parseFloat(h.price)), currentPrice);
        low7d = Math.min(...history.map((h) => parseFloat(h.price)), currentPrice);
      }
      logger?.info("\u{1F4C8} [MonitorAMD] 7-day range calculated", { high7d, low7d });
      await savePriceSnapshot({
        symbol,
        price: currentPrice,
        high7d,
        low7d,
        changePercent
      });
      logger?.info("\u{1F4BE} [MonitorAMD] Price snapshot saved to database");
      const signals = [];
      const dipFromHigh = (high7d - currentPrice) / high7d * 100;
      if (dipFromHigh >= dipThreshold) {
        const reason = `\u{1F53D} BUY SIGNAL: AMD dipped ${dipFromHigh.toFixed(2)}% from $${high7d.toFixed(2)} high (current: $${currentPrice.toFixed(2)})`;
        const recentSignals = await getRecentSignals(symbol, 24);
        const alreadyAlerted = recentSignals.some(
          (s) => s.signal_type === "BUY" && Math.abs(parseFloat(s.current_price) - currentPrice) < 1
        );
        if (!alreadyAlerted) {
          await saveSignal({
            symbol,
            signalType: "BUY",
            triggerPrice: high7d,
            currentPrice,
            reason
          });
          signals.push({
            type: "BUY",
            reason,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          });
          logger?.info("\u{1F6A8} [MonitorAMD] BUY SIGNAL DETECTED!", { dipFromHigh, currentPrice, high7d });
        }
      }
      const openTrades = await getOpenTrades(symbol);
      for (const trade of openTrades) {
        const entryPrice = parseFloat(trade.entry_price);
        const profitPercent = (currentPrice - entryPrice) / entryPrice * 100;
        if (profitPercent >= profitTarget) {
          const reason = `\u{1F53C} SELL SIGNAL: AMD hit ${profitPercent.toFixed(2)}% profit (entry: $${entryPrice.toFixed(2)}, current: $${currentPrice.toFixed(2)})`;
          const recentSignals = await getRecentSignals(symbol, 24);
          const alreadyAlerted = recentSignals.some(
            (s) => s.signal_type === "SELL" && s.trade_id === trade.id
          );
          if (!alreadyAlerted) {
            await saveSignal({
              symbol,
              signalType: "SELL",
              triggerPrice: entryPrice,
              currentPrice,
              reason
            });
            signals.push({
              type: "SELL",
              reason,
              timestamp: (/* @__PURE__ */ new Date()).toISOString()
            });
            logger?.info("\u{1F6A8} [MonitorAMD] SELL SIGNAL DETECTED!", { profitPercent, currentPrice, entryPrice });
          }
        }
      }
      let recommendation = "";
      if (signals.length > 0) {
        recommendation = signals.map((s) => s.reason).join("; ");
      } else if (dipFromHigh >= dipThreshold * 0.7) {
        recommendation = `\u26A0\uFE0F WATCH: AMD is ${dipFromHigh.toFixed(1)}% below $${high7d.toFixed(2)} high. Close to BUY signal (${dipThreshold}% threshold).`;
      } else {
        recommendation = `\u2705 NO ACTION: AMD at $${currentPrice.toFixed(2)} (${dipFromHigh.toFixed(1)}% from high). Waiting for ${dipThreshold}% dip or profit targets.`;
      }
      logger?.info("\u2705 [MonitorAMD] Monitoring complete", {
        signals: signals.length,
        openTrades: openTrades.length,
        recommendation
      });
      return {
        success: true,
        currentPrice,
        high7d,
        low7d,
        changePercent,
        signals,
        openTrades: openTrades.length,
        recommendation
      };
    } catch (error) {
      logger?.error("\u274C [MonitorAMD] Error monitoring AMD price", { error: error.message });
      return {
        success: false,
        error: error.message
      };
    }
  }
});

function calculateRSI(prices, period = 14) {
  if (prices.length < period + 1) {
    return null;
  }
  const changes = [];
  for (let i = 1; i < prices.length; i++) {
    changes.push(prices[i] - prices[i - 1]);
  }
  let avgGain = 0;
  let avgLoss = 0;
  for (let i = 0; i < period; i++) {
    if (changes[i] > 0) {
      avgGain += changes[i];
    } else {
      avgLoss += Math.abs(changes[i]);
    }
  }
  avgGain /= period;
  avgLoss /= period;
  for (let i = period; i < changes.length; i++) {
    const change = changes[i];
    const gain = change > 0 ? change : 0;
    const loss = change < 0 ? Math.abs(change) : 0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
  }
  if (avgLoss === 0) {
    return 100;
  }
  const rs = avgGain / avgLoss;
  const rsi = 100 - 100 / (1 + rs);
  return rsi;
}
const monitorAssetPrice = createTool({
  id: "monitor-asset-price",
  description: `Monitor price for stocks (AMD via Alpha Vantage) or crypto (SOL via Birdeye) 
    and detect swing trading signals based on 7-day highs/lows.
    Triggers BUY signal on 8% dip from 7-day high.
    Triggers SELL signal when open position hits 15% profit target.`,
  inputSchema: z.object({
    symbol: z.string().describe("Asset symbol (AMD for stock, SOL for crypto)"),
    assetType: z.enum(["STOCK", "CRYPTO"]).describe("Type of asset to monitor"),
    dipThreshold: z.number().default(8).describe("Percentage dip to trigger buy signal"),
    profitTarget: z.number().default(15).describe("Percentage profit to trigger sell signal"),
    lookbackDays: z.number().default(7).describe("Days to look back for high/low")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    currentPrice: z.number().optional(),
    high7d: z.number().optional(),
    low7d: z.number().optional(),
    rsi: z.number().optional(),
    signals: z.array(z.string()).optional(),
    recommendation: z.string().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { symbol, assetType, dipThreshold, profitTarget, lookbackDays } = context;
    try {
      logger?.info("\u{1F4CA} [MonitorAsset] Starting price monitoring", {
        symbol,
        assetType,
        dipThreshold,
        profitTarget
      });
      let currentPrice;
      let changePercent;
      let volume;
      if (assetType === "STOCK") {
        logger?.info("\u{1F517} [MonitorAsset] Fetching stock price from Alpha Vantage", { symbol });
        const apiKey = process.env.ALPHA_VANTAGE_API_KEY;
        if (!apiKey) {
          throw new Error("ALPHA_VANTAGE_API_KEY not configured");
        }
        const url = `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${apiKey}`;
        const response = await fetch(url);
        if (!response.ok) {
          throw new Error(`Alpha Vantage API error: ${response.status}`);
        }
        const data = await response.json();
        if (data["Error Message"]) {
          throw new Error(`Invalid stock symbol: ${symbol}`);
        }
        if (data["Note"]) {
          logger?.warn("\u26A0\uFE0F [MonitorAsset] API rate limit hit - will retry next hour");
          return {
            success: false,
            error: "Alpha Vantage API rate limit exceeded (25/day free tier). Next attempt in 1 hour."
          };
        }
        const quote = data["Global Quote"];
        if (!quote) {
          throw new Error("No stock quote data received");
        }
        currentPrice = parseFloat(quote["05. price"]);
        changePercent = parseFloat(quote["10. change percent"]?.replace("%", ""));
        volume = parseFloat(quote["06. volume"]);
        logger?.info("\u{1F4B0} [MonitorAsset] Stock price fetched", { price: currentPrice, changePercent, volume });
      } else {
        logger?.info("\u{1F517} [MonitorAsset] Fetching crypto price from CoinGecko", { symbol });
        const coinIds = {
          SOL: "solana",
          BTC: "bitcoin",
          ETH: "ethereum"
          // Add more as needed
        };
        const coinId = coinIds[symbol];
        if (!coinId) {
          throw new Error(`No CoinGecko ID configured for ${symbol}`);
        }
        const url = `https://api.coingecko.com/api/v3/simple/price?ids=${coinId}&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true`;
        const response = await fetch(url);
        if (!response.ok) {
          throw new Error(`CoinGecko API error: ${response.status}`);
        }
        const data = await response.json();
        if (!data[coinId]) {
          throw new Error("No crypto price data received");
        }
        currentPrice = data[coinId].usd;
        changePercent = data[coinId].usd_24h_change;
        volume = data[coinId].usd_24h_vol;
        logger?.info("\u{1F4B0} [MonitorAsset] Crypto price fetched", { price: currentPrice, changePercent, volume });
      }
      const recentPrices = await getPriceHistory(symbol, lookbackDays);
      const prices = recentPrices.map((p) => parseFloat(p.price));
      prices.push(currentPrice);
      const high7d = Math.max(...prices);
      const low7d = Math.min(...prices);
      logger?.info("\u{1F4C8} [MonitorAsset] Range calculated", {
        high7d,
        low7d,
        lookbackDays
      });
      const rsiPrices = await getPriceHistory(symbol, 15);
      const rsiPriceArray = rsiPrices.map((p) => parseFloat(p.price));
      rsiPriceArray.reverse();
      rsiPriceArray.push(currentPrice);
      const rsi = calculateRSI(rsiPriceArray, 14);
      if (rsi !== null) {
        logger?.info("\u{1F4CA} [MonitorAsset] RSI calculated", { rsi: rsi.toFixed(2) });
      } else {
        logger?.warn("\u26A0\uFE0F [MonitorAsset] Not enough price history for RSI (need 15+ days)");
      }
      await savePriceSnapshot({
        symbol,
        price: currentPrice,
        high7d,
        low7d,
        changePercent,
        rsi: rsi !== null ? rsi : void 0,
        volume
      });
      logger?.info("\u{1F4BE} [MonitorAsset] Price snapshot saved to database");
      let reversalDetected = false;
      let reversalReason = "";
      const hasValidVolume = volume !== void 0 && Number.isFinite(volume) && volume > 0;
      if (recentPrices.length >= 3 && rsi !== null && hasValidVolume && volume !== void 0) {
        const price1 = parseFloat(recentPrices[0]?.price || currentPrice);
        const price2 = parseFloat(recentPrices[1]?.price || currentPrice);
        const price3 = parseFloat(recentPrices[2]?.price || currentPrice);
        const rsi1 = parseFloat(recentPrices[0]?.rsi || rsi);
        const rsi2 = parseFloat(recentPrices[1]?.rsi || 50);
        const validVolumes = recentPrices.slice(0, 5).map((p) => p.volume ? parseFloat(p.volume) : null).filter((v) => v !== null && !isNaN(v));
        const avgVolume = validVolumes.length > 0 ? validVolumes.reduce((sum, v) => sum + v, 0) / validVolumes.length : 0;
        const wasDecreasing = price3 > price2 && price2 > price1;
        const nowIncreasing = currentPrice > price1;
        const rsiRising = rsi > rsi1 && rsi1 > rsi2;
        const volumeSpike = avgVolume > 0 && volume > avgVolume * 1.5;
        if (wasDecreasing && nowIncreasing && rsiRising && volumeSpike) {
          reversalDetected = true;
          const volumeRatioText = avgVolume > 0 ? `Volume spike ${(volume / avgVolume * 100).toFixed(0)}% above average` : `Volume confirmed`;
          reversalReason = `Reversal detected! Price turning up (${price1.toFixed(2)} \u2192 ${currentPrice.toFixed(2)}), RSI rising (${rsi2.toFixed(1)} \u2192 ${rsi.toFixed(1)}), ${volumeRatioText}`;
          logger?.info("\u{1F504} [MonitorAsset] REVERSAL DETECTED", {
            symbol,
            wasDecreasing,
            nowIncreasing,
            rsiRising,
            volumeSpike,
            currentPrice,
            rsi: rsi.toFixed(2),
            volumeRatio: avgVolume > 0 ? (volume / avgVolume).toFixed(2) : "N/A"
          });
        } else if (wasDecreasing && nowIncreasing) {
          const volumeInfo = avgVolume > 0 ? `${(volume / avgVolume * 100).toFixed(0)}% of avg` : "No history";
          logger?.info("\u{1F4C8} [MonitorAsset] Price turning up but reversal not confirmed", {
            rsiRising,
            volumeSpike: volumeSpike ? "YES" : `NO (${volumeInfo})`
          });
        }
      }
      const signals = [];
      const dipFromHigh = (high7d - currentPrice) / high7d * 100;
      if (reversalDetected) {
        const signal = `\u{1F504} ${symbol} REVERSAL SIGNAL! ${reversalReason}`;
        signals.push(signal);
        await saveSignal({
          symbol,
          signalType: "BUY",
          triggerPrice: high7d,
          currentPrice,
          reason: reversalReason
        });
        logger?.info("\u{1F504} [MonitorAsset] REVERSAL signal saved", { symbol, reversalReason });
      }
      let buySignalTriggered = false;
      let buyReason = "";
      if (dipFromHigh >= dipThreshold) {
        buySignalTriggered = true;
        buyReason = `${dipFromHigh.toFixed(1)}% dip from $${high7d.toFixed(2)} 7-day high`;
        const signal = `\u{1F53D} ${symbol} BUY SIGNAL (Price Dip)! Price: $${currentPrice.toFixed(2)} (-${dipFromHigh.toFixed(1)}% from 7d high of $${high7d.toFixed(2)})`;
        signals.push(signal);
      }
      if (rsi !== null && rsi < 30 && !buySignalTriggered) {
        buySignalTriggered = true;
        buyReason = `RSI oversold at ${rsi.toFixed(2)} (below 30 threshold)`;
        const signal = `\u{1F53D} ${symbol} BUY SIGNAL (RSI Oversold)! RSI: ${rsi.toFixed(2)}, Price: $${currentPrice.toFixed(2)}`;
        signals.push(signal);
      }
      if (buySignalTriggered) {
        await saveSignal({
          symbol,
          signalType: "BUY",
          triggerPrice: high7d,
          currentPrice,
          reason: buyReason
        });
        logger?.info("\u{1F53D} [MonitorAsset] BUY signal detected and saved", {
          symbol,
          dipFromHigh,
          rsi: rsi !== null ? rsi.toFixed(2) : "N/A",
          reason: buyReason
        });
      }
      const openTrades = await getOpenTrades(symbol);
      for (const trade of openTrades) {
        const entryPrice = parseFloat(trade.entry_price);
        const profitPercent = (currentPrice - entryPrice) / entryPrice * 100;
        if (profitPercent >= profitTarget) {
          const signal = `\u{1F53C} ${symbol} SELL SIGNAL! Entry: $${entryPrice.toFixed(2)}, Current: $${currentPrice.toFixed(2)}, Profit: +${profitPercent.toFixed(1)}%`;
          signals.push(signal);
          await saveSignal({
            symbol,
            signalType: "SELL",
            triggerPrice: entryPrice,
            currentPrice,
            reason: `+${profitPercent.toFixed(1)}% profit target reached (entry at $${entryPrice.toFixed(2)})`
          });
          logger?.info("\u{1F53C} [MonitorAsset] SELL signal detected and saved", {
            symbol,
            profitPercent,
            tradeId: trade.id
          });
        }
      }
      let recommendation;
      if (signals.length > 0) {
        recommendation = signals.join("\n");
      } else {
        const rsiText = rsi !== null ? `, RSI: ${rsi.toFixed(2)}` : "";
        recommendation = `\u2705 NO ACTION: ${symbol} at $${currentPrice.toFixed(2)} (${dipFromHigh.toFixed(1)}% from high${rsiText}). Waiting for ${dipThreshold}% dip, RSI < 30, or profit targets.`;
      }
      logger?.info("\u2705 [MonitorAsset] Monitoring complete", {
        signals: signals.length,
        openTrades: openTrades.length,
        rsi: rsi !== null ? rsi.toFixed(2) : "N/A",
        recommendation
      });
      return {
        success: true,
        currentPrice,
        high7d,
        low7d,
        rsi: rsi !== null ? rsi : void 0,
        signals,
        recommendation
      };
    } catch (error) {
      logger?.error("\u274C [MonitorAsset] Error during monitoring", {
        error: error.message,
        symbol
      });
      return {
        success: false,
        error: error.message
      };
    }
  }
});

const recordTradeEntry = createTool({
  id: "record-trade-entry",
  description: `
    Records a new trade entry (BUY) for AMD swing trading.
    Creates a trade record in the Darkwave database.
    Use when executing a BUY signal.
  `,
  inputSchema: z.object({
    symbol: z.string().default("AMD").describe("Stock symbol"),
    tradeType: z.enum(["PAPER", "REAL"]).default("PAPER").describe("Paper trading or real money"),
    entryPrice: z.number().describe("Price per share at entry"),
    positionSize: z.number().describe("Dollar amount invested (e.g., 700)"),
    entrySignalId: z.number().optional().describe("ID of the signal that triggered this entry"),
    notes: z.string().optional().describe("Optional notes about this trade")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    trade: z.any().optional(),
    message: z.string().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { symbol, tradeType, entryPrice, positionSize, entrySignalId, notes } = context;
    logger?.info("\u{1F4DD} [RecordEntry] Recording trade entry", {
      symbol,
      tradeType,
      entryPrice,
      positionSize
    });
    try {
      const trade = await createTrade({
        symbol,
        tradeType,
        entryPrice,
        positionSize,
        entrySignalId,
        notes
      });
      const shares = trade.shares;
      const message = `\u2705 ${tradeType} TRADE OPENED: Bought ${parseFloat(shares).toFixed(4)} shares of ${symbol} at $${entryPrice.toFixed(2)} (Total: $${positionSize.toFixed(2)})`;
      logger?.info("\u2705 [RecordEntry] Trade entry recorded", {
        tradeId: trade.id,
        shares: parseFloat(shares).toFixed(4)
      });
      return {
        success: true,
        trade,
        message
      };
    } catch (error) {
      logger?.error("\u274C [RecordEntry] Error recording trade entry", { error: error.message });
      return {
        success: false,
        error: error.message
      };
    }
  }
});
const recordTradeExit = createTool({
  id: "record-trade-exit",
  description: `
    Records a trade exit (SELL) for AMD swing trading.
    Closes an open trade and calculates P&L.
    Use when executing a SELL signal or stop loss.
  `,
  inputSchema: z.object({
    tradeId: z.number().describe("ID of the trade to close"),
    exitPrice: z.number().describe("Price per share at exit"),
    exitReason: z.enum(["PROFIT_TARGET", "STOP_LOSS", "MANUAL"]).describe("Reason for exit"),
    exitSignalId: z.number().optional().describe("ID of the signal that triggered this exit")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    trade: z.any().optional(),
    message: z.string().optional(),
    profitLoss: z.number().optional(),
    profitLossPercent: z.number().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { tradeId, exitPrice, exitReason, exitSignalId } = context;
    logger?.info("\u{1F4DD} [RecordExit] Recording trade exit", { tradeId, exitPrice, exitReason });
    try {
      const trade = await closeTrade({
        tradeId,
        exitPrice,
        exitReason,
        exitSignalId
      });
      const profitLoss = parseFloat(trade.profit_loss);
      const profitLossPercent = parseFloat(trade.profit_loss_percent);
      const emoji = profitLoss > 0 ? "\u{1F389}" : "\u{1F61E}";
      const message = `${emoji} ${trade.trade_type} TRADE CLOSED: ${trade.symbol} exited at $${exitPrice.toFixed(2)} | P&L: ${profitLoss > 0 ? "+" : ""}$${profitLoss.toFixed(2)} (${profitLossPercent > 0 ? "+" : ""}${profitLossPercent.toFixed(2)}%) | Held: ${trade.holding_days} days | Reason: ${exitReason}`;
      logger?.info("\u2705 [RecordExit] Trade exit recorded", {
        tradeId: trade.id,
        profitLoss,
        profitLossPercent
      });
      await calculateAndSaveMetrics(trade.symbol, trade.trade_type);
      return {
        success: true,
        trade,
        message,
        profitLoss,
        profitLossPercent
      };
    } catch (error) {
      logger?.error("\u274C [RecordExit] Error recording trade exit", { error: error.message });
      return {
        success: false,
        error: error.message
      };
    }
  }
});
const getTradeStatus = createTool({
  id: "get-trade-status",
  description: `
    Gets current trading status for AMD.
    Shows open trades, recent closed trades, and performance metrics.
    Useful for checking portfolio status.
  `,
  inputSchema: z.object({
    symbol: z.string().default("AMD").describe("Stock symbol"),
    tradeType: z.enum(["PAPER", "REAL", "ALL"]).default("ALL").describe("Filter by trade type")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    openTrades: z.array(z.any()).optional(),
    recentTrades: z.array(z.any()).optional(),
    totalOpen: z.number().optional(),
    summary: z.string().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { symbol, tradeType } = context;
    logger?.info("\u{1F4CA} [TradeStatus] Fetching trade status", { symbol, tradeType });
    try {
      const filterType = tradeType === "ALL" ? void 0 : tradeType;
      const openTrades = await getOpenTrades(symbol, filterType);
      const allTrades = await getAllTrades(symbol, filterType);
      const recentTrades = allTrades.slice(0, 10);
      const closedTrades = allTrades.filter((t) => t.status === "CLOSED");
      const totalPnL = closedTrades.reduce((sum, t) => sum + parseFloat(t.profit_loss || 0), 0);
      const winningTrades = closedTrades.filter((t) => parseFloat(t.profit_loss) > 0).length;
      const winRate = closedTrades.length > 0 ? winningTrades / closedTrades.length * 100 : 0;
      const summary = `
\u{1F4CA} AMD Trading Status (${tradeType}):
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F513} Open Trades: ${openTrades.length}
\u2705 Closed Trades: ${closedTrades.length}
\u{1F4B0} Total P&L: ${totalPnL > 0 ? "+" : ""}$${totalPnL.toFixed(2)}
\u{1F4C8} Win Rate: ${winRate.toFixed(1)}% (${winningTrades}/${closedTrades.length})

${openTrades.length > 0 ? "\u{1F513} OPEN POSITIONS:\n" + openTrades.map((t) => {
        const entryPrice = parseFloat(t.entry_price);
        const positionSize = parseFloat(t.position_size);
        const days = Math.floor((Date.now() - new Date(t.entry_date).getTime()) / (1e3 * 60 * 60 * 24));
        return `   \u2022 ${t.trade_type}: $${entryPrice.toFixed(2)} x ${parseFloat(t.shares).toFixed(2)} shares = $${positionSize.toFixed(2)} (${days} days ago)`;
      }).join("\n") : ""}
      `.trim();
      logger?.info("\u2705 [TradeStatus] Status fetched", {
        openTrades: openTrades.length,
        closedTrades: closedTrades.length
      });
      return {
        success: true,
        openTrades,
        recentTrades,
        totalOpen: openTrades.length,
        summary
      };
    } catch (error) {
      logger?.error("\u274C [TradeStatus] Error fetching trade status", { error: error.message });
      return {
        success: false,
        error: error.message
      };
    }
  }
});

const calculatePosition = createTool({
  id: "calculate-position-size",
  description: `Calculate optimal position sizing for a trade based on total capital and risk management rules.
    Determines number of shares to buy, stop loss price, and take profit target.
    Enforces maximum position size to prevent over-concentration of capital.`,
  inputSchema: z.object({
    symbol: z.string().describe("Asset symbol (AMD, SOL, etc)"),
    currentPrice: z.number().describe("Current price of the asset"),
    totalCapital: z.number().describe("Total capital available for trading"),
    maxPositionPercent: z.number().default(33).describe("Max percent of capital per trade (default 33% = 3 trades max)"),
    profitTargetPercent: z.number().default(15).describe("Profit target percentage"),
    stopLossPercent: z.number().default(10).describe("Stop loss percentage")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    positionSize: z.number().optional().describe("Dollar amount to invest"),
    shares: z.number().optional().describe("Number of shares/coins to buy"),
    entryPrice: z.number().optional().describe("Entry price"),
    stopLossPrice: z.number().optional().describe("Stop loss price"),
    takeProfitPrice: z.number().optional().describe("Take profit price"),
    riskAmount: z.number().optional().describe("Maximum loss if stop hit"),
    rewardAmount: z.number().optional().describe("Profit if target hit"),
    riskRewardRatio: z.number().optional().describe("Reward to risk ratio"),
    recommendation: z.string().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const {
      symbol,
      currentPrice,
      totalCapital,
      maxPositionPercent,
      profitTargetPercent,
      stopLossPercent
    } = context;
    try {
      logger?.info("\u{1F9EE} [PositionSize] Calculating position", {
        symbol,
        currentPrice,
        totalCapital,
        maxPositionPercent
      });
      const maxPositionSize = totalCapital * maxPositionPercent / 100;
      const shares = maxPositionSize / currentPrice;
      const stopLossPrice = currentPrice * (1 - stopLossPercent / 100);
      const takeProfitPrice = currentPrice * (1 + profitTargetPercent / 100);
      const riskAmount = maxPositionSize * (stopLossPercent / 100);
      const rewardAmount = maxPositionSize * (profitTargetPercent / 100);
      const riskRewardRatio = rewardAmount / riskAmount;
      logger?.info("\u2705 [PositionSize] Position calculated", {
        positionSize: maxPositionSize.toFixed(2),
        shares: shares.toFixed(4),
        stopLossPrice: stopLossPrice.toFixed(2),
        takeProfitPrice: takeProfitPrice.toFixed(2),
        riskRewardRatio: riskRewardRatio.toFixed(2)
      });
      const recommendation = `
\u{1F4CA} POSITION SIZING for ${symbol}

\u{1F4B0} Investment: $${maxPositionSize.toFixed(2)} (${maxPositionPercent}% of $${totalCapital} capital)
\u{1F4C8} Shares to Buy: ${shares.toFixed(4)} shares at $${currentPrice.toFixed(2)}

\u{1F3AF} TARGETS:
  Entry:        $${currentPrice.toFixed(2)}
  Stop Loss:    $${stopLossPrice.toFixed(2)} (-${stopLossPercent}%)
  Take Profit:  $${takeProfitPrice.toFixed(2)} (+${profitTargetPercent}%)

\u{1F4B5} RISK/REWARD:
  Max Loss:     -$${riskAmount.toFixed(2)} (if stop hit)
  Target Gain:  +$${rewardAmount.toFixed(2)} (if target hit)
  R/R Ratio:    ${riskRewardRatio.toFixed(2)}:1

\u2705 This limits you to ${Math.floor(100 / maxPositionPercent)} concurrent trades maximum.
      `.trim();
      return {
        success: true,
        positionSize: maxPositionSize,
        shares,
        entryPrice: currentPrice,
        stopLossPrice,
        takeProfitPrice,
        riskAmount,
        rewardAmount,
        riskRewardRatio,
        recommendation
      };
    } catch (error) {
      logger?.error("\u274C [PositionSize] Error calculating position", {
        error: error.message,
        symbol
      });
      return {
        success: false,
        error: error.message
      };
    }
  }
});

const { Pool: Pool$1 } = pg;
const pool$1 = new Pool$1({
  connectionString: process.env.DATABASE_URL
});
const scanHoldings = createTool({
  id: "scan-holdings",
  description: "Scan all user holdings for SELL signals - used by hourly workflow",
  inputSchema: z.object({}),
  outputSchema: z.object({
    scanned: z.number(),
    sellSignals: z.array(z.object({
      symbol: z.string(),
      assetType: z.string(),
      signal: z.string()
    })),
    message: z.string()
  }),
  execute: async ({ mastra }) => {
    const logger = mastra?.getLogger();
    try {
      logger?.info("\u{1F50D} [ScanHoldings] Starting holdings scan for SELL signals");
      const result = await pool$1.query(
        "SELECT symbol, asset_type FROM holdings ORDER BY symbol"
      );
      const holdings = result.rows;
      if (holdings.length === 0) {
        logger?.info("\u{1F4ED} [ScanHoldings] No holdings to scan");
        return {
          scanned: 0,
          sellSignals: [],
          message: "No holdings in watchlist."
        };
      }
      logger?.info(`\u{1F4CA} [ScanHoldings] Found ${holdings.length} holdings to scan`);
      const sellSignals = [];
      for (const holding of holdings) {
        try {
          logger?.info(`\u{1F50E} [ScanHoldings] Scanning ${holding.symbol} (${holding.asset_type})`);
          const scanResult = await scanAsset.execute({
            context: {
              symbol: holding.symbol,
              assetType: holding.asset_type
            },
            runtimeContext: new RuntimeContext(),
            mastra
          });
          if (scanResult.signal && scanResult.signal.includes("SELL")) {
            sellSignals.push({
              symbol: holding.symbol,
              assetType: holding.asset_type,
              signal: scanResult.signal
            });
            logger?.warn(`\u26A0\uFE0F [ScanHoldings] SELL signal detected for ${holding.symbol}`);
          }
          await new Promise((resolve) => setTimeout(resolve, 1200));
        } catch (error) {
          logger?.error(`\u274C [ScanHoldings] Error scanning ${holding.symbol}:`, error.message);
        }
      }
      logger?.info(`\u2705 [ScanHoldings] Scan complete`, {
        scanned: holdings.length,
        sellSignals: sellSignals.length
      });
      return {
        scanned: holdings.length,
        sellSignals,
        message: `Scanned ${holdings.length} holdings. Found ${sellSignals.length} SELL signal(s).`
      };
    } catch (error) {
      logger?.error("\u274C [ScanHoldings] Error", { error: error.message });
      return {
        scanned: 0,
        sellSignals: [],
        message: `Error scanning holdings: ${error.message}`
      };
    }
  }
});

const reconnectTelegramWebhook = createTool$1({
  id: "reconnect-telegram-webhook",
  description: "Automatically reconnects Telegram webhook to current domain (keeps bot alive through restarts)",
  inputSchema: z.object({}),
  outputSchema: z.object({
    success: z.boolean(),
    webhookUrl: z.string(),
    message: z.string()
  }),
  execute: async ({ mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F504} [ReconnectWebhook] Starting automatic webhook reconnection");
    const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
    const REPLIT_DOMAINS = process.env.REPLIT_DOMAINS;
    if (!TELEGRAM_BOT_TOKEN) {
      logger?.error("\u274C [ReconnectWebhook] TELEGRAM_BOT_TOKEN not found");
      return {
        success: false,
        webhookUrl: "",
        message: "Missing TELEGRAM_BOT_TOKEN"
      };
    }
    if (!REPLIT_DOMAINS) {
      logger?.error("\u274C [ReconnectWebhook] REPLIT_DOMAINS not found");
      return {
        success: false,
        webhookUrl: "",
        message: "Missing REPLIT_DOMAINS"
      };
    }
    const webhookUrl = `https://${REPLIT_DOMAINS}/webhooks/telegram/action`;
    logger?.info("\u{1F4CD} [ReconnectWebhook] Setting webhook URL:", { webhookUrl });
    try {
      const response = await fetch(
        `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            url: webhookUrl
          })
        }
      );
      const result = await response.json();
      logger?.info("\u{1F4E1} [ReconnectWebhook] Telegram API response:", result);
      if (result.ok) {
        logger?.info("\u2705 [ReconnectWebhook] Webhook successfully reconnected!");
        return {
          success: true,
          webhookUrl,
          message: "Webhook reconnected successfully"
        };
      } else {
        logger?.error("\u274C [ReconnectWebhook] Failed to set webhook:", result);
        return {
          success: false,
          webhookUrl,
          message: `Failed: ${result.description || "Unknown error"}`
        };
      }
    } catch (error) {
      logger?.error("\u274C [ReconnectWebhook] Error setting webhook:", error);
      return {
        success: false,
        webhookUrl,
        message: `Error: ${error instanceof Error ? error.message : "Unknown error"}`
      };
    }
  }
});

const { Pool } = pg;
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});
const setWallet = createTool({
  id: "set-wallet",
  description: "Set or update your Phantom/Solana wallet address for portfolio tracking",
  inputSchema: z.object({
    walletAddress: z.string().describe("Solana wallet public address"),
    walletType: z.string().optional().default("SOLANA").describe("Wallet type (default: SOLANA)"),
    notes: z.string().optional().describe("Optional notes")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    message: z.string(),
    walletAddress: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { walletAddress, walletType, notes } = context;
    try {
      logger?.info("\u{1F4BC} [SetWallet] Setting wallet address", { walletType });
      if (walletType === "SOLANA" && (walletAddress.length < 32 || walletAddress.length > 44)) {
        logger?.warn("\u26A0\uFE0F [SetWallet] Invalid Solana address format", { walletAddress });
        return {
          success: false,
          message: `\u274C Invalid Solana wallet address format. Address should be 32-44 characters.`
        };
      }
      const existing = await pool.query(
        "SELECT id FROM wallet_settings WHERE is_active = true LIMIT 1"
      );
      if (existing.rows.length > 0) {
        await pool.query(
          "UPDATE wallet_settings SET wallet_address = $1, wallet_type = $2, notes = $3, updated_at = NOW() WHERE id = $4",
          [walletAddress, walletType, notes || null, existing.rows[0].id]
        );
        logger?.info("\u2705 [SetWallet] Updated wallet address", { walletAddress: walletAddress.substring(0, 8) + "..." });
        return {
          success: true,
          message: `\u2705 Updated your ${walletType} wallet address!

\u{1F510} ${walletAddress.substring(0, 8)}...${walletAddress.substring(walletAddress.length - 6)}

\u{1F4A1} Use "portfolio" to see your holdings.`,
          walletAddress
        };
      } else {
        await pool.query(
          "INSERT INTO wallet_settings (wallet_address, wallet_type, notes, is_active) VALUES ($1, $2, $3, true)",
          [walletAddress, walletType, notes || null]
        );
        logger?.info("\u2705 [SetWallet] Added new wallet address", { walletAddress: walletAddress.substring(0, 8) + "..." });
        return {
          success: true,
          message: `\u2705 Connected your ${walletType} wallet!

\u{1F510} ${walletAddress.substring(0, 8)}...${walletAddress.substring(walletAddress.length - 6)}

\u{1F4A1} Use "portfolio" to see your live holdings.`,
          walletAddress
        };
      }
    } catch (error) {
      logger?.error("\u274C [SetWallet] Error", { error: error.message });
      return {
        success: false,
        message: `\u274C Error setting wallet: ${error.message}`
      };
    }
  }
});
const getWallet = createTool({
  id: "get-wallet",
  description: "Get the currently configured wallet address",
  inputSchema: z.object({}),
  outputSchema: z.object({
    success: z.boolean(),
    walletAddress: z.string().optional(),
    walletType: z.string().optional(),
    message: z.string()
  }),
  execute: async ({ mastra }) => {
    const logger = mastra?.getLogger();
    try {
      logger?.info("\u{1F50D} [GetWallet] Fetching wallet address");
      const result = await pool.query(
        "SELECT wallet_address, wallet_type FROM wallet_settings WHERE is_active = true LIMIT 1"
      );
      if (result.rows.length === 0) {
        logger?.info("\u26A0\uFE0F [GetWallet] No wallet configured");
        return {
          success: false,
          message: 'No wallet configured. Use "setwallet <address>" to add your Phantom wallet.'
        };
      }
      const wallet = result.rows[0];
      logger?.info("\u2705 [GetWallet] Retrieved wallet", { type: wallet.wallet_type });
      return {
        success: true,
        walletAddress: wallet.wallet_address,
        walletType: wallet.wallet_type,
        message: `Wallet configured: ${wallet.wallet_address}`
      };
    } catch (error) {
      logger?.error("\u274C [GetWallet] Error", { error: error.message });
      return {
        success: false,
        message: `Error fetching wallet: ${error.message}`
      };
    }
  }
});

const getPortfolio = createTool({
  id: "get-portfolio",
  description: "Fetches all token holdings from a Solana wallet with current USD values using Helius API",
  inputSchema: z.object({
    walletAddress: z.string().describe("Solana wallet address to fetch portfolio for")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    tokens: z.array(z.object({
      symbol: z.string(),
      name: z.string(),
      balance: z.number(),
      priceUsd: z.number().optional(),
      valueUsd: z.number().optional(),
      logoURI: z.string().optional()
    })).optional(),
    totalValueUsd: z.number().optional(),
    solBalance: z.number().optional(),
    error: z.string().optional()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    const { walletAddress } = context;
    logger?.info("\u{1F4BC} [GetPortfolio] Fetching portfolio", { wallet: walletAddress.substring(0, 8) + "..." });
    const HELIUS_API_KEY = process.env.HELIUS_API_KEY;
    if (!HELIUS_API_KEY) {
      logger?.error("\u274C [GetPortfolio] Missing HELIUS_API_KEY");
      return {
        success: false,
        error: "Missing HELIUS_API_KEY - cannot fetch portfolio"
      };
    }
    try {
      const url = `https://api.helius.xyz/v0/addresses/${walletAddress}/balances?api-key=${HELIUS_API_KEY}`;
      logger?.info("\u{1F4E1} [GetPortfolio] Calling Helius Balances API");
      const response = await axios.get(url);
      const data = response.data;
      if (!data || !data.tokens) {
        logger?.warn("\u26A0\uFE0F [GetPortfolio] No token data returned");
        return {
          success: false,
          error: "No token data available for this wallet"
        };
      }
      const solBalance = data.nativeBalance ? data.nativeBalance / 1e9 : 0;
      const solPrice = await getSolPrice(logger);
      const solValue = solBalance * (solPrice || 0);
      logger?.info("\u{1F4B0} [GetPortfolio] SOL balance", { balance: solBalance, value: solValue });
      const tokens = [];
      let totalValue = solValue;
      for (const token of data.tokens || []) {
        const balance = token.amount / Math.pow(10, token.decimals || 0);
        if (balance > 1e-6 && token.tokenAccount) {
          const tokenInfo = {
            symbol: token.tokenAccount.data?.symbol || "UNKNOWN",
            name: token.tokenAccount.data?.name || "Unknown Token",
            balance,
            priceUsd: token.tokenAccount.data?.priceUsd,
            valueUsd: token.tokenAccount.data?.priceUsd ? balance * token.tokenAccount.data.priceUsd : void 0,
            logoURI: token.tokenAccount.data?.logoURI
          };
          tokens.push(tokenInfo);
          if (tokenInfo.valueUsd) {
            totalValue += tokenInfo.valueUsd;
          }
        }
      }
      tokens.sort((a, b) => (b.valueUsd || 0) - (a.valueUsd || 0));
      logger?.info("\u2705 [GetPortfolio] Portfolio fetched", {
        tokenCount: tokens.length,
        totalValue: totalValue.toFixed(2)
      });
      return {
        success: true,
        tokens,
        totalValueUsd: totalValue,
        solBalance
      };
    } catch (error) {
      logger?.error("\u274C [GetPortfolio] Error fetching portfolio", {
        error: error.message,
        wallet: walletAddress.substring(0, 8) + "..."
      });
      return {
        success: false,
        error: error.message || "Failed to fetch portfolio"
      };
    }
  }
});
async function getSolPrice(logger) {
  try {
    logger?.info("\u{1F4CA} [GetPortfolio] Fetching SOL price from CoinGecko");
    const response = await axios.get(
      "https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd"
    );
    const price = response.data?.solana?.usd;
    logger?.info("\u2705 [GetPortfolio] SOL price fetched", { price });
    return price || null;
  } catch (error) {
    logger?.warn("\u26A0\uFE0F [GetPortfolio] Could not fetch SOL price", { error: error.message });
    return null;
  }
}

const reconnectWebhookStep = createStep({
  id: "reconnect-webhook",
  description: "Automatically reconnect Telegram webhook to current domain",
  inputSchema: z.object({}),
  outputSchema: z.object({
    webhookReconnected: z.boolean()
  }),
  execute: async ({ mastra }) => {
    const logger = mastra?.getLogger();
    const runtimeContext = new RuntimeContext();
    logger?.info("\u{1F504} [HourlyMonitor] Step 0: Reconnecting Telegram webhook");
    try {
      const result = await reconnectTelegramWebhook.execute({
        context: {},
        runtimeContext,
        mastra
      });
      logger?.info("\u2705 [HourlyMonitor] Webhook reconnection complete", {
        success: result.success,
        url: result.webhookUrl
      });
      return { webhookReconnected: result.success };
    } catch (error) {
      logger?.error("\u274C [HourlyMonitor] Webhook reconnection failed", { error: error.message });
      return { webhookReconnected: false };
    }
  }
});
const scanHoldingsStep = createStep({
  id: "scan-holdings",
  description: "Scan user holdings for SELL signals",
  inputSchema: z.object({
    webhookReconnected: z.boolean()
  }),
  outputSchema: z.object({
    webhookReconnected: z.boolean(),
    scanned: z.number(),
    sellSignals: z.array(z.object({
      symbol: z.string(),
      assetType: z.string(),
      signal: z.string()
    }))
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    const runtimeContext = new RuntimeContext();
    logger?.info("\u{1F50D} [HourlyMonitor] Step 1: Scanning holdings for SELL signals");
    const result = await scanHoldings.execute({
      context: {},
      runtimeContext,
      mastra
    });
    logger?.info("\u2705 [HourlyMonitor] Holdings scan complete", {
      scanned: result.scanned,
      sellSignals: result.sellSignals?.length || 0
    });
    return {
      ...inputData,
      scanned: result.scanned,
      sellSignals: result.sellSignals || []
    };
  }
});
const scanCryptoBuySignalsStep = createStep({
  id: "scan-crypto-buy",
  description: "Scan top 100 crypto for BUY/rally signals",
  inputSchema: z.object({
    webhookReconnected: z.boolean(),
    scanned: z.number(),
    sellSignals: z.array(z.object({
      symbol: z.string(),
      assetType: z.string(),
      signal: z.string()
    }))
  }),
  outputSchema: z.object({
    webhookReconnected: z.boolean(),
    scanned: z.number(),
    sellSignals: z.array(z.object({
      symbol: z.string(),
      assetType: z.string(),
      signal: z.string()
    })),
    cryptoBuySignals: z.array(z.object({
      ticker: z.string(),
      type: z.string(),
      price: z.number(),
      signal: z.string(),
      reason: z.string(),
      rsi: z.number().optional(),
      priceChange24h: z.number().optional(),
      volume24h: z.number().optional(),
      volumeChange: z.number().optional(),
      volumeIndicator: z.string().optional()
    }))
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    const runtimeContext = new RuntimeContext();
    logger?.info("\u{1FA99} [HourlyMonitor] Step 2: Scanning top 100 crypto for BUY signals");
    const result = await getBuySignals.execute({
      context: {
        assetType: "CRYPTO",
        limit: 100
      },
      runtimeContext,
      mastra
    });
    logger?.info("\u2705 [HourlyMonitor] Crypto scan complete", {
      buySignals: result.buyOpportunities?.length || 0
    });
    return {
      ...inputData,
      cryptoBuySignals: result.buyOpportunities || []
    };
  }
});
const scanStockBuySignalsStep = createStep({
  id: "scan-stock-buy",
  description: "Scan top 30 stocks for BUY signals (cost-optimized)",
  inputSchema: z.object({
    webhookReconnected: z.boolean(),
    scanned: z.number(),
    sellSignals: z.array(z.object({
      symbol: z.string(),
      assetType: z.string(),
      signal: z.string()
    })),
    cryptoBuySignals: z.array(z.object({
      ticker: z.string(),
      type: z.string(),
      price: z.number(),
      signal: z.string(),
      reason: z.string(),
      rsi: z.number().optional(),
      priceChange24h: z.number().optional(),
      volume24h: z.number().optional(),
      volumeChange: z.number().optional(),
      volumeIndicator: z.string().optional()
    }))
  }),
  outputSchema: z.object({
    webhookReconnected: z.boolean(),
    scanned: z.number(),
    sellSignals: z.array(z.object({
      symbol: z.string(),
      assetType: z.string(),
      signal: z.string()
    })),
    cryptoBuySignals: z.array(z.object({
      ticker: z.string(),
      type: z.string(),
      price: z.number(),
      signal: z.string(),
      reason: z.string(),
      rsi: z.number().optional(),
      priceChange24h: z.number().optional(),
      volume24h: z.number().optional(),
      volumeChange: z.number().optional(),
      volumeIndicator: z.string().optional()
    })),
    stockBuySignals: z.array(z.object({
      ticker: z.string(),
      type: z.string(),
      price: z.number(),
      signal: z.string(),
      reason: z.string(),
      rsi: z.number().optional(),
      priceChange24h: z.number().optional()
    }))
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    const runtimeContext = new RuntimeContext();
    logger?.info("\u{1F4CA} [HourlyMonitor] Step 3: Scanning top 30 stocks for BUY signals");
    const result = await getBuySignals.execute({
      context: {
        assetType: "STOCK",
        limit: 30
      },
      runtimeContext,
      mastra
    });
    logger?.info("\u2705 [HourlyMonitor] Stock scan complete", {
      buySignals: result.buyOpportunities?.length || 0
    });
    return {
      ...inputData,
      stockBuySignals: result.buyOpportunities || []
    };
  }
});
const sendAllAlertsStep = createStep({
  id: "send-all-alerts",
  description: "Send Telegram alerts for SELL and BUY signals",
  inputSchema: z.object({
    webhookReconnected: z.boolean(),
    scanned: z.number(),
    sellSignals: z.array(z.object({
      symbol: z.string(),
      assetType: z.string(),
      signal: z.string()
    })),
    cryptoBuySignals: z.array(z.object({
      ticker: z.string(),
      type: z.string(),
      price: z.number(),
      signal: z.string(),
      reason: z.string(),
      rsi: z.number().optional(),
      priceChange24h: z.number().optional(),
      volume24h: z.number().optional(),
      volumeChange: z.number().optional(),
      volumeIndicator: z.string().optional()
    })),
    stockBuySignals: z.array(z.object({
      ticker: z.string(),
      type: z.string(),
      price: z.number(),
      signal: z.string(),
      reason: z.string(),
      rsi: z.number().optional(),
      priceChange24h: z.number().optional()
    }))
  }),
  outputSchema: z.object({
    totalAlertsSent: z.number()
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    const runtimeContext = new RuntimeContext();
    logger?.info("\u{1F4E4} [HourlyMonitor] Step 4: Preparing and sending all alerts");
    let alertsSent = 0;
    if (inputData.sellSignals.length > 0) {
      try {
        let sellMessage = `\u26A0\uFE0F *SELL SIGNALS DETECTED*

`;
        sellMessage += `Scanned ${inputData.scanned} holdings, found ${inputData.sellSignals.length} SELL signal(s):

`;
        for (const signal of inputData.sellSignals) {
          const emoji = signal.assetType === "STOCK" ? "\u{1F4CA}" : "\u{1FA99}";
          sellMessage += `${emoji} *${signal.symbol}* (${signal.assetType})
`;
          sellMessage += `\u26A0\uFE0F ${signal.signal}

`;
        }
        sellMessage += `\u{1F4A1} Review your positions and consider taking action.`;
        await sendTelegramAlert.execute({
          context: { message: sellMessage },
          runtimeContext,
          mastra
        });
        alertsSent++;
        logger?.info(`\u2705 [HourlyMonitor] SELL alert sent for ${inputData.sellSignals.length} signal(s)`);
      } catch (error) {
        logger?.error(`\u274C [HourlyMonitor] Failed to send SELL alert`, { error: error.message });
      }
    } else if (inputData.scanned > 0) {
      try {
        await sendTelegramAlert.execute({
          context: {
            message: `\u2705 *Holdings Scan*

Scanned ${inputData.scanned} holding(s).
No SELL signals detected. \u{1F48E}\u{1F64C}`
          },
          runtimeContext,
          mastra
        });
        logger?.info("\u2705 [HourlyMonitor] Holdings summary sent (no SELL signals)");
      } catch (error) {
        logger?.error(`\u274C [HourlyMonitor] Failed to send holdings summary`, { error: error.message });
      }
    } else {
      try {
        await sendTelegramAlert.execute({
          context: {
            message: `\u{1F4ED} *Holdings Watchlist Empty*

No assets to scan.
Use "addhold <ticker>" to add assets for monitoring.`
          },
          runtimeContext,
          mastra
        });
        logger?.info("\u2705 [HourlyMonitor] Empty watchlist notification sent");
      } catch (error) {
        logger?.error(`\u274C [HourlyMonitor] Failed to send empty watchlist notification`, { error: error.message });
      }
    }
    const totalBuySignals = inputData.cryptoBuySignals.length + inputData.stockBuySignals.length;
    if (totalBuySignals > 0) {
      try {
        let buyMessage = `\u{1F680} *BUY SIGNALS DETECTED*

`;
        buyMessage += `Found ${totalBuySignals} strong opportunity signal(s):

`;
        if (inputData.cryptoBuySignals.length > 0) {
          buyMessage += `\u{1FA99} *CRYPTO (${inputData.cryptoBuySignals.length})*
`;
          for (const signal of inputData.cryptoBuySignals) {
            buyMessage += `\u2022 *${signal.ticker}*`;
            if (signal.price) {
              const decimals = signal.price < 1 ? 6 : 2;
              buyMessage += ` @ $${signal.price.toFixed(decimals)}`;
            }
            buyMessage += `
`;
            if (signal.volume24h !== void 0 && signal.volumeChange !== void 0 && signal.volumeIndicator && Number.isFinite(signal.volume24h) && Number.isFinite(signal.volumeChange)) {
              const volumeM = (signal.volume24h / 1e6).toFixed(2);
              const volumeChangeStr = signal.volumeChange > 0 ? `+${signal.volumeChange.toFixed(1)}` : signal.volumeChange.toFixed(1);
              buyMessage += `  Vol: ${signal.volumeIndicator} $${volumeM}M (${volumeChangeStr}%)
`;
            }
            buyMessage += `  ${signal.reason}

`;
          }
        }
        if (inputData.stockBuySignals.length > 0) {
          buyMessage += `\u{1F4CA} *STOCKS (${inputData.stockBuySignals.length})*
`;
          for (const signal of inputData.stockBuySignals) {
            buyMessage += `\u2022 *${signal.ticker}* @ $${signal.price.toFixed(2)}
`;
            buyMessage += `  ${signal.reason}

`;
          }
        }
        buyMessage += `\u{1F4A1} Use "addhold <ticker>" to add to your watchlist.`;
        await sendTelegramAlert.execute({
          context: { message: buyMessage },
          runtimeContext,
          mastra
        });
        alertsSent++;
        logger?.info(`\u2705 [HourlyMonitor] BUY alert sent for ${totalBuySignals} signal(s)`);
      } catch (error) {
        logger?.error(`\u274C [HourlyMonitor] Failed to send BUY alert`, { error: error.message });
      }
    } else {
      try {
        await sendTelegramAlert.execute({
          context: {
            message: `\u2705 *Market Scan Complete*

Scanned top 100 crypto + 30 stocks.
No strong BUY signals detected.`
          },
          runtimeContext,
          mastra
        });
        logger?.info("\u2705 [HourlyMonitor] Market summary sent (no BUY signals)");
      } catch (error) {
        logger?.error(`\u274C [HourlyMonitor] Failed to send market summary`, { error: error.message });
      }
    }
    logger?.info(`\u2705 [HourlyMonitor] Total alerts sent: ${alertsSent}`);
    return { totalAlertsSent: alertsSent };
  }
});
const hourlyMonitor = createWorkflow({
  id: "hourly-monitor",
  inputSchema: z.object({}),
  outputSchema: z.object({
    totalAlertsSent: z.number()
  })
}).then(reconnectWebhookStep).then(scanHoldingsStep).then(scanCryptoBuySignalsStep).then(scanStockBuySignalsStep).then(sendAllAlertsStep).commit();

class ProductionPinoLogger extends MastraLogger {
  logger;
  constructor(options = {}) {
    super(options);
    this.logger = pino({
      name: options.name || "app",
      level: options.level || LogLevel.INFO,
      base: {},
      formatters: {
        level: (label, _number) => ({
          level: label
        })
      },
      timestamp: () => `,"time":"${new Date(Date.now()).toISOString()}"`
    });
  }
  debug(message, args = {}) {
    this.logger.debug(args, message);
  }
  info(message, args = {}) {
    this.logger.info(args, message);
  }
  warn(message, args = {}) {
    this.logger.warn(args, message);
  }
  error(message, args = {}) {
    this.logger.error(args, message);
  }
}
registerCronWorkflow(
  "0 8,20 * * *",
  // At 8:00 AM and 8:00 PM every day
  hourlyMonitor
);
const mastra = new Mastra({
  storage: sharedPostgresStorage,
  // Register your workflows here
  workflows: {
    hourlyMonitor
  },
  // Register your agents here
  agents: {},
  mcpServers: {
    allTools: new MCPServer({
      name: "allTools",
      version: "1.0.0",
      tools: {
        getWalletActivity,
        getTokenMetrics,
        analyzeWalletOrganic,
        getWalletPerformance,
        calculateWalletScore,
        autoDiscoverWallets,
        verifyWallets,
        sendTelegramAlert,
        getHistoricalOHLCV,
        analyzePatterns,
        monitorTokenPrices,
        backtestStrategy,
        backtestSwingStrategy,
        backtestStockSwingStrategy,
        monitorAMDPrice,
        monitorAssetPrice,
        recordTradeEntry,
        recordTradeExit,
        getTradeStatus,
        calculatePosition,
        scanAsset,
        getNewCoins,
        getTrendingCoins,
        getBuySignals,
        getSellSignals,
        addHolding,
        removeHolding,
        listHoldings,
        scanHoldings,
        reconnectTelegramWebhook,
        setWallet,
        getWallet,
        getPortfolio
      }
    })
  },
  bundler: {
    // A few dependencies are not properly picked up by
    // the bundler if they are not added directly to the
    // entrypoint.
    externals: ["@slack/web-api", "inngest", "inngest/hono", "hono", "hono/streaming"],
    // sourcemaps are good for debugging.
    sourcemap: true
  },
  server: {
    host: "0.0.0.0",
    port: 5e3,
    middleware: [async (c, next) => {
      const mastra2 = c.get("mastra");
      const logger = mastra2?.getLogger();
      logger?.debug("[Request]", {
        method: c.req.method,
        url: c.req.url
      });
      try {
        await next();
      } catch (error) {
        logger?.error("[Response]", {
          method: c.req.method,
          url: c.req.url,
          error
        });
        if (error instanceof MastraError) {
          if (error.id === "AGENT_MEMORY_MISSING_RESOURCE_ID") {
            throw new NonRetriableError(error.message, {
              cause: error
            });
          }
        } else if (error instanceof z.ZodError) {
          throw new NonRetriableError(error.message, {
            cause: error
          });
        }
        throw error;
      }
    }],
    apiRoutes: [
      // This API route is used to register the Mastra workflow (inngest function) on the inngest server
      {
        path: "/api/inngest",
        method: "ALL",
        createHandler: async ({
          mastra: mastra2
        }) => inngestServe({
          mastra: mastra2,
          inngest
        })
        // The inngestServe function integrates Mastra workflows with Inngest by:
        // 1. Creating Inngest functions for each workflow with unique IDs (workflow.${workflowId})
        // 2. Setting up event handlers that:
        //    - Generate unique run IDs for each workflow execution
        //    - Create an InngestExecutionEngine to manage step execution
        //    - Handle workflow state persistence and real-time updates
        // 3. Establishing a publish-subscribe system for real-time monitoring
        //    through the workflow:${workflowId}:${runId} channel
      }
      // Telegram bot now uses polling mode instead of webhooks (no routes needed)
    ]
  },
  logger: process.env.NODE_ENV === "production" ? new ProductionPinoLogger({
    name: "Mastra",
    level: "info"
  }) : new PinoLogger({
    name: "Mastra",
    level: "info"
  })
});
if (Object.keys(mastra.getWorkflows()).length > 1) {
  throw new Error("More than 1 workflows found. Currently, more than 1 workflows are not supported in the UI, since doing so will cause app state to be inconsistent.");
}
if (Object.keys(mastra.getAgents()).length > 1) {
  throw new Error("More than 1 agents found. Currently, more than 1 agents are not supported in the UI, since doing so will cause app state to be inconsistent.");
}
registerTickerBot(mastra);

export { mastra };
