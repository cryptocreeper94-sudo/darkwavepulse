import pg from 'pg';

const { Pool } = pg;
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});
async function savePriceSnapshot(data) {
  const result = await pool.query(
    `INSERT INTO price_snapshots (symbol, price, high_7d, low_7d, change_percent, rsi, volume)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     RETURNING *`,
    [data.symbol, data.price, data.high7d, data.low7d, data.changePercent, data.rsi, data.volume]
  );
  return result.rows[0];
}
async function getPriceHistory(symbol, days) {
  const result = await pool.query(
    `SELECT * FROM price_snapshots
     WHERE symbol = $1
     AND timestamp >= NOW() - INTERVAL '${days} days'
     ORDER BY timestamp DESC`,
    [symbol]
  );
  return result.rows;
}
async function saveSignal(data) {
  const result = await pool.query(
    `INSERT INTO trading_signals (symbol, signal_type, trigger_price, current_price, reason)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING *`,
    [data.symbol, data.signalType, data.triggerPrice, data.currentPrice, data.reason]
  );
  return result.rows[0];
}
async function getRecentSignals(symbol, hours = 24) {
  const result = await pool.query(
    `SELECT * FROM trading_signals
     WHERE symbol = $1
     AND timestamp >= NOW() - INTERVAL '${hours} hours'
     ORDER BY timestamp DESC`,
    [symbol]
  );
  return result.rows;
}
async function createTrade(data) {
  const shares = data.positionSize / data.entryPrice;
  const result = await pool.query(
    `INSERT INTO trades (symbol, trade_type, entry_price, entry_date, position_size, shares, entry_signal_id, notes)
     VALUES ($1, $2, $3, NOW(), $4, $5, $6, $7)
     RETURNING *`,
    [data.symbol, data.tradeType, data.entryPrice, data.positionSize, shares, data.entrySignalId, data.notes]
  );
  return result.rows[0];
}
async function closeTrade(data) {
  const tradeResult = await pool.query(
    `SELECT * FROM trades WHERE id = $1`,
    [data.tradeId]
  );
  if (tradeResult.rows.length === 0) {
    throw new Error(`Trade ${data.tradeId} not found`);
  }
  const trade = tradeResult.rows[0];
  const profitLoss = parseFloat(trade.shares) * data.exitPrice - parseFloat(trade.position_size);
  const profitLossPercent = profitLoss / parseFloat(trade.position_size) * 100;
  const holdingDays = Math.floor((Date.now() - new Date(trade.entry_date).getTime()) / (1e3 * 60 * 60 * 24));
  const result = await pool.query(
    `UPDATE trades
     SET exit_price = $2, exit_date = NOW(), exit_reason = $3, exit_signal_id = $4,
         profit_loss = $5, profit_loss_percent = $6, holding_days = $7, status = 'CLOSED',
         updated_at = NOW()
     WHERE id = $1
     RETURNING *`,
    [data.tradeId, data.exitPrice, data.exitReason, data.exitSignalId, profitLoss, profitLossPercent, holdingDays]
  );
  return result.rows[0];
}
async function getOpenTrades(symbol, tradeType) {
  const query = tradeType ? `SELECT * FROM trades WHERE symbol = $1 AND status = 'OPEN' AND trade_type = $2 ORDER BY entry_date DESC` : `SELECT * FROM trades WHERE symbol = $1 AND status = 'OPEN' ORDER BY entry_date DESC`;
  const params = tradeType ? [symbol, tradeType] : [symbol];
  const result = await pool.query(query, params);
  return result.rows;
}
async function getAllTrades(symbol, tradeType) {
  const query = tradeType ? `SELECT * FROM trades WHERE symbol = $1 AND trade_type = $2 ORDER BY entry_date DESC` : `SELECT * FROM trades WHERE symbol = $1 ORDER BY entry_date DESC`;
  const params = tradeType ? [symbol, tradeType] : [symbol];
  const result = await pool.query(query, params);
  return result.rows;
}
async function calculateAndSaveMetrics(symbol, tradeType) {
  const trades = await getAllTrades(symbol, tradeType);
  const closedTrades = trades.filter((t) => t.status === "CLOSED");
  if (closedTrades.length === 0) {
    return null;
  }
  const winningTrades = closedTrades.filter((t) => parseFloat(t.profit_loss) > 0);
  const losingTrades = closedTrades.filter((t) => parseFloat(t.profit_loss) < 0);
  const totalProfit = winningTrades.reduce((sum, t) => sum + parseFloat(t.profit_loss), 0);
  const totalLoss = Math.abs(losingTrades.reduce((sum, t) => sum + parseFloat(t.profit_loss), 0));
  const netProfitLoss = totalProfit - totalLoss;
  const winRate = winningTrades.length / closedTrades.length * 100;
  const avgWin = winningTrades.length > 0 ? winningTrades.reduce((sum, t) => sum + parseFloat(t.profit_loss_percent), 0) / winningTrades.length : 0;
  const avgLoss = losingTrades.length > 0 ? losingTrades.reduce((sum, t) => sum + parseFloat(t.profit_loss_percent), 0) / losingTrades.length : 0;
  const avgHolding = closedTrades.reduce((sum, t) => sum + (t.holding_days || 0), 0) / closedTrades.length;
  const profitFactor = totalLoss > 0 ? totalProfit / totalLoss : totalProfit > 0 ? 999 : 0;
  let peak = 0;
  let maxDrawdown = 0;
  let runningTotal = 0;
  closedTrades.forEach((t) => {
    runningTotal += parseFloat(t.profit_loss);
    if (runningTotal > peak) {
      peak = runningTotal;
    }
    const drawdown = (peak - runningTotal) / peak * 100;
    if (drawdown > maxDrawdown) {
      maxDrawdown = drawdown;
    }
  });
  const periodStart = new Date(closedTrades[closedTrades.length - 1].entry_date);
  const periodEnd = new Date(closedTrades[0].exit_date);
  const result = await pool.query(
    `INSERT INTO performance_metrics 
     (symbol, trade_type, total_trades, winning_trades, losing_trades, win_rate,
      total_profit, total_loss, net_profit_loss, avg_win_percent, avg_loss_percent,
      avg_holding_days, profit_factor, max_drawdown, period_start, period_end)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
     ON CONFLICT DO NOTHING
     RETURNING *`,
    [
      symbol,
      tradeType,
      closedTrades.length,
      winningTrades.length,
      losingTrades.length,
      winRate,
      totalProfit,
      totalLoss,
      netProfitLoss,
      avgWin,
      avgLoss,
      avgHolding,
      profitFactor,
      maxDrawdown,
      periodStart,
      periodEnd
    ]
  );
  return result.rows[0];
}

export { getRecentSignals as a, saveSignal as b, getOpenTrades as c, createTrade as d, closeTrade as e, calculateAndSaveMetrics as f, getPriceHistory as g, getAllTrades as h, savePriceSnapshot as s };
//# sourceMappingURL=darkwave.mjs.map
